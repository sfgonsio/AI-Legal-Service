# ATTORNEY VALIDATION GUIDE

## Purpose

This guide helps you present the Litigation Workflow slides (SL-13, SL-14, SL-15) to attorneys for validation.

---

## CRITICAL: Set the Right Frame

### Opening Statement (Use This Verbatim):

> **"We are not debating terminology today. We are validating whether the workflow and artifacts reflect real litigation practice. If the artifacts and stages are correct, the platform will mirror how attorneys actually work."**

This prevents getting derailed by semantic debates.

---

## THE THREE SLIDES TO VALIDATE

### 1. SL-13: Litigation Workflow Stages

**What it shows:** 12-stage litigation lifecycle from intake to post-trial

**Validation questions:**
- ✅ Are these the right 12 stages?
- ✅ Is the sequence correct?
- ✅ Are the key artifacts listed for each stage accurate?
- ✅ Does the party designation (Plaintiff/Defendant/Both) make sense?

**What NOT to validate:**
- ❌ Platform component naming conventions
- ❌ Whether "INTERVIEW_AGENT" is the right name
- ❌ Technical implementation details

**Focus on:** Real litigation practice, not system architecture

---

### 2. SL-14: Artifact Production Matrix

**What it shows:** SIPOC workflow (Supplier → Inputs → Process → Output → Consumer)

**Validation questions:**
- ✅ Do these artifact flows match real litigation?
- ✅ Is the supplier correctly identified?
- ✅ Are the inputs correct for each artifact?
- ✅ Does the process accurately describe the legal work?
- ✅ Is the consumer/next user correct?
- ✅ Is approval designation accurate?

**What NOT to validate:**
- ❌ "Producer Type" labels (Program/Agent/Attorney)
- ❌ Platform component names
- ❌ Technical implementation

**Focus on:** Litigation workflow accuracy

---

### 3. SL-15: Canonical Artifact Registry

**What it shows:** Comprehensive catalog of ~40 litigation artifacts

**Validation questions:**
- ✅ Are we missing any major artifacts?
- ✅ Are the artifact descriptions accurate?
- ✅ Are the 8 classes correct? (Evidence, Analysis, Pleading, Discovery, Motion, Trial, Post-Trial, Administrative)
- ✅ Do lifecycle stages align with when artifacts are actually produced?

**What NOT to validate:**
- ❌ Artifact ID naming convention (ART-XX-XXXXX)
- ❌ "Deterministic Stage" labels
- ❌ Technical implementation details

**Focus on:** Completeness and accuracy of artifact catalog

---

## TERMINOLOGY REFERENCE (Keep This Handy)

### Core Litigation Terms:

| Term | Meaning | Example |
|------|---------|---------|
| **Stage** | Major phase of litigation | Client Intake, Discovery, Trial |
| **Artifact** | Work product produced | Complaint, Deposition Transcript, Motion |
| **Supplier** | Source of information | Client, Evidence, Court, Attorney |
| **Inputs** | Information used | Facts, Evidence, Law |
| **Process** | Legal/analytical work | Fact extraction, Legal analysis, Drafting |
| **Output** | Artifact created | Document, Analysis, Brief |
| **Consumer** | Next user of artifact | Attorney, Court, Opposing Counsel |

### Platform Execution Terms (Less Important for Validation):

| Term | Meaning | Why It Matters |
|------|---------|----------------|
| **Producer Type** | Who generated it | Shows automation level |
| **Platform Component** | Responsible system | Technical mapping |
| **Approval Required** | Attorney validation needed | Prevents unauthorized work |
| **Artifact Class** | Type category | Organization structure |
| **Deterministic Stage** | Processing pipeline | Technical execution |

**Remind attorneys:** Focus on the left column (litigation terms), not the right column (platform terms).

---

## MISSING ARTIFACTS CHECK

### Discovery Artifacts (7 in catalog):
- [ ] Interrogatories
- [ ] Requests for Production
- [ ] Requests for Admission
- [ ] Subpoena
- [ ] Deposition Notice
- [ ] Deposition Outline
- [ ] Discovery Response Map

**Ask:** "Are we missing any discovery artifacts?"

### Motion Practice (6 in catalog):
- [ ] Motion to Dismiss
- [ ] Motion for Summary Judgment
- [ ] Motion to Compel
- [ ] Motion for Protective Order
- [ ] Opposition Brief
- [ ] Reply Brief

**Ask:** "Are there other motions we should include?"

### Trial Artifacts (7 in catalog):
- [ ] Exhibit List
- [ ] Witness List
- [ ] Trial Brief
- [ ] Direct Examination Outline
- [ ] Cross Examination Outline
- [ ] Proposed Jury Instructions
- [ ] Trial Evidence Map

**Ask:** "What trial artifacts are we missing?"

---

## KNOWN GAPS TO VALIDATE

### Case Type Coverage:
- **Currently scoped:** Civil → Contract → Breach
- **Need to expand:** Tort, Employment, IP, etc.

**Ask:** "Does the workflow matrix work for other case types?"

### Posture Coverage:
- **Currently shown:** Plaintiff and Defendant views
- **Need to validate:** Defense-specific workflows

**Ask:** "Are defendant-side artifacts accurately represented?"

### Litigation Hierarchy:
```
Case Type (Civil)
  ↓
Sub Case Type (Contract)
  ↓
Cause of Action (Breach of Contract)
  ↓
Elements (Valid Contract, Performance, Breach, Damages)
  ↓
Evidence
```

**Ask:** "Is this hierarchy correct? Does it capture how COAs are analyzed?"

---

## VALIDATION SESSION STRUCTURE

### Phase 1: High-Level Validation (15 minutes)
1. Show **SL-13** - "Are these the right 12 stages?"
2. Get yes/no on overall structure
3. Note any missing stages

### Phase 2: Workflow Validation (20 minutes)
1. Show **SL-14** - "Does this SIPOC flow match reality?"
2. Filter by stage and review 2-3 examples
3. Get feedback on supplier/input/process/output accuracy
4. Focus on approval requirements

### Phase 3: Artifact Completeness (15 minutes)
1. Show **SL-15** - "Are we missing artifacts?"
2. Go through each class (Evidence, Analysis, Pleading, etc.)
3. Capture missing artifacts
4. Validate descriptions

### Phase 4: Capture Action Items (10 minutes)
1. Document missing artifacts
2. Note incorrect flows
3. Identify scope gaps (case types, postures)
4. Prioritize fixes

**Total time: ~60 minutes**

---

## RED FLAGS TO WATCH FOR

### 🚩 Attorney Gets Lost in Technical Details
**Solution:** Redirect with: "Let's focus on whether the litigation workflow is accurate, not the system architecture."

### 🚩 Semantic Debate About Terms
**Solution:** "We can adjust terminology later. Right now, does the workflow itself match reality?"

### 🚩 "This Doesn't Apply to My Practice Area"
**Solution:** "Correct, we're starting with civil contract litigation. Does it work for that specific scope?"

### 🚩 "You're Missing X, Y, Z Artifacts"
**Solution:** "Great! Let's capture those. Are they common across case types or specific to certain practice areas?"

### 🚩 "This Is Too Simplified"
**Solution:** "Good feedback. Where does the simplification break down? What nuance are we missing?"

---

## SUCCESS CRITERIA

### ✅ Validation Successful If:
1. Attorney confirms 12 stages are correct
2. Attorney confirms artifact flow logic is sound
3. Attorney identifies <10 missing artifacts
4. Attorney confirms approval requirements are reasonable
5. Attorney says: "Yes, this mirrors real litigation"

### ⚠️ Needs Revision If:
1. Attorney identifies missing stages
2. Major artifact flows are incorrect
3. Approval logic is wrong
4. 20+ missing artifacts identified
5. Attorney says: "This doesn't match practice"

### ❌ Back to Drawing Board If:
1. Fundamental workflow is wrong
2. Stage sequence is incorrect
3. Attorney says: "This makes no sense"

---

## POST-VALIDATION ACTIONS

### After Session:
1. **Document feedback** in structured format:
   ```
   STAGE: [Stage Name]
   ISSUE: [What's wrong]
   CORRECTION: [What should it be]
   PRIORITY: [High/Medium/Low]
   ```

2. **Update artifact registry** with missing artifacts

3. **Revise workflow matrix** with corrected flows

4. **Re-present changes** to attorney for confirmation

5. **Update slides** with validated content

---

## EXPECTED OUTCOME

After attorney validation, you should have:

1. ✅ **Validated 12-stage workflow** (or revised stage list)
2. ✅ **Corrected artifact flows** in SIPOC matrix
3. ✅ **Expanded artifact catalog** to 50-80 artifacts
4. ✅ **Identified scope boundaries** (case types, postures)
5. ✅ **Attorney buy-in** that platform mirrors real practice

This becomes your **authoritative litigation specification** for:
- Product scope
- Engineering builds
- Orchestration design
- Artifact registry architecture
- Attorney validation checkpoints

---

## FINAL REMINDER

**The goal is NOT perfection.**

**The goal is validation that:**
1. The workflow is fundamentally correct
2. The major artifacts are captured
3. The SIPOC flow logic is sound
4. Attorneys recognize this as real litigation practice

Gaps and refinements are expected and welcomed.

This is v1 for attorney validation, not the final specification.

**Frame it that way from the start.**
