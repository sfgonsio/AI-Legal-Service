# Legal AI Executive Portal - Deployment Guide

## 📦 Building for Production

Your app is built with React + Vite. To create the production files (.html, .js, .css), run:

```bash
npm run build
```

This creates a `dist/` folder containing:
- `index.html` - Main HTML file
- `assets/*.js` - Optimized JavaScript bundles
- `assets/*.css` - Compiled CSS files
- All optimized assets

---

## 🚀 Deployment Options

### Option 1: GitHub Pages (Free Hosting)

#### Step 1: Add GitHub Pages configuration

Add this to your `package.json`:

```json
{
  "homepage": "https://YOUR_USERNAME.github.io/YOUR_REPO_NAME"
}
```

#### Step 2: Install gh-pages

```bash
npm install --save-dev gh-pages
```

#### Step 3: Add deploy scripts to package.json

```json
{
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

#### Step 4: Deploy

```bash
npm run deploy
```

Your site will be live at: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME`

#### Step 5: Configure GitHub Repository

1. Go to your repo Settings → Pages
2. Set Source to `gh-pages` branch
3. Click Save

---

### Option 2: Custom Domain (Netlify - Free)

#### Quick Deploy:

1. **Build your app:**
   ```bash
   npm run build
   ```

2. **Deploy to Netlify:**
   - Go to [netlify.com](https://netlify.com)
   - Drag & drop your `dist` folder
   - Done! You get a URL like `your-app.netlify.app`

3. **Custom Domain:**
   - In Netlify dashboard: Domain Settings → Add custom domain
   - Point your domain's DNS to Netlify:
     - Add A record: `75.2.60.5`
     - Add CNAME record: `www` → `your-app.netlify.app`

#### Continuous Deployment (via GitHub):

1. Connect your GitHub repo to Netlify
2. Build settings:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
3. Every push to `main` auto-deploys!

---

### Option 3: Custom Domain (Vercel - Free)

1. Install Vercel CLI:
   ```bash
   npm install -g vercel
   ```

2. Deploy:
   ```bash
   vercel
   ```

3. Follow prompts to link your domain

---

### Option 4: Traditional Web Host (GoDaddy, Bluehost, etc.)

1. **Build the app:**
   ```bash
   npm run build
   ```

2. **Upload via FTP/cPanel:**
   - Upload everything from the `dist/` folder
   - Place files in your `public_html` or `www` directory

3. **Important:** Configure URL routing (see below)

---

## ⚙️ Required: Router Configuration

Since this app uses React Router, you need to configure your server to handle client-side routing:

### For Netlify:
Create `public/_redirects`:
```
/*    /index.html   200
```

### For Vercel:
Create `vercel.json`:
```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/" }]
}
```

### For Apache (most shared hosting):
Create `dist/.htaccess`:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

### For GitHub Pages:
GitHub Pages doesn't support server-side routing well. Use hash router instead (see vite.config.ts update below).

---

## 🛠️ Files I'm Creating for You

1. **vite.config.ts** - Updated build configuration
2. **netlify.toml** - Netlify deployment config
3. **vercel.json** - Vercel deployment config
4. **public/_redirects** - Netlify routing
5. **.github/workflows/deploy.yml** - GitHub Pages auto-deploy

---

## 📝 Quick Start

**For Netlify (Recommended for beginners):**
```bash
npm run build
# Then drag & drop 'dist' folder to netlify.com/drop
```

**For GitHub Pages:**
```bash
npm run deploy
```

**For Custom Server:**
```bash
npm run build
# Upload 'dist' folder contents via FTP
```

---

## 🔍 Testing Locally

Before deploying, test the production build:

```bash
npm run build
npx serve dist
```

Open http://localhost:3000 to preview

---

## 📱 What You'll Get

After deployment, your portal will have:
- ✅ Fast loading (optimized bundles)
- ✅ Responsive design
- ✅ Smooth animations
- ✅ Keyboard navigation
- ✅ Dark mode toggle
- ✅ Professional UI

---

## 🆘 Need Help?

If you run into issues, let me know which deployment method you chose!
