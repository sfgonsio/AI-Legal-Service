# 🚀 Quick Deployment Guide

## Choose Your Method:

### 🟢 EASIEST: Netlify Drop (2 minutes)

1. **Build your app:**
   ```bash
   npm run build
   ```

2. **Deploy:**
   - Go to https://app.netlify.com/drop
   - Drag the `dist` folder onto the page
   - Done! You get a live URL instantly

3. **Add custom domain (optional):**
   - Click "Domain settings" in Netlify
   - Add your domain (e.g., legalai.yourdomain.com)
   - Update your DNS:
     - CNAME: `legalai` → `your-site.netlify.app`

---

### 🔵 AUTOMATED: GitHub Pages (Free, Auto-updates)

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

2. **Enable GitHub Pages:**
   - Go to your repo → Settings → Pages
   - Source: GitHub Actions
   - The workflow will auto-deploy!

3. **Your site will be at:**
   ```
   https://YOUR_USERNAME.github.io/YOUR_REPO/
   ```

4. **If using a repo name, update vite.config.ts:**
   ```typescript
   // Uncomment and change:
   base: '/YOUR_REPO_NAME/',
   ```

---

### 🟣 PROFESSIONAL: Vercel (Best for custom domains)

1. **Install Vercel CLI:**
   ```bash
   npm install -g vercel
   ```

2. **Deploy:**
   ```bash
   vercel
   ```

3. **Follow prompts:**
   - Link to your account
   - Choose project name
   - Done! Auto-deploys on every git push

4. **Custom domain:**
   - In Vercel dashboard: Settings → Domains
   - Add domain and follow DNS instructions

---

### 🟠 TRADITIONAL: FTP Upload (Any hosting)

1. **Build:**
   ```bash
   npm run build
   ```

2. **Upload via FTP/cPanel:**
   - Upload contents of `dist/` folder to your web root
   - Usually `public_html/` or `www/`
   - Make sure `.htaccess` is included for routing

---

## 📁 What Gets Generated

After `npm run build`, your `dist/` folder contains:

```
dist/
├── index.html          ← Main HTML file
├── assets/
│   ├── index-abc123.js    ← JavaScript bundle
│   ├── index-def456.css   ← Compiled styles
│   └── ...                ← Other optimized assets
└── .htaccess          ← Apache routing rules
```

These are the **production-ready files** you upload to your server.

---

## ✅ Verification

After deployment, check:
- [ ] Homepage loads
- [ ] Navigation works (click through pages)
- [ ] Keyboard shortcuts work (arrow keys, Home, End, ?)
- [ ] Dark mode toggle works
- [ ] No console errors

---

## 🆘 Common Issues

**Issue:** Pages show 404 when refreshing
- **Fix:** Make sure routing config is set up (see DEPLOYMENT.md)

**Issue:** GitHub Pages shows blank page
- **Fix:** Add `base: '/YOUR_REPO_NAME/'` to vite.config.ts

**Issue:** Assets not loading
- **Fix:** Check that all files from `dist/` were uploaded

---

## 💡 Recommended: Netlify

**Why Netlify?**
- ✅ Drag & drop deployment
- ✅ Free SSL certificate
- ✅ Custom domains
- ✅ Auto-handles routing
- ✅ Fast CDN
- ✅ No configuration needed

Just build and drop!

---

## 📞 Next Steps

1. Deploy using your preferred method
2. Share the URL for 3-minute video creation
3. Test on mobile devices
4. Share with stakeholders

Good luck with your deployment! 🎉
