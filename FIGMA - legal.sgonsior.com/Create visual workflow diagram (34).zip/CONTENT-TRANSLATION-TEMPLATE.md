# 📋 Content Translation Template

Use this template to translate technical features into stakeholder-focused content.

---

## 🎯 Feature Translation Framework

Copy and fill out for each feature:

```
🔐 [Number]. "[Feature Name in Their Language]"

═══════════════════════════════════════════════════════

Technical Meaning
─────────────────────────────────────────────────────

[Write the precise technical definition here]
[How it actually works mechanically]
[Include 2-3 key technical details]


[Stakeholder Type] Meaning
─────────────────────────────────────────────────────

[What it does in their workflow]
[Real-world application they understand]
[Concrete example from their domain]


Why They Care
─────────────────────────────────────────────────────

Because:

• [Connection to their primary goal]
• [Risk it mitigates]
• [Benefit they receive]

If challenged:

"[Exact quote they could use to defend/explain]"

That's [powerful outcome in their language].


[Stakeholder Type] Translation:
─────────────────────────────────────────────────────

"[One-sentence summary in plain language]"

That's [concrete benefit they care about].

═══════════════════════════════════════════════════════
```

---

## 📝 Example: Filled Template

```
🔐 1. "Integrity-Locked Files"

═══════════════════════════════════════════════════════

Technical Meaning
─────────────────────────────────────────────────────

Key system files are cryptographically hashed.
If even one character changes, the system detects it.
Uses SHA-256 or similar algorithms for verification.


Attorney Meaning
─────────────────────────────────────────────────────

No one can silently alter:

• Cause-of-action definitions
• Mapping rules
• Audit structures
• Evidence schemas
• Output formatting rules

If something changes, it's detected immediately.


Why They Care
─────────────────────────────────────────────────────

Because:

• Opposing counsel cannot argue system tampering
• Internal staff cannot unknowingly alter structural rules
• The firm avoids "unknown version drift"

If challenged:

"We can prove no unauthorized changes were made to the system."

That's malpractice risk reduction.


Attorney Translation:
─────────────────────────────────────────────────────

"The system prevents silent rule changes."

That's defensibility.

═══════════════════════════════════════════════════════
```

---

## 🎯 Quick Fill Template (Short Version)

```
Feature: _______________________________

Technical: [How it works]

Functional: [What it does]

Impact: [Why they care]

One-liner: "[Summary in their language]"
```

---

## 🧪 Pre-Objection Framework

List potential objections BEFORE writing content:

```
OBJECTION CHECKLIST
═══════════════════════════════════════════════════════

Common Concern #1: _______________________________

How Feature Addresses It: _______________________________

Language to Use: _______________________________


Common Concern #2: _______________________________

How Feature Addresses It: _______________________________

Language to Use: _______________________________


Common Concern #3: _______________________________

How Feature Addresses It: _______________________________

Language to Use: _______________________________


Common Concern #4: _______________________________

How Feature Addresses It: _______________________________

Language to Use: _______________________________


Common Concern #5: _______________________________

How Feature Addresses It: _______________________________

Language to Use: _______________________________
```

---

## 🎭 Stakeholder Analysis Template

```
STAKEHOLDER: _______________________________

PRIMARY ROLE: _______________________________

TOP 5 PRIORITIES:
1. _______________________________
2. _______________________________
3. _______________________________
4. _______________________________
5. _______________________________

TOP 5 FEARS:
1. _______________________________
2. _______________________________
3. _______________________________
4. _______________________________
5. _______________________________

LANGUAGE THEY USE:
• _______________________________
• _______________________________
• _______________________________

METRICS THEY CARE ABOUT:
• _______________________________
• _______________________________
• _______________________________

DECISIONS THEY MAKE:
• _______________________________
• _______________________________
• _______________________________
```

---

## 🔍 Feature-to-Fear Mapping

```
FEATURE → FEAR MATRIX
═══════════════════════════════════════════════════════

Feature: _______________________________

Stakeholder Fear It Addresses: _______________________________

Connection: _______________________________

Supporting Evidence: _______________________________

One-Sentence Pitch: _______________________________


Feature: _______________________________

Stakeholder Fear It Addresses: _______________________________

Connection: _______________________________

Supporting Evidence: _______________________________

One-Sentence Pitch: _______________________________


[Repeat for each feature]
```

---

## 📊 "So What" Test

Run every statement through this test:

```
STATEMENT: _______________________________

Reader asks: "So what?"

Answer (must connect to ONE of these):
□ Saves money (how much?): _______________________________
□ Reduces risk (which risk?): _______________________________
□ Saves time (how much?): _______________________________
□ Improves quality (measured how?): _______________________________
□ Protects reputation (from what?): _______________________________
□ Ensures compliance (with what?): _______________________________
□ Increases revenue (by what means?): _______________________________

If you can't check a box, rewrite the statement.
```

---

## 🎬 Presentation Guidance Template

```
FEATURE: _______________________________

═══════════════════════════════════════════════════════

DON'T SAY:
─────────────────────────────────────────────────────

"_______________________________"

[Explain why this doesn't land]


INSTEAD SAY:
─────────────────────────────────────────────────────

"_______________________________"

[Explain why this lands better]


THEN:
─────────────────────────────────────────────────────

[Tactical instruction - pause, show visual, ask question, etc.]


EXPECTED RESPONSE:
─────────────────────────────────────────────────────

[What stakeholder should think/feel/ask]


FOLLOW-UP:
─────────────────────────────────────────────────────

[What to say if they ask for more detail]

═══════════════════════════════════════════════════════
```

---

## 🧠 Complete Content Development Process

```
STEP 1: STAKEHOLDER RESEARCH
═══════════════════════════════════════════════════════

□ Identify primary stakeholder
□ Research their priorities
□ List their top fears
□ Note language they use
□ Understand their decision criteria


STEP 2: FEATURE INVENTORY
═══════════════════════════════════════════════════════

□ List all technical features
□ Write technical description for each
□ Document how each works
□ Identify which are most important
□ Prioritize by stakeholder impact


STEP 3: TRANSLATION
═══════════════════════════════════════════════════════

□ Use Feature Translation Framework
□ Write technical meaning
□ Write stakeholder meaning
□ Connect to "why they care"
□ Create one-line summary
□ Test clarity with non-technical person


STEP 4: OBJECTION HANDLING
═══════════════════════════════════════════════════════

□ List potential objections
□ Map features to objections
□ Write pre-emptive responses
□ Incorporate into content


STEP 5: EVIDENCE GATHERING
═══════════════════════════════════════════════════════

□ Quantify benefits where possible
□ Cite industry standards
□ Reference case studies
□ Include expert opinions
□ Add regulatory requirements


STEP 6: STRUCTURE
═══════════════════════════════════════════════════════

□ Start with stakeholder goals
□ Present features as solutions
□ Use clear visual hierarchy
□ Add presentation guidance
□ End with "so what"


STEP 7: TESTING
═══════════════════════════════════════════════════════

□ Read to someone outside your field
□ Note confusion points
□ Track "so what?" moments
□ Identify what lands
□ Revise based on feedback


STEP 8: REFINEMENT
═══════════════════════════════════════════════════════

□ Remove jargon
□ Shorten sentences
□ Add concrete examples
□ Strengthen connections to fears
□ Polish one-liners
```

---

## 📝 Example Use Case: Your Video Component

Let me show you how to use this for YOUR video component:

```
🎬 "Consistent Message Delivery System"

═══════════════════════════════════════════════════════

Technical Meaning
─────────────────────────────────────────────────────

Auto-playing React component using Motion animations
Timer-based progress tracking with state management
Deterministic slide sequencing with configurable timing


Executive Meaning
─────────────────────────────────────────────────────

Your 3-minute overview plays automatically, hitting every 
key point in the same order every time. No manual clicking.
No risk of forgetting a section.


Why They Care
─────────────────────────────────────────────────────

Because:

• Inconsistent messaging creates confusion
• Skipped sections lead to incomplete understanding
• Manual presentations vary by presenter
• Stakeholders need to review async

If shared:

"Every board member saw the exact same presentation."

That's messaging control.


Executive Translation:
─────────────────────────────────────────────────────

"Ensures every stakeholder gets the complete story, 
consistently delivered."

That's professional communication.

═══════════════════════════════════════════════════════
```

---

## 🎯 Practice Exercise

Fill out this template for ONE feature of your system:

```
🔐 [Number]. "[Feature Name]"

═══════════════════════════════════════════════════════

Technical Meaning
─────────────────────────────────────────────────────







[Stakeholder Type] Meaning
─────────────────────────────────────────────────────







Why They Care
─────────────────────────────────────────────────────

Because:

•
•
•

If challenged:

""

That's ____________.


[Stakeholder Type] Translation:
─────────────────────────────────────────────────────

""

That's ____________.

═══════════════════════════════════════════════════════
```

---

## ✅ Quality Checklist

Before finalizing content, verify:

```
CLARITY
□ No unexplained jargon
□ Sentences under 20 words
□ Concrete examples provided
□ Technical terms defined

RELEVANCE
□ Connects to stakeholder goals
□ Addresses their fears
□ Uses their language
□ References their metrics

PERSUASION
□ States "so what" clearly
□ Provides evidence
□ Addresses objections
□ Includes presentation guidance

COMPLETENESS
□ Technical meaning provided
□ Functional translation included
□ Impact clearly stated
□ One-line summary written

TESTING
□ Tested with target audience
□ Confusion points addressed
□ Feedback incorporated
□ Landing moments identified
```

---

## 💡 Remember

**The goal isn't to sound smart.**

**The goal is to help stakeholders make confident decisions.**

Focus on:
- Their language (not yours)
- Their fears (not your features)
- Their outcomes (not your process)

**Use this template to bridge the gap.** 🌉

---

## 📞 Quick Reference

1. **Fill out Stakeholder Analysis** - Know your audience
2. **Use Feature Translation Framework** - Convert each feature
3. **Complete Pre-Objection Checklist** - Address concerns
4. **Run "So What" Test** - Verify impact
5. **Add Presentation Guidance** - Help them deliver
6. **Test with real people** - Validate clarity
7. **Refine based on feedback** - Iterate to excellence

**Result:** Content as good as the governed-legal-infrastructure.md example.

You can do this. 🚀
