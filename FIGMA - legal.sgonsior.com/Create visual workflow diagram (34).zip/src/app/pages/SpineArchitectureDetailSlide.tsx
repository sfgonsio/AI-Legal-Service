import { SlideShell } from "../components/SlideShell";
import { SpineArchitectureDetailDiagram } from "../components/slides/SpineArchitectureDetailDiagram";

export function SpineArchitectureDetailSlide() {
  return (
    <SlideShell
      title="The Spine Architecture"
      subtitle="Central Coordination Layer — Workflow • State • Audit • Determinism"
    >
      <SpineArchitectureDetailDiagram />
    </SlideShell>
  );
}
