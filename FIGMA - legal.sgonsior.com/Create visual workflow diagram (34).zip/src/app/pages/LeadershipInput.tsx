import { motion } from "motion/react";
import { useState } from "react";
import { MessageSquare, Send } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

const questions = [
  "Are workflow transitions aligned with firm practice?",
  "Are approval inflection points sufficient?",
  "Does governance reflect risk tolerance?",
  "Where should controls be strengthened?",
  "Are there additional defensibility considerations?",
];

export function LeadershipInput() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">
          Leadership Input
        </h1>
        <p
          className="text-base md:text-lg mt-4"
          style={{ color: "var(--text-secondary)" }}
        >
          Strategic questions for executive consideration
        </p>
      </motion.div>

      {/* Key Questions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        <h2>Key Questions for Review</h2>
        <p
          className="text-base"
          style={{ color: "var(--text-secondary)" }}
        >
          Please consider these questions as you review the
          system. Select any that require discussion:
        </p>

        <div className="space-y-3 mt-6">
          {questions.map((question, i) => (
            <QuestionCard
              key={i}
              question={question}
              delay={0.1 * i}
            />
          ))}
        </div>
      </motion.div>

      <PageNavigation
        prevLink="/final/development"
        prevLabel="Development Status"
      />
    </div>
  );
}

interface QuestionCardProps {
  question: string;
  delay: number;
}

function QuestionCard({ question, delay }: QuestionCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
      whileHover={{ x: 4 }}
      className="p-4 rounded-lg border cursor-pointer transition-all"
      style={{
        backgroundColor: "var(--white)",
        borderColor: "var(--divider)",
        borderWidth: "1px",
      }}
    >
      <div className="flex items-start gap-3">
        <div
          className="mt-1 w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-all"
          style={{
            borderColor: "var(--silver-accent)",
            backgroundColor: "transparent",
          }}
        ></div>
        <span style={{ color: "var(--text-primary)" }}>
          {question}
        </span>
      </div>
    </motion.div>
  );
}