import { motion } from "motion/react";
import { Link } from "react-router";
import { SLIDE_SEQUENCE } from "../config/slideNavigation";
import { FileText } from "lucide-react";

// Group slides by story arc
const STORY_PARTS = [
  {
    title: "Part 1: Foundational Overview",
    description: "The problem we solve and our architectural approach",
    slides: [1, 2, 3, 4],
  },
  {
    title: "Part 2: Conceptual Framework",
    description: "How evidence transforms into litigation leverage",
    slides: [5, 6, 7],
  },
  {
    title: "Part 3: System Execution",
    description: "The litigation lifecycle and workflow in action",
    slides: [8, 9, 10, 11],
  },
  {
    title: "Part 4: Spine & Brain Architecture",
    description: "Core system design and deep technical dives",
    slides: [12, 13, 14, 15],
  },
  {
    title: "Part 5: Technical Implementation",
    description: "How we build it with concrete technology",
    slides: [16, 17],
  },
  {
    title: "Part 6: Development & Input",
    description: "Current status and leadership feedback",
    slides: [18],
  },
];

export function PresentationIndex() {
  return (
    <div className="space-y-8 md:space-y-12">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-6"
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">
          Executive Presentation
        </h1>
        
        <div className="space-y-4 text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>
          <p>
            Complete presentation deck covering <strong>TrialForge</strong> — \n            the litigation intelligence infrastructure that transforms evidence into court-ready legal artifacts.
          </p>
          
          <div className="p-4 bg-blue-50 border-l-4 border-blue-600 rounded">
            <p className="text-sm" style={{ color: 'var(--deep-navy)' }}>
              <strong>Navigation:</strong> Click any slide below to begin. Use the Previous/Next buttons at the bottom \n              of each slide, or press <kbd className="px-2 py-1 bg-white border rounded text-xs">←</kbd> and{" "}\n              <kbd className="px-2 py-1 bg-white border rounded text-xs">→</kbd> arrow keys to navigate.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Story Parts */}
      {STORY_PARTS.map((part, partIndex) => (
        <div key={partIndex} className="space-y-3">
          <div className="space-y-1">
            <h2 
              className="text-xl md:text-2xl font-bold" 
              style={{ color: 'var(--primary-blue)' }}
            >
              {part.title}
            </h2>
            <p 
              className="text-sm md:text-base" 
              style={{ color: 'var(--text-secondary)' }}
            >
              {part.description}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {part.slides.map((slideOrder) => {
              const slide = SLIDE_SEQUENCE[slideOrder - 1];
              return (
                <Link key={slide.id} to={slide.path}>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * (slideOrder - 1) }}
                    whileHover={{ scale: 1.02, y: -4 }}
                    className="p-5 rounded-lg border-2 transition-all shadow-sm hover:shadow-md"
                    style={{
                      backgroundColor: 'var(--white)',
                      borderColor: 'var(--divider)',
                    }}
                  >
                    {/* Slide Number Badge */}
                    <div className="flex items-start gap-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ 
                          backgroundColor: 'var(--primary-blue)',
                          color: 'white',
                        }}
                      >
                        <span className="text-lg font-bold">{slide.order}</span>
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start gap-2 mb-2">
                          <FileText size={16} style={{ color: 'var(--primary-blue)', marginTop: '2px' }} />
                          <h3 
                            className="text-sm font-bold uppercase tracking-wide"
                            style={{ color: 'var(--primary-blue)' }}
                          >
                            {slide.id.toUpperCase()}
                          </h3>
                        </div>
                        <p className="text-base" style={{ color: 'var(--text-primary)' }}>
                          {slide.shortLabel}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </Link>
              );
            })}
          </div>
        </div>
      ))}

      {/* Footer Info */}
      <div className="pt-8 border-t" style={{ borderColor: 'var(--divider)' }}>
        <div className="p-5 rounded-lg" style={{ backgroundColor: 'var(--light-background)' }}>
          <h3 className="text-sm font-bold mb-3 uppercase tracking-wide" style={{ color: 'var(--primary-blue)' }}>
            Presentation Story Arc
          </h3>
          <div className="space-y-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
            <div><strong>Foundation:</strong> Start with the architectural overview and problem statement</div>
            <div><strong>Transformation:</strong> Show how evidence becomes leverage through structured analysis</div>
            <div><strong>Execution:</strong> Detail the litigation lifecycle and workflow</div>
            <div><strong>Architecture:</strong> Deep dive into Spine & Brain system design</div>
            <div><strong>Implementation:</strong> Technical architecture and technology stack</div>
            <div><strong>Development:</strong> Current status and leadership feedback</div>
          </div>
        </div>
      </div>
    </div>
  );
}