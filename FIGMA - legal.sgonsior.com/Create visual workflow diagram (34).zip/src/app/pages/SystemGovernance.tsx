import { motion } from "motion/react";
import { Shield, Lock, RotateCcw, TestTube, Fingerprint, GitBranch, AlertTriangle, CheckCircle2 } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

const governanceFeatures = [
  {
    icon: Lock,
    number: 1,
    title: "Integrity-Locked Files",
    technical: {
      heading: "What It Means (Technically)",
      content: [
        "Key system files are cryptographically hashed.",
        "If even one character changes, the system detects it."
      ]
    },
    attorney: {
      heading: "What It Means to an Attorney",
      intro: "No one can silently alter:",
      items: [
        "Cause-of-action definitions",
        "Mapping rules",
        "Audit structures",
        "Evidence schemas",
        "Output formatting rules"
      ],
      conclusion: "If something changes, it's detected."
    },
    whyCare: {
      heading: "Why They Care",
      intro: "Because:",
      items: [
        "Opposing counsel cannot argue system tampering.",
        "Internal staff cannot unknowingly alter structural rules.",
        "The firm avoids 'unknown version drift.'"
      ]
    },
    translation: "'The system prevents silent rule changes.'",
    impact: "That's malpractice risk reduction."
  },
  {
    icon: RotateCcw,
    number: 2,
    title: "Replay Equivalence Enforced",
    technical: {
      heading: "Technical Meaning",
      content: [
        "Given the same inputs, the system must produce the same outputs.",
        "If it doesn't, validation fails."
      ]
    },
    attorney: {
      heading: "Attorney Meaning",
      intro: "If we re-run a case file:",
      items: [
        "The complaint remains the same.",
        "The mapping remains the same.",
        "The deposition outline remains the same.",
        "No surprise variations."
      ]
    },
    whyCare: {
      heading: "Why They Care",
      intro: "Because reproducibility = defensibility.",
      items: [
        "'We can reproduce exactly how this document was generated.'"
      ],
      conclusion: "That's powerful in discovery disputes."
    },
    translation: "'The system guarantees reproducibility.'",
    impact: "That's defensibility."
  },
  {
    icon: TestTube,
    number: 3,
    title: "CI-Validated Contract Active",
    technical: {
      heading: "Technical Meaning",
      content: [
        "Every code change is automatically validated against the contract rules before it can be committed."
      ]
    },
    attorney: {
      heading: "Attorney Meaning",
      intro: "The system cannot evolve casually.",
      items: [
        "Changes must pass structural governance checks."
      ]
    },
    whyCare: {
      heading: "Why They Care",
      intro: "Because:",
      items: [
        "No junior developer can 'just tweak something.'",
        "The system cannot degrade over time.",
        "Governance is automated."
      ]
    },
    translation: "'No one can quietly break the system.'",
    impact: "That's automated governance."
  },
  {
    icon: Fingerprint,
    number: 4,
    title: "Deterministic Fingerprinting Enabled",
    technical: {
      heading: "Technical Meaning",
      intro: "Each system run generates a fingerprint tied to:",
      items: [
        "Inputs",
        "Rules",
        "Output state"
      ]
    },
    attorney: {
      heading: "Attorney Meaning",
      intro: "Every case instance has a verifiable digital identity.",
      items: [
        "'Was this altered?'",
        "'Was this re-run?'",
        "'Did someone modify inputs?'"
      ],
      conclusion: "You can verify."
    },
    whyCare: {
      heading: "Why They Care",
      content: [
        "Chain of custody.",
        "It mirrors evidentiary handling discipline."
      ]
    },
    translation: "'Every case has a verifiable digital identity.'",
    impact: "That's chain of custody."
  },
  {
    icon: GitBranch,
    number: 5,
    title: "Multi-Stage Validation Gates Operational",
    technical: {
      heading: "Technical Meaning",
      content: [
        "The system passes through structured checkpoints before changes are accepted."
      ]
    },
    attorney: {
      heading: "Attorney Meaning",
      intro: "There are control gates before:",
      items: [
        "Intake validation",
        "COA mapping approval",
        "Output release",
        "System updates"
      ]
    },
    whyCare: {
      heading: "Why They Care",
      intro: "Because this prevents:",
      items: [
        "Premature complaint filing",
        "Incomplete evidence mapping",
        "Unreviewed outputs"
      ]
    },
    translation: "'There are approval checkpoints at every meaningful decision.'",
    impact: "That's process control."
  }
];

function GovernanceFeatureCard({ feature, index }: { feature: typeof governanceFeatures[0]; index: number }) {
  const Icon = feature.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="p-6 md:p-8 rounded-xl border space-y-6"
      style={{
        backgroundColor: 'var(--white)',
        borderColor: 'var(--divider)',
      }}
    >
      {/* Header */}
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: 'var(--light-background)' }}>
          <Icon size={24} style={{ color: 'var(--primary-blue)' }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>
            Feature {feature.number}
          </div>
          <h3 className="text-xl md:text-2xl mb-0">{feature.title}</h3>
        </div>
      </div>

      {/* Technical Meaning */}
      <div className="space-y-3">
        <h4 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--primary-blue)' }}>
          {feature.technical.heading}
        </h4>
        <div className="space-y-2">
          {feature.technical.content?.map((text, i) => (
            <p key={i} style={{ color: 'var(--text-primary)' }}>{text}</p>
          ))}
          {feature.technical.intro && (
            <>
              <p style={{ color: 'var(--text-primary)' }}>{feature.technical.intro}</p>
              <ul className="space-y-1 ml-6">
                {feature.technical.items?.map((item, i) => (
                  <li key={i} className="list-disc" style={{ color: 'var(--text-primary)' }}>{item}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>

      {/* Attorney Meaning */}
      <div className="space-y-3 p-4 rounded-lg" style={{ backgroundColor: 'var(--light-background)' }}>
        <h4 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--deep-navy)' }}>
          {feature.attorney.heading}
        </h4>
        <div className="space-y-2">
          {feature.attorney.intro && (
            <p style={{ color: 'var(--text-primary)' }}>{feature.attorney.intro}</p>
          )}
          {feature.attorney.items && (
            <ul className="space-y-1 ml-6">
              {feature.attorney.items.map((item, i) => (
                <li key={i} className="list-disc" style={{ color: 'var(--text-primary)' }}>{item}</li>
              ))}
            </ul>
          )}
          {feature.attorney.conclusion && (
            <p className="mt-2" style={{ color: 'var(--text-primary)' }}>{feature.attorney.conclusion}</p>
          )}
        </div>
      </div>

      {/* Why They Care */}
      <div className="space-y-3">
        <h4 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--primary-blue)' }}>
          {feature.whyCare.heading}
        </h4>
        <div className="space-y-2">
          {feature.whyCare.intro && (
            <p style={{ color: 'var(--text-primary)' }}>{feature.whyCare.intro}</p>
          )}
          {feature.whyCare.content?.map((text, i) => (
            <p key={i} style={{ color: 'var(--text-primary)' }}>{text}</p>
          ))}
          {feature.whyCare.items && (
            <ul className="space-y-1 ml-6">
              {feature.whyCare.items.map((item, i) => (
                <li key={i} className="list-disc" style={{ color: 'var(--text-primary)' }}>{item}</li>
              ))}
            </ul>
          )}
          {feature.whyCare.conclusion && (
            <p className="mt-2" style={{ color: 'var(--text-primary)' }}>{feature.whyCare.conclusion}</p>
          )}
        </div>
      </div>

      {/* Translation */}
      <div className="pt-4 border-t space-y-2" style={{ borderColor: 'var(--divider)' }}>
        <div className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>
          Attorney Translation:
        </div>
        <p className="text-lg font-medium" style={{ color: 'var(--deep-navy)' }}>
          {feature.translation}
        </p>
        <p className="text-base font-semibold" style={{ color: 'var(--primary-blue)' }}>
          {feature.impact}
        </p>
      </div>
    </motion.div>
  );
}

export function SystemGovernance() {
  return (
    <div className="space-y-8 md:space-y-12">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-6"
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">System Governance</h1>
        <p className="text-lg md:text-xl" style={{ color: 'var(--text-secondary)' }}>
          Five core mechanisms that ensure integrity, reproducibility, and defensibility
        </p>
      </motion.div>

      {/* Introduction */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="p-6 md:p-8 rounded-xl border-2"
        style={{
          backgroundColor: 'var(--light-background)',
          borderColor: 'var(--primary-blue)',
        }}
      >
        <div className="flex items-start gap-4">
          <Shield size={32} className="flex-shrink-0 mt-1" style={{ color: 'var(--primary-blue)' }} />
          <div className="space-y-3 min-w-0">
            <h3 className="text-xl md:text-2xl" style={{ color: 'var(--deep-navy)' }}>Governed Legal Infrastructure</h3>
            <p className="text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>
              This is not experimental AI. This is governed legal infrastructure that behaves more like a compliance system, 
              a financial ledger, or a regulated audit environment than like a chatbot.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Five Governance Features */}
      <div className="space-y-6 md:space-y-8">
        {governanceFeatures.map((feature, index) => (
          <GovernanceFeatureCard key={feature.number} feature={feature} index={index} />
        ))}
      </div>

      {/* The Bigger Picture */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="space-y-6 p-6 md:p-8 rounded-xl"
        style={{ backgroundColor: 'var(--deep-navy)' }}
      >
        <h3 className="text-2xl md:text-3xl" style={{ color: 'var(--white)' }}>The Bigger Picture</h3>
        
        <div className="space-y-4">
          <p className="text-base md:text-lg" style={{ color: 'var(--white)', opacity: 0.9 }}>
            What all five really say:
          </p>
          
          <p className="text-xl md:text-2xl font-semibold" style={{ color: 'var(--white)' }}>
            This is not experimental AI.
          </p>
          
          <p className="text-xl md:text-2xl font-semibold" style={{ color: 'var(--white)' }}>
            This is governed legal infrastructure.
          </p>

          <div className="pt-4">
            <p className="text-base md:text-lg mb-3" style={{ color: 'var(--white)', opacity: 0.9 }}>
              It behaves more like:
            </p>
            <ul className="space-y-2 ml-6">
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--white)' }}>A compliance system</li>
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--white)' }}>A financial ledger</li>
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--white)' }}>A regulated audit environment</li>
            </ul>
          </div>

          <p className="text-base md:text-lg pt-4" style={{ color: 'var(--white)', opacity: 0.9 }}>
            Than like a chatbot.
          </p>
        </div>
      </motion.div>

      {/* The "So What" Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="space-y-6 p-6 md:p-8 rounded-xl border-2"
        style={{
          backgroundColor: 'var(--white)',
          borderColor: 'var(--primary-blue)',
        }}
      >
        <div className="flex items-start gap-4">
          <AlertTriangle size={28} className="flex-shrink-0 mt-1" style={{ color: 'var(--primary-blue)' }} />
          <div className="space-y-4 min-w-0">
            <h3 className="text-xl md:text-2xl" style={{ color: 'var(--deep-navy)' }}>The "So What" You Should Say</h3>
            <p className="text-sm md:text-base" style={{ color: 'var(--text-secondary)' }}>
              When presenting, don't list the five phrases.
            </p>
            <p className="text-base md:text-lg font-medium" style={{ color: 'var(--text-primary)' }}>
              Instead say:
            </p>
            <div className="p-4 md:p-6 rounded-lg" style={{ backgroundColor: 'var(--light-background)' }}>
              <p className="text-lg md:text-xl leading-relaxed" style={{ color: 'var(--deep-navy)' }}>
                This system prevents silent mutation, ensures reproducibility, enforces governance at every checkpoint, 
                and allows us to defend how documents were generated if ever challenged.
              </p>
            </div>
            <p className="text-base md:text-lg italic" style={{ color: 'var(--text-secondary)' }}>
              Then pause.
            </p>
            <p className="text-base md:text-lg font-semibold" style={{ color: 'var(--primary-blue)' }}>
              That lands.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Why This Matters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="space-y-6 p-6 md:p-8 rounded-xl border"
        style={{
          backgroundColor: 'var(--white)',
          borderColor: 'var(--divider)',
        }}
      >
        <div className="flex items-start gap-4">
          <CheckCircle2 size={28} className="flex-shrink-0 mt-1" style={{ color: 'var(--primary-blue)' }} />
          <div className="space-y-4 min-w-0">
            <h3 className="text-xl md:text-2xl" style={{ color: 'var(--deep-navy)' }}>Why This Matters at Managing Partner Level</h3>
            <p className="text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>
              They care about:
            </p>
            <ul className="space-y-2 ml-6">
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>Risk exposure</li>
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>Defensibility</li>
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>Firm reputation</li>
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>Operational efficiency</li>
              <li className="list-disc text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>Scalability</li>
            </ul>
            <p className="text-lg md:text-xl font-semibold pt-4" style={{ color: 'var(--primary-blue)' }}>
              These features address risk, not convenience.
            </p>
            <p className="text-base md:text-lg font-medium" style={{ color: 'var(--text-primary)' }}>
              That's the framing.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Navigation */}
      <PageNavigation />
    </div>
  );
}