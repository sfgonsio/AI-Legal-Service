import { SlideShell } from "../components/SlideShell";
import { TechStackDiagram } from "../components/slides/TechStackDiagram";

export function TechStackSlide() {
  return (
    <SlideShell
      title="Technology Stack — Litigation Infrastructure"
      subtitle="AWS-first • Deterministic Runtime • Governed AI"
    >
      <TechStackDiagram />
    </SlideShell>
  );
}
