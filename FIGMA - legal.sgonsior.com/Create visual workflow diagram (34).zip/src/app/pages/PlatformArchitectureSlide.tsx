import { SlideShell } from "../components/SlideShell";
import { PlatformArchitecture } from "../components/slides/PlatformArchitecture";

export function PlatformArchitectureSlide() {
  return (
    <SlideShell
      title="Architectural Foundation for Litigation Leverage"
      subtitle="Evidence-first. Overlay-governed. Audit-enforced. Adversarially defensible."
    >
      <PlatformArchitecture />
    </SlideShell>
  );
}
