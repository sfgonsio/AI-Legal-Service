import { CinematicVideo } from "../components/video/CinematicVideo";

export function VideoPresentation() {
  return (
    <div className="fixed inset-0 -m-4 sm:-m-6 md:-m-8 lg:-m-12">
      <CinematicVideo />
    </div>
  );
}