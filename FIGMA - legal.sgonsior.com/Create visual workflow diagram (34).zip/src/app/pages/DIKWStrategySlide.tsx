import { SlideShell } from "../components/SlideShell";
import { DIKWStrategyArchitecture } from "../components/slides/DIKWStrategyArchitecture";

export function DIKWStrategySlide() {
  return (
    <SlideShell
      title="Evidence Transformation Pipeline"
      subtitle="Hash-Verified Evidence → Rule-Evaluated Facts → Traceable Artifacts"
    >
      <DIKWStrategyArchitecture />
    </SlideShell>
  );
}
