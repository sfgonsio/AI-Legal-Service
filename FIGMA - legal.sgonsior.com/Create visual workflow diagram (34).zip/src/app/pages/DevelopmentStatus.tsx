import { motion } from "motion/react";
import { CheckCircle2, Circle, Clock } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

const completedItems = [
  "Contract validation",
  "Rerun governance",
  "Deterministic fingerprinting",
  "Replay equivalence enforcement"
];

const currentPhase = {
  title: "Application layer build following locked contract",
  description: "Implementing user interfaces and operational workflows based on validated specifications"
};

const expectation = {
  title: "UI and operational deployment after leadership validation",
  description: "Final deployment pending executive review and approval"
};

export function DevelopmentStatus() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">Development Status</h1>
        <p className="text-base md:text-lg mt-4" style={{ color: 'var(--text-secondary)' }}>
          Current implementation state and roadmap
        </p>
      </motion.div>

      {/* Completed Items */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        <h2>Completed</h2>
        <div className="space-y-3">
          {completedItems.map((item, i) => (
            <StatusItem key={i} text={item} status="completed" delay={0.1 * i} />
          ))}
        </div>
      </motion.div>

      {/* Current Phase */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="space-y-4"
      >
        <h2>Current Phase</h2>
        <PhaseCard
          icon={Clock}
          title={currentPhase.title}
          description={currentPhase.description}
          color="var(--primary-blue)"
        />
      </motion.div>

      {/* Expectation */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="space-y-4"
      >
        <h2>Expectation</h2>
        <PhaseCard
          icon={Circle}
          title={expectation.title}
          description={expectation.description}
          color="var(--silver-accent)"
        />
      </motion.div>

      {/* Timeline Visual */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="pt-8"
      >
        <div className="relative">
          <div className="absolute left-0 top-0 bottom-0 w-1 rounded-full" style={{ backgroundColor: 'var(--divider)' }} />
          <div className="absolute left-0 top-0 w-1 rounded-full transition-all duration-1000" 
            style={{ 
              backgroundColor: 'var(--primary-blue)',
              height: '60%'
            }} 
          />
          
          <div className="pl-8 space-y-8">
            <TimelineItem
              title="Foundation Phase"
              status="Complete"
              date="Q4 2025"
            />
            <TimelineItem
              title="Application Development"
              status="In Progress"
              date="Q1 2026"
            />
            <TimelineItem
              title="Leadership Review"
              status="Pending"
              date="Q1 2026"
            />
            <TimelineItem
              title="Deployment"
              status="Planned"
              date="Q2 2026"
            />
          </div>
        </div>
      </motion.div>

      <PageNavigation 
        prevLink="/final/engineering" 
        prevLabel="Engineering Foundation" 
        nextLink="/final/leadership" 
        nextLabel="Leadership Input" 
      />
    </div>
  );
}

interface StatusItemProps {
  text: string;
  status: "completed" | "in-progress" | "pending";
  delay?: number;
}

function StatusItem({ text, status, delay = 0 }: StatusItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
      className="flex items-center gap-3 p-4 rounded-lg border"
      style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}
    >
      <CheckCircle2 size={20} style={{ color: 'var(--primary-blue)' }} />
      <span style={{ color: 'var(--text-primary)' }}>{text}</span>
    </motion.div>
  );
}

interface PhaseCardProps {
  icon: React.ComponentType<{ size: number; style?: React.CSSProperties }>;
  title: string;
  description: string;
  color: string;
}

function PhaseCard({ icon: Icon, title, description, color }: PhaseCardProps) {
  return (
    <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}>
      <div className="flex items-start gap-4">
        <div className="p-3 rounded-lg flex-shrink-0" style={{ backgroundColor: 'var(--light-background)' }}>
          <Icon size={24} style={{ color }} />
        </div>
        <div>
          <h4 className="mb-2">{title}</h4>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
            {description}
          </p>
        </div>
      </div>
    </div>
  );
}

interface TimelineItemProps {
  title: string;
  status: string;
  date: string;
}

function TimelineItem({ title, status, date }: TimelineItemProps) {
  return (
    <div>
      <h4 className="mb-1">{title}</h4>
      <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--text-secondary)' }}>
        <span>{status}</span>
        <span>•</span>
        <span>{date}</span>
      </div>
    </div>
  );
}