import { SlideShell } from "../components/SlideShell";
import { LitigationWorkflowStages } from "../components/slides/LitigationWorkflowStages";

export function LitigationWorkflowSlide() {
  return (
    <SlideShell 
      title="Litigation Workflow Stages"
      subtitle="Complete 12-stage litigation lifecycle with deterministic artifact production and platform component mapping."
    >
      <LitigationWorkflowStages />
    </SlideShell>
  );
}
