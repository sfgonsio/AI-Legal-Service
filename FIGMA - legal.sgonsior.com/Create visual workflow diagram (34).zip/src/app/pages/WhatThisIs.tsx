import { motion } from "motion/react";
import { CheckCircle2, XCircle } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

export function WhatThisIs() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">What This Is</h1>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* What It Is */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <h3 className="flex items-center gap-2">
            <CheckCircle2 size={24} style={{ color: 'var(--primary-blue)' }} />
            What It Is
          </h3>
          
          <ul className="space-y-3">
            <ListItem>A workflow-governed legal intelligence system</ListItem>
            <ListItem>Deterministically structured</ListItem>
            <ListItem>Version-controlled and replay-verifiable</ListItem>
            <ListItem>Designed to reduce operational risk</ListItem>
          </ul>
        </motion.div>

        {/* What It Is Not */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-4"
        >
          <h3 className="flex items-center gap-2">
            <XCircle size={24} style={{ color: 'var(--silver-accent)' }} />
            What It Is Not
          </h3>
          
          <ul className="space-y-3">
            <ListItem muted>Not a chatbot</ListItem>
            <ListItem muted>Not uncontrolled generative AI</ListItem>
            <ListItem muted>Not autonomous legal advice</ListItem>
          </ul>
        </motion.div>
      </div>

      <PageNavigation 
        prevLink="/final/welcome" 
        prevLabel="Welcome" 
        nextLink="/final/what-this-changes" 
        nextLabel="What This Changes" 
      />
    </div>
  );
}

interface ListItemProps {
  children: React.ReactNode;
  muted?: boolean;
}

function ListItem({ children, muted }: ListItemProps) {
  return (
    <li 
      className="flex items-start gap-3 text-base"
      style={{ color: muted ? 'var(--text-secondary)' : 'var(--text-primary)' }}
    >
      <span className="mt-1.5 h-1.5 w-1.5 rounded-full flex-shrink-0" 
        style={{ backgroundColor: muted ? 'var(--silver-accent)' : 'var(--primary-blue)' }}
      />
      <span>{children}</span>
    </li>
  );
}