import { motion } from "motion/react";
import { MessageSquare, Database, FileText } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

export function CoreCapabilities() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">Core Capabilities</h1>
      </motion.div>

      <div className="space-y-8">
        <CapabilitySection
          icon={MessageSquare}
          title="Structured Intake"
          items={[
            "Guided dialogue",
            "Perspective validation",
            "Clear factual foundation"
          ]}
          delay={0.1}
        />

        <CapabilitySection
          icon={Database}
          title="Evidence Governance"
          items={[
            "Structured tagging",
            "COA alignment",
            "Artifact versioning"
          ]}
          delay={0.2}
        />

        <CapabilitySection
          icon={FileText}
          title="Controlled Output Generation"
          items={[
            "Interrogatories",
            "Subpoenas",
            "Deposition outlines",
            "Structured reports"
          ]}
          delay={0.3}
        />
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="p-4 md:p-6 rounded-lg border-l-4 mt-8 md:mt-12"
        style={{
          backgroundColor: 'var(--white)',
          borderColor: 'var(--primary-blue)',
        }}
      >
        <p className="text-base md:text-lg" style={{ color: 'var(--primary-blue)' }}>
          <strong>All outputs traceable to structured inputs.</strong>
        </p>
      </motion.div>

      <PageNavigation 
        prevLink="/final/what-this-changes" 
        prevLabel="What This Changes" 
        nextLink="/final/workflow" 
        nextLabel="Workflow" 
      />
    </div>
  );
}

interface CapabilitySectionProps {
  icon: React.ComponentType<{ size: number; style?: React.CSSProperties }>;
  title: string;
  items: string[];
  delay: number;
}

function CapabilitySection({ icon: Icon, title, items, delay }: CapabilitySectionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="p-6 md:p-8 rounded-lg border"
      style={{
        backgroundColor: 'var(--white)',
        borderColor: 'var(--divider)',
      }}
    >
      <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
        <div 
          className="p-2 md:p-3 rounded-lg"
          style={{ backgroundColor: 'var(--light-background)' }}
        >
          <Icon size={24} className="md:w-7 md:h-7" style={{ color: 'var(--primary-blue)' }} />
        </div>
        <h2 className="text-xl md:text-2xl">{title}</h2>
      </div>
      
      <ul className="space-y-3">
        {items.map((item, index) => (
          <li 
            key={index}
            className="flex items-center gap-3 text-base"
            style={{ color: 'var(--text-primary)' }}
          >
            <span 
              className="h-2 w-2 rounded-full flex-shrink-0"
              style={{ backgroundColor: 'var(--primary-blue)' }}
            />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
}