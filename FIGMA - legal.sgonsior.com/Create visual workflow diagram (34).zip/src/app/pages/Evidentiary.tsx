import { motion } from "motion/react";
import { Shield, FileCheck, RotateCcw, Lock } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

export function Evidentiary() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">Evidentiary Defensibility</h1>
        <p className="text-base md:text-lg mt-4" style={{ color: 'var(--text-secondary)' }}>
          Verifiable traceability from intake to output
        </p>
      </motion.div>

      {/* Core Principles */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid gap-4"
      >
        <PrincipleCard
          icon={FileCheck}
          title="Each output can be reproduced"
          description="Deterministic processing ensures identical results given the same inputs"
        />
        <PrincipleCard
          icon={Lock}
          title="Each transition is governed"
          description="State changes require explicit authorization and are logged"
        />
        <PrincipleCard
          icon={RotateCcw}
          title="Each rerun is controlled"
          description="Version control prevents unauthorized modifications"
        />
      </motion.div>

      <div className="h-px" style={{ backgroundColor: 'var(--divider)' }} />

      {/* Defensibility Benefits */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="space-y-6"
      >
        <h2>Defensibility Through Structure</h2>
        
        <div className="p-8 rounded-lg border" style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}>
          <div className="space-y-6">
            <DefensibilityPoint
              number="1"
              title="Traceable Artifacts"
              description="Every document, evidence file, and generated output maintains a clear provenance chain linking it to its source material and creation context."
            />
            <DefensibilityPoint
              number="2"
              title="Immutable Audit Trail"
              description="All actions, decisions, and state transitions are recorded in an append-only log that cannot be altered retroactively."
            />
            <DefensibilityPoint
              number="3"
              title="Reproducible Results"
              description="Any output can be regenerated with identical results by replaying the same inputs through the same workflow version."
            />
            <DefensibilityPoint
              number="4"
              title="Clear Decision Points"
              description="Human approval gates are explicitly marked and require attorney authorization before proceeding."
            />
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="p-6 rounded-lg border-l-4"
        style={{
          backgroundColor: 'var(--white)',
          borderColor: 'var(--primary-blue)',
        }}
      >
        <div className="flex items-start gap-4">
          <Shield size={32} style={{ color: 'var(--primary-blue)' }} />
          <div>
            <h4 className="mb-2">Operational Speed Without Sacrificing Defensibility</h4>
            <p className="text-base" style={{ color: 'var(--text-secondary)' }}>
              The system enables rapid case processing while maintaining the rigorous 
              documentation standards required for professional responsibility and litigation defense.
            </p>
          </div>
        </div>
      </motion.div>

      <PageNavigation 
        prevLink="/final/agent-program-map" 
        prevLabel="Agent → Program Map" 
        nextLink="/final/engineering" 
        nextLabel="Engineering Foundation" 
      />
    </div>
  );
}

interface PrincipleCardProps {
  icon: React.ComponentType<{ size: number; style?: React.CSSProperties }>;
  title: string;
  description: string;
}

function PrincipleCard({ icon: Icon, title, description }: PrincipleCardProps) {
  return (
    <motion.div
      whileHover={{ x: 4 }}
      className="p-6 rounded-lg border flex items-start gap-4"
      style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}
    >
      <div className="p-3 rounded-lg flex-shrink-0" style={{ backgroundColor: 'var(--light-background)' }}>
        <Icon size={24} style={{ color: 'var(--primary-blue)' }} />
      </div>
      <div>
        <h4 className="mb-2">{title}</h4>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          {description}
        </p>
      </div>
    </motion.div>
  );
}

interface DefensibilityPointProps {
  number: string;
  title: string;
  description: string;
}

function DefensibilityPoint({ number, title, description }: DefensibilityPointProps) {
  return (
    <div className="flex items-start gap-4">
      <div
        className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center"
        style={{ backgroundColor: 'var(--primary-blue)', color: 'var(--white)' }}
      >
        <strong>{number}</strong>
      </div>
      <div>
        <h4 className="mb-2">{title}</h4>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          {description}
        </p>
      </div>
    </div>
  );
}