import { SlideShell } from "../components/SlideShell";
import { BrainArchitectureDetailDiagram } from "../components/slides/BrainArchitectureDetailDiagram";

export function BrainArchitectureDetailSlide() {
  return (
    <SlideShell
      title="The Brain Architecture"
      subtitle="Legal Reasoning Center — Three Specialized Cognitive Lobes"
    >
      <BrainArchitectureDetailDiagram />
    </SlideShell>
  );
}
