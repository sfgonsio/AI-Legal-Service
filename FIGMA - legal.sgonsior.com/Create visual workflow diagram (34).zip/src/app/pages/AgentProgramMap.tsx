import { motion } from "motion/react";
import { Users, Cpu, GitBranch, Database, Lock } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";
import { TermDefinition } from "../components/TermDefinition";

const agents = [
  {
    name: "Interview Agent",
    soWhat: [
      "Establishes factual clarity before downstream processing",
      "Reduces intake ambiguity",
      "Creates defensible factual baseline"
    ]
  },
  {
    name: "Evidence Processing Agent",
    soWhat: [
      "Structures and timestamps artifacts",
      "Preserves traceability",
      "Reduces evidentiary chaos"
    ]
  },
  {
    name: "Mapping Agent",
    soWhat: [
      "Aligns evidence to COA elements",
      "Strengthens pleading defensibility"
    ]
  },
  {
    name: "Output Construction Agent",
    soWhat: [
      "Generates structured outputs tied to mapped evidence",
      "Preserves alignment"
    ]
  }
];

export function AgentProgramMap() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">Agent → Program Map</h1>
        <p className="text-base md:text-lg mt-4" style={{ color: 'var(--text-secondary)' }}>
          Specialized agents mapped to deterministic programs
        </p>
      </motion.div>

      {/* Layer 1: Human Governance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="space-y-4"
      >
        <LayerHeader icon={Users} title="Layer 1 — Human Governance" color="var(--primary-blue)" />
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {["Case Acceptance", "Intake Validation", "COA Approval", "Complaint Approval", "Output Review", "Rerun Authorization"].map((item, i) => (
            <GovernanceItem key={i} text={item} />
          ))}
        </div>
      </motion.div>

      {/* Layer 2: Workflow Orchestration */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        <LayerHeader icon={GitBranch} title="Layer 2 — Workflow Orchestration" color="var(--primary-blue)" />
        <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}>
          <ul className="space-y-2">
            <li style={{ color: 'var(--text-primary)' }}>
              •{" "}
              <TermDefinition 
                term="State Machine Controller"
                definition="Orchestrates workflow transitions between stages, ensuring each stage completes successfully before advancing to the next. Maintains deterministic execution paths."
                variant="underline"
              />
            </li>
            <li style={{ color: 'var(--text-primary)' }}>
              •{" "}
              <TermDefinition 
                term="Versioned transitions"
                definition="Each workflow transition is tracked with version information, allowing historical reconstruction of how cases progressed through the system."
                variant="inline"
              />
            </li>
            <li style={{ color: 'var(--text-primary)' }}>
              •{" "}
              <TermDefinition 
                term="Controlled reruns"
                definition="Ability to re-execute specific workflow stages with human authorization, while maintaining audit trails of all execution attempts."
                variant="inline"
              />
            </li>
          </ul>
        </div>
      </motion.div>

      {/* Layer 3: Agents */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="space-y-4"
      >
        <LayerHeader icon={Cpu} title="Layer 3 — Agents" color="var(--primary-blue)" />
        <div className="grid md:grid-cols-2 gap-6">
          {agents.map((agent, i) => (
            <AgentCard key={i} name={agent.name} soWhat={agent.soWhat} />
          ))}
        </div>
      </motion.div>

      {/* Layer 4: Evidentiary Structure */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="space-y-4"
      >
        <LayerHeader icon={Database} title="Layer 4 — Evidentiary Structure" color="var(--primary-blue)" />
        <div className="p-8 rounded-lg border text-center" style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}>
          <div className="flex items-center justify-center gap-4 flex-wrap text-lg" style={{ color: 'var(--primary-blue)' }}>
            <strong>Facts</strong>
            <span>→</span>
            <strong>Evidence</strong>
            <span>→</span>
            <strong>COA Elements</strong>
            <span>→</span>
            <strong>Complaint Sections</strong>
          </div>
          <p className="mt-4 text-sm" style={{ color: 'var(--text-secondary)' }}>
            Every output traceable to originating artifact
          </p>
        </div>
      </motion.div>

      {/* Layer 5: Integrity & Audit */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="space-y-4"
      >
        <LayerHeader icon={Lock} title="Layer 5 — Integrity & Audit" color="var(--primary-blue)" />
        <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <ul className="space-y-2">
                <li style={{ color: 'var(--text-primary)' }}>• Manifest enforcement</li>
                <li style={{ color: 'var(--text-primary)' }}>• Fingerprint validation</li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2">
                <li style={{ color: 'var(--text-primary)' }}>• Replay equivalence</li>
                <li style={{ color: 'var(--text-primary)' }}>• Append-only audit</li>
              </ul>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t" style={{ borderColor: 'var(--divider)' }}>
            <span className="inline-block px-4 py-2 rounded-full text-sm" style={{ backgroundColor: 'var(--light-background)', color: 'var(--primary-blue)' }}>
              <strong>Prevents silent mutation</strong>
            </span>
          </div>
        </div>
      </motion.div>

      <PageNavigation 
        prevLink="/final/workflow" 
        prevLabel="Workflow" 
        nextLink="/final/evidentiary" 
        nextLabel="Evidentiary Defensibility" 
      />
    </div>
  );
}

interface LayerHeaderProps {
  icon: React.ComponentType<{ size: number; style?: React.CSSProperties }>;
  title: string;
  color: string;
}

function LayerHeader({ icon: Icon, title, color }: LayerHeaderProps) {
  return (
    <div className="flex items-center gap-3">
      <Icon size={24} style={{ color }} />
      <h2>{title}</h2>
    </div>
  );
}

function GovernanceItem({ text }: { text: string }) {
  return (
    <div
      className="p-3 rounded-lg border text-center text-sm"
      style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)', color: 'var(--text-primary)' }}
    >
      {text}
    </div>
  );
}

interface AgentCardProps {
  name: string;
  soWhat: string[];
}

function AgentCard({ name, soWhat }: AgentCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="p-6 rounded-lg border"
      style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}
    >
      <h4 className="mb-4">{name}</h4>
      <div className="space-y-2">
        <p className="text-xs uppercase tracking-wider" style={{ color: 'var(--silver-accent)' }}>So What:</p>
        <ul className="space-y-2">
          {soWhat.map((item, i) => (
            <li key={i} className="text-sm flex items-start gap-2" style={{ color: 'var(--text-secondary)' }}>
              <span className="mt-1.5 h-1.5 w-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: 'var(--primary-blue)' }} />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </motion.div>
  );
}