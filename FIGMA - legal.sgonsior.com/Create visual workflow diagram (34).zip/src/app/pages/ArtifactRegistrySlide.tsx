import { SlideShell } from "../components/SlideShell";
import { CanonicalArtifactRegistry } from "../components/slides/CanonicalArtifactRegistry";

export function ArtifactRegistrySlide() {
  return (
    <SlideShell 
      title="Canonical Artifact Registry"
      subtitle="Comprehensive catalog of litigation artifacts organized by class with lifecycle stage and deterministic pipeline mappings."
    >
      <CanonicalArtifactRegistry />
    </SlideShell>
  );
}
