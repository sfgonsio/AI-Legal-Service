import { motion } from "motion/react";
import { ArrowRight, Presentation } from "lucide-react";
import { Link } from "react-router";
import { PageNavigation } from "../components/PageNavigation";

export function Welcome() {
  return (
    <div className="space-y-8 md:space-y-12">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">TrialForge</h1>
        <p className="text-xl md:text-2xl font-semibold" style={{ color: 'var(--slide-royal-blue)' }}>
          Where Evidence Becomes Strategy
        </p>
        
        <div className="space-y-4 text-base md:text-lg" style={{ color: 'var(--text-primary)' }}>
          <p>
            Legal practice depends on clarity, discipline, and trust.
          </p>
          
          <p>
            As cases grow more complex and evidence volumes expand, the firm must rely on 
            infrastructure that preserves knowledge, governs workflow, and protects defensibility.
          </p>
          
          <p>
            This initiative establishes a <strong>structured legal intelligence foundation</strong> — 
            engineered for discipline, not experimentation.
          </p>
          
          <p className="pt-4" style={{ color: 'var(--primary-blue)' }}>
            <strong>It becomes the knowledge backbone of the practice.</strong>
          </p>
        </div>

        {/* Presentation CTA */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Link to="/final/presentation">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-3 px-6 py-4 rounded-lg border-2 transition-all"
              style={{
                borderColor: 'var(--primary-blue)',
                backgroundColor: 'var(--primary-blue)',
                color: 'var(--white)',
              }}
            >
              <Presentation size={24} />
              <span className="text-base md:text-lg" style={{ fontWeight: '600' }}>
                View Executive Presentation (18 Slides)
              </span>
              <ArrowRight size={20} />
            </motion.div>
          </Link>
        </motion.div>
      </motion.div>

      {/* Visual Divider */}
      <div className="h-px" style={{ backgroundColor: 'var(--divider)' }} />

      {/* Key Principles */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6"
      >
        <PrincipleCard
          title="Clarity"
          description="Structured intake creates factual foundations"
        />
        <PrincipleCard
          title="Discipline"
          description="Governed workflows ensure consistency"
        />
        <PrincipleCard
          title="Trust"
          description="Evidentiary traceability protects defensibility"
        />
      </motion.div>

      {/* Call to Action */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="pt-8"
      >
        <Link to="/final/what-this-is">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="px-8 py-4 rounded-lg flex items-center gap-3 transition-all"
            style={{
              backgroundColor: 'var(--primary-blue)',
              color: 'var(--white)',
            }}
          >
            <span>Explore the System</span>
            <ArrowRight size={20} />
          </motion.button>
        </Link>
      </motion.div>

      <PageNavigation nextLink="/final/what-this-is" nextLabel="What This Is" />
    </div>
  );
}

interface PrincipleCardProps {
  title: string;
  description: string;
}

function PrincipleCard({ title, description }: PrincipleCardProps) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="p-6 rounded-lg border transition-all"
      style={{
        backgroundColor: 'var(--white)',
        borderColor: 'var(--divider)',
      }}
    >
      <h4 className="mb-2">{title}</h4>
      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
        {description}
      </p>
    </motion.div>
  );
}