import { SlideShell } from "../components/SlideShell";
import { LitigationWorkflowMap } from "../components/slides/LitigationWorkflowMap";

export function WorkflowMapSlide() {
  return (
    <SlideShell 
      title="TrialForge Litigation Workflow Map"
      subtitle="Comprehensive case lifecycle support from client intake through post-trial appeals, powered by the TrialForge intelligence engine."
    >
      <LitigationWorkflowMap />
    </SlideShell>
  );
}
