import { SlideShell } from "../components/SlideShell";
import { FiveLayerStackArchitectureDiagram } from "../components/slides/FiveLayerStackArchitectureDiagram";

export function FiveLayerStackSlide() {
  return (
    <SlideShell
      title="Five-Layer Stack Architecture"
      subtitle="Governed Litigation Reasoning System — Spine • Data Graph • Programs • Agents • UI"
    >
      <FiveLayerStackArchitectureDiagram />
    </SlideShell>
  );
}
