import { SlideShell } from "../components/SlideShell";
import { LitigationEngineArchitecture } from "../components/slides/LitigationEngineArchitecture";

export function LitigationEngineSlide() {
  return (
    <SlideShell 
      title="Evidence-Driven Litigation Lifecycle"
      subtitle="Governed intelligence from evidence capture to court-ready artifacts."
    >
      <LitigationEngineArchitecture />
    </SlideShell>
  );
}
