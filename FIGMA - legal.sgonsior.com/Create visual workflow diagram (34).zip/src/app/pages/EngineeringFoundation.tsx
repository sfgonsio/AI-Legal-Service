import { motion } from "motion/react";
import { useState } from "react";
import { ChevronRight, ChevronDown, Folder, File, CheckCircle2 } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

const fileTree = {
  name: "contract/",
  type: "folder",
  children: [
    {
      name: "v1/",
      type: "folder",
      children: [
        { name: "acceptance/", type: "folder", children: [] },
        { name: "orchestration/", type: "folder", children: [] },
        { name: "schemas/", type: "folder", children: [] },
        { name: "harness/", type: "folder", children: [] },
        { name: "tools/", type: "folder", children: [] },
        { name: "policy/", type: "folder", children: [] },
      ]
    }
  ]
};

const confidenceMetrics = [
  { label: "Integrity-locked files", value: "17+" },
  { label: "Replay equivalence", value: "Enforced" },
  { label: "CI-validated contract", value: "Active" },
  { label: "Deterministic fingerprinting", value: "Enabled" },
  { label: "Multi-stage validation gates", value: "Operational" },
];

export function EngineeringFoundation() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">Engineering Foundation</h1>
        <p className="text-base md:text-lg mt-4" style={{ color: 'var(--text-secondary)' }}>
          Disciplined architecture for legal infrastructure
        </p>
      </motion.div>

      {/* File Tree */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        <h2>Project Structure</h2>
        <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}>
          <FileTreeNode node={fileTree} level={0} />
        </div>
      </motion.div>

      {/* Confidence Metrics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="space-y-4"
      >
        <h2>Confidence Metrics</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {confidenceMetrics.map((metric, i) => (
            <MetricCard key={i} label={metric.label} value={metric.value} />
          ))}
        </div>
      </motion.div>

      {/* Key Insight */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="p-6 rounded-lg border-l-4"
        style={{
          backgroundColor: 'var(--white)',
          borderColor: 'var(--primary-blue)',
        }}
      >
        <p className="text-base" style={{ color: 'var(--primary-blue)' }}>
          <strong>This infrastructure ensures the application can be built without interpretation drift.</strong>
        </p>
        <p className="text-sm mt-2" style={{ color: 'var(--text-secondary)' }}>
          Version-locked contracts, deterministic validation, and multi-stage gates eliminate ambiguity 
          in the development process.
        </p>
      </motion.div>

      <PageNavigation 
        prevLink="/final/evidentiary" 
        prevLabel="Evidentiary Defensibility" 
        nextLink="/final/development" 
        nextLabel="Development Status" 
      />
    </div>
  );
}

interface FileTreeNodeProps {
  node: any;
  level: number;
}

function FileTreeNode({ node, level }: FileTreeNodeProps) {
  const [isOpen, setIsOpen] = useState(level === 0);
  const isFolder = node.type === "folder";
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div>
      <motion.div
        whileHover={{ x: 2 }}
        className="flex items-center gap-2 py-1 cursor-pointer"
        style={{ paddingLeft: `${level * 20}px` }}
        onClick={() => isFolder && setIsOpen(!isOpen)}
      >
        {isFolder && hasChildren && (
          <span style={{ color: 'var(--text-secondary)' }}>
            {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
          </span>
        )}
        {isFolder ? (
          <Folder size={16} style={{ color: 'var(--primary-blue)' }} />
        ) : (
          <File size={16} style={{ color: 'var(--silver-accent)' }} />
        )}
        <span className="text-sm" style={{ color: 'var(--text-primary)' }}>
          {node.name}
        </span>
      </motion.div>
      
      {isFolder && isOpen && hasChildren && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          transition={{ duration: 0.3 }}
        >
          {node.children.map((child: any, i: number) => (
            <FileTreeNode key={i} node={child} level={level + 1} />
          ))}
        </motion.div>
      )}
    </div>
  );
}

interface MetricCardProps {
  label: string;
  value: string;
}

function MetricCard({ label, value }: MetricCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="p-4 rounded-lg border flex items-center gap-3"
      style={{ backgroundColor: 'var(--white)', borderColor: 'var(--divider)' }}
    >
      <CheckCircle2 size={20} style={{ color: 'var(--primary-blue)' }} />
      <div>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{label}</p>
        <p className="font-semibold" style={{ color: 'var(--primary-blue)' }}>{value}</p>
      </div>
    </motion.div>
  );
}