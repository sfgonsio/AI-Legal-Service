import { SlideShell } from "../components/SlideShell";
import { ArtifactProductionMatrix } from "../components/slides/ArtifactProductionMatrix";

export function ArtifactMatrixSlide() {
  return (
    <SlideShell 
      title="Artifact Production Matrix"
      subtitle="SIPOC workflow mapping showing supplier, inputs, process, output, and consumer for each litigation artifact with platform component assignments."
    >
      <ArtifactProductionMatrix />
    </SlideShell>
  );
}
