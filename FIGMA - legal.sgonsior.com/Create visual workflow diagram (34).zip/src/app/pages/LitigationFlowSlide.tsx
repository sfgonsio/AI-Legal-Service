import { SlideShell } from "../components/SlideShell";
import { LitigationIntelligenceFlow } from "../components/slides/LitigationIntelligenceFlow";

export function LitigationFlowSlide() {
  return (
    <SlideShell 
      title="TrialForge Intelligence Flow"
      subtitle="Dynamic transformation showing how a single piece of evidence becomes court-ready litigation artifacts through seven processing stages."
    >
      <LitigationIntelligenceFlow />
    </SlideShell>
  );
}