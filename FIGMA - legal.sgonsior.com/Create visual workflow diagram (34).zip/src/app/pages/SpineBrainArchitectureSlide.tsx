import { SlideShell } from "../components/SlideShell";
import { SpineBrainArchitectureDiagram } from "../components/slides/SpineBrainArchitectureDiagram";

export function SpineBrainArchitectureSlide() {
  return (
    <SlideShell
      title="The Spine & Brain Architecture"
      subtitle="Legal Intelligence System — Biological Metaphor for Connected Reasoning"
    >
      <SpineBrainArchitectureDiagram />
    </SlideShell>
  );
}
