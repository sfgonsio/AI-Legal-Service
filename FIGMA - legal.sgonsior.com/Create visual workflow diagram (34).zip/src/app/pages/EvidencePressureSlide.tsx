import { SlideShell } from "../components/SlideShell";
import { EvidencePressureModel } from "../components/slides/EvidencePressureModel";

export function EvidencePressureSlide() {
  return (
    <SlideShell
      title="Engineering Admissibility Leverage"
      subtitle="Every output survives structured scrutiny."
    >
      <EvidencePressureModel />
    </SlideShell>
  );
}
