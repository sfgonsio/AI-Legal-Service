import { SlideShell } from "../components/SlideShell";
import { LitigationIntelligenceEngine } from "../components/slides/LitigationIntelligenceEngine";

export function LitigationIntelligenceSlide() {
  return (
    <SlideShell 
      title="TrialForge Intelligence Engine"
      subtitle="Five-layer intelligence architecture transforming evidence into court-ready litigation artifacts through structured processing."
    >
      <LitigationIntelligenceEngine />
    </SlideShell>
  );
}