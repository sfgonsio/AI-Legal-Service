import { SlideShell } from "../components/SlideShell";
import { LitigationLeverageDiagram } from "../components/LitigationLeverageDiagram";

export function DataArchitectureSlide() {
  return (
    <SlideShell
      title="Litigation Leverage Infrastructure"
      subtitle="Evidence-Centered. Rule-Evaluated. Strategically Traceable."
    >
      <LitigationLeverageDiagram />
    </SlideShell>
  );
}
