import { motion } from "motion/react";
import { TrendingUp, Zap, FileCheck, Shield, Brain, Maximize } from "lucide-react";
import { PageNavigation } from "../components/PageNavigation";

export function WhatThisChanges() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">What This Changes</h1>
      </motion.div>

      <div className="h-px" style={{ backgroundColor: 'var(--divider)' }} />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="space-y-6"
      >
        <h2>Operational Advantages</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <AdvantageCard
            icon={Zap}
            title="Faster Complaint Drafting"
            description="Structured inputs enable rapid output generation"
          />
          <AdvantageCard
            icon={FileCheck}
            title="Faster Deposition Preparation"
            description="Evidence mapping accelerates case readiness"
          />
          <AdvantageCard
            icon={TrendingUp}
            title="Reduced Rework"
            description="Version control prevents drift and duplication"
          />
          <AdvantageCard
            icon={Brain}
            title="Reduced Ambiguity"
            description="Clear workflow states eliminate confusion"
          />
          <AdvantageCard
            icon={Shield}
            title="Improved Defensibility"
            description="Traceable artifacts strengthen legal positions"
          />
          <AdvantageCard
            icon={Maximize}
            title="Greater Scalability"
            description="Repeatable processes enable firm growth"
          />
        </div>
      </motion.div>

      <PageNavigation 
        prevLink="/final/what-this-is" 
        prevLabel="What This Is" 
        nextLink="/final/core-capabilities" 
        nextLabel="Core Capabilities" 
      />
    </div>
  );
}

interface AdvantageCardProps {
  icon: React.ComponentType<{ size: number; style?: React.CSSProperties }>;
  title: string;
  description: string;
}

function AdvantageCard({ icon: Icon, title, description }: AdvantageCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="p-6 rounded-lg border"
      style={{
        backgroundColor: 'var(--white)',
        borderColor: 'var(--divider)',
      }}
    >
      <Icon size={32} style={{ color: 'var(--primary-blue)', marginBottom: '12px' }} />
      <h4 className="mb-2">{title}</h4>
      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
        {description}
      </p>
    </motion.div>
  );
}