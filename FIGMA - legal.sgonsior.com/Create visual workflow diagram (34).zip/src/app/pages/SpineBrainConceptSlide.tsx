import { SlideShell } from "../components/SlideShell";
import { SpineBrainNarrative } from "../components/slides/SpineBrainNarrative";

export function SpineBrainConceptSlide() {
  return (
    <SlideShell
      title="The Spine & Brain Concept"
      subtitle="Connecting People, AI Agents, and Deterministic Programs"
    >
      <SpineBrainNarrative />
    </SlideShell>
  );
}
