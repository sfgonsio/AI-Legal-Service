import { motion } from "motion/react";
import { PageNavigation } from "../components/PageNavigation";
import { WorkflowDiagram } from "../components/WorkflowDiagram";
import { TermDefinition } from "../components/TermDefinition";

export function Workflow() {
  return (
    <div className="space-y-8 md:space-y-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h1 className="text-3xl md:text-4xl lg:text-5xl">Workflow</h1>
        <p className="text-base md:text-lg mt-4" style={{ color: 'var(--text-secondary)' }}>
          From case intake to legal deliverables — how{" "}
          <TermDefinition 
            term="human judgment"
            definition="Attorney expertise in legal strategy, case evaluation, and final authorization of work products"
            variant="inline"
          />
          ,{" "}
          <TermDefinition 
            term="AI agents"
            definition="Specialized components that perform structured legal tasks like intake interviews, document analysis, and evidence mapping"
            variant="inline"
          />
          , and{" "}
          <TermDefinition 
            term="governed programs"
            definition="Deterministic systems that enforce state transitions, maintain audit trails, and ensure evidentiary defensibility"
            variant="inline"
          />{" "}
          work together
        </p>
      </motion.div>

      {/* Interactive Workflow Diagram */}
      <WorkflowDiagram />

      <PageNavigation 
        prevLink="/final/core-capabilities" 
        prevLabel="Core Capabilities" 
        nextLink="/final/agent-program-map" 
        nextLabel="Agent → Program Map" 
      />
    </div>
  );
}