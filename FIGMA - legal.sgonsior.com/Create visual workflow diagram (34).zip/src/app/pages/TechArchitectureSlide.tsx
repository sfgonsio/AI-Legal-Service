import { SlideShell } from "../components/SlideShell";
import { TechArchitectureDiagram } from "../components/slides/TechArchitectureDiagram";

export function TechArchitectureSlide() {
  return (
    <SlideShell
      title="Conceptual Technology Architecture Framework — Overall"
      subtitle="Evidence-Centered Litigation Infrastructure"
    >
      <TechArchitectureDiagram />
    </SlideShell>
  );
}
