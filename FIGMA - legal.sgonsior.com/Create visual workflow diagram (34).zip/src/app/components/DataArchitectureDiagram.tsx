import { motion } from "motion/react";
import { useState } from "react";

interface ArchitectureStage {
  topLabel: string;
  title: string;
  summary: string;
  controls: string[];
  detailedDescription: string;
  inputSource: string;
  outputDeliverable: string;
}

const architectureStages: ArchitectureStage[] = [
  {
    topLabel: "DATA",
    title: "EVIDENCE\nCAPTURE",
    summary: "Raw evidence enters the platform with cryptographic fingerprinting and chain of custody initialization.",
    controls: [
      "Hash Verification",
      "Deterministic Execution",
      "Overlay Governance"
    ],
    detailedDescription: "All incoming evidence—emails, documents, testimony transcripts—is captured with cryptographic fingerprints at the moment of acquisition. No evidence enters the system without a hash baseline that locks its state.",
    inputSource: "Client documents, discovery materials, witness statements",
    outputDeliverable: "Immutable evidence registry with hash-verified baseline"
  },
  {
    topLabel: "INFORMATION",
    title: "STRUCTURED\nPARSING",
    summary: "Evidence packets are parsed into structured semantic units while preserving bidirectional source references.",
    controls: [
      "Schema Validated",
      "Chunk UID Created",
      "Replay Equivalent"
    ],
    detailedDescription: "Evidence is parsed into structured units—parties, dates, events, claims—while maintaining bidirectional references to source documents. Every extracted fact points back to its origin.",
    inputSource: "Hash-verified evidence registry",
    outputDeliverable: "Structured fact graph with source citations"
  },
  {
    topLabel: "KNOWLEDGE",
    title: "RULE\nEVALUATION",
    summary: "CA Evidence Code overlays evaluate structured facts for relevance, authentication, hearsay, and privilege.",
    controls: [
      "Audit Logging",
      "Replay Equivalence",
      "Deterministic Execution"
    ],
    detailedDescription: "When multiple sources describe the same event differently, the system flags contradictions and constructs a weighted timeline showing competing narratives. Attorneys resolve conflicts with explicit decisions recorded in audit trail.",
    inputSource: "Structured fact graph",
    outputDeliverable: "Reconciled event timeline with attorney resolutions"
  },
  {
    topLabel: "LEGAL KNOWLEDGE",
    title: "ELEMENT\nMAPPING",
    summary: "Rule-evaluated facts are mapped to cause-of-action elements with evidentiary support analysis.",
    controls: [
      "Hash Verification",
      "Deterministic Execution",
      "Overlay Governance"
    ],
    detailedDescription: "The system maps normalized facts to legal elements required for each cause of action. Attorneys see which elements have sufficient evidentiary support and which require additional discovery.",
    inputSource: "Reconciled event timeline",
    outputDeliverable: "Element-to-evidence matrix with coverage analysis"
  },
  {
    topLabel: "STRATEGIC OUTPUTS",
    title: "ARTIFACT\nGENERATION",
    summary: "Court-ready documents generated with complete citation chains traceable to original source evidence.",
    controls: [
      "Schema Validated",
      "Chunk UID Created", 
      "Replay Equivalent"
    ],
    detailedDescription: "Complaints, briefs, and discovery responses are generated with embedded citations to the evidence chain. Every assertion is traceable back through the transformation pipeline to the original source document hash.",
    inputSource: "Element-to-evidence matrix",
    outputDeliverable: "Court filings with complete evidentiary audit trail"
  }
];

export function DataArchitectureDiagram() {
  const [selectedStage, setSelectedStage] = useState<number | null>(null);

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Top Governance Band */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="w-full rounded-lg md:rounded-xl flex flex-col items-center justify-center text-center py-4 md:py-5 px-4 md:px-8"
        style={{
          backgroundColor: '#000033',
          minHeight: '80px'
        }}
      >
        <p className="text-xs md:text-sm font-bold uppercase tracking-widest mb-1.5" style={{ color: '#FFFFFF' }}>
          CASE-BOUND EVIDENCE TRANSFORMATION
        </p>
        <p className="text-[10px] md:text-xs" style={{ color: '#FFFFFF', opacity: 0.85 }}>
          Immutable • Deterministic • Hash-Verified • Overlay-Enforced
        </p>
      </motion.div>

      {/* Primary Visual - Five Column Architecture */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="w-full rounded-lg md:rounded-xl border overflow-hidden"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#C0C5CE'
        }}
      >
        {/* Desktop: 5 columns side-by-side, Mobile/Tablet: Stack vertically */}
        <div className="flex flex-col lg:grid lg:grid-cols-5 lg:divide-x divide-y lg:divide-y-0" style={{ borderColor: '#C0C5CE' }}>
          {architectureStages.map((stage, index) => (
            <div
              key={index}
              onMouseEnter={() => setSelectedStage(index)}
              onMouseLeave={() => setSelectedStage(null)}
              className="cursor-pointer transition-all duration-200"
              style={{
                backgroundColor: selectedStage === index ? '#F4F6F8' : 'transparent'
              }}
            >
              {/* Column Content */}
              <div className="p-6 md:p-8 lg:p-10 flex flex-col h-full lg:min-h-[560px]">
                {/* Top Label */}
                <p 
                  className="text-[10px] md:text-xs font-semibold uppercase tracking-widest mb-4 md:mb-6" 
                  style={{ color: '#000033', opacity: 0.6 }}
                >
                  {stage.topLabel}
                </p>

                {/* Stage Title */}
                <h4 
                  className="text-sm md:text-base font-bold uppercase mb-4 md:mb-6 whitespace-pre-line" 
                  style={{ 
                    color: '#000033', 
                    lineHeight: '1.3'
                  }}
                >
                  {stage.title}
                </h4>

                {/* Summary */}
                <div className="mb-6 md:mb-8">
                  <p 
                    className="text-xs md:text-sm" 
                    style={{ 
                      color: '#4A5568', 
                      lineHeight: '1.6'
                    }}
                  >
                    {stage.summary}
                  </p>
                </div>

                {/* Controls Section */}
                <div className="mt-auto pt-4 border-t" style={{ borderColor: '#E2E8F0' }}>
                  <p 
                    className="text-[10px] md:text-xs font-semibold uppercase tracking-wide mb-4" 
                    style={{ color: '#000033', opacity: 0.6 }}
                  >
                    CONTROLS APPLIED
                  </p>
                  
                  {/* Three Bullets */}
                  <div className="space-y-3 md:space-y-4">
                    {stage.controls.map((control, controlIndex) => (
                      <div 
                        key={controlIndex} 
                        className="flex items-start gap-2.5 md:gap-3"
                      >
                        <div 
                          className="rounded-full flex-shrink-0"
                          style={{ 
                            width: '6px', 
                            height: '6px', 
                            backgroundColor: '#000033',
                            marginTop: '6px'
                          }}
                        />
                        <p 
                          className="text-xs md:text-sm flex-1" 
                          style={{ 
                            color: '#4A5568', 
                            lineHeight: '1.5'
                          }}
                        >
                          {control}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Anchored Callout - Appears on Hover */}
      {selectedStage !== null && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="w-full rounded-lg md:rounded-xl border p-6 md:p-8"
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#C0C5CE'
          }}
        >
          <h4 className="font-bold text-base md:text-lg mb-3 md:mb-4" style={{ color: '#000033' }}>
            {architectureStages[selectedStage].title}
          </h4>
          
          <p className="text-sm md:text-base mb-6" style={{ color: '#4A5568', lineHeight: '1.7' }}>
            {architectureStages[selectedStage].detailedDescription}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-xs md:text-sm font-semibold uppercase tracking-wide mb-2" style={{ color: '#718096' }}>
                INPUT SOURCE
              </p>
              <p className="text-xs md:text-sm" style={{ color: '#4A5568', lineHeight: '1.6' }}>
                {architectureStages[selectedStage].inputSource}
              </p>
            </div>
            <div>
              <p className="text-xs md:text-sm font-semibold uppercase tracking-wide mb-2" style={{ color: '#718096' }}>
                OUTPUT DELIVERABLE
              </p>
              <p className="text-xs md:text-sm" style={{ color: '#4A5568', lineHeight: '1.6' }}>
                {architectureStages[selectedStage].outputDeliverable}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Foundation Strip - Traceability Guarantee */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="w-full rounded-lg md:rounded-xl p-6 md:p-8"
        style={{
          backgroundColor: '#FFFFFF',
          borderTop: '3px solid #000033'
        }}
      >
        <h4 className="font-bold text-sm md:text-base uppercase tracking-wide mb-3" style={{ color: '#000033' }}>
          TRACEABILITY GUARANTEE
        </h4>
        <p className="text-sm md:text-base" style={{ color: '#4A5568', lineHeight: '1.7' }}>
          Every transformation step writes to an immutable audit ledger enabling replay and adversarial defensibility.
        </p>
      </motion.div>
    </div>
  );
}