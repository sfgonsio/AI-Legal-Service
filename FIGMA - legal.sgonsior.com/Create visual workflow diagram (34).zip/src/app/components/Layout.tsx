import { Outlet, Link, useLocation } from "react-router";
import { motion } from "motion/react";
import { Home, Info, TrendingUp, Layers, Workflow as WorkflowIcon, GitBranch, Shield, Code, Activity, MessageSquare, HelpCircle, Video, Lock, Building2, Cpu, Database, Zap, Filter, Presentation, Map } from "lucide-react";
import { ProgressIndicator } from "./ProgressIndicator";
import { ThemeToggle } from "./ThemeToggle";
import { useKeyboardNavigation } from "../hooks/useKeyboardNavigation";
import { KeyboardShortcutsModal } from "./KeyboardShortcutsModal";
import { SplashScreen } from "./SplashScreen";
import { useState, useEffect } from "react";

// Navigation sections for better organization
const navigationSections = [
  {
    title: "OVERVIEW",
    items: [
      { path: "/final/welcome", label: "WELCOME", icon: Home },
      { path: "/final/what-this-is", label: "WHAT THIS IS", icon: Info },
      { path: "/final/what-this-changes", label: "WHAT THIS CHANGES", icon: TrendingUp },
    ],
  },
  {
    title: "EXECUTIVE SLIDES",
    items: [
      { path: "/final/presentation", label: "📊 PRESENTATION INDEX", icon: Presentation },
      // Part 1: Foundational Overview
      { path: "/final/platform-architecture", label: "SL-1: Platform Architecture", icon: Building2 },
      { path: "/final/litigation-intelligence", label: "SL-16: TrialForge Engine", icon: Cpu },
      { path: "/final/litigation-flow", label: "SL-17: Intelligence Flow", icon: WorkflowIcon },
      { path: "/final/workflow-map", label: "SL-18: Workflow Map", icon: Map },
      // Part 2: Conceptual Framework
      { path: "/final/dikw-strategy", label: "SL-3: Evidence Transformation", icon: Zap },
      { path: "/final/data-architecture", label: "SL-4: Litigation Leverage", icon: Database },
      { path: "/final/evidence-pressure", label: "SL-5: Admissibility Leverage", icon: Filter },
      // Part 3: System Execution
      { path: "/final/litigation-engine", label: "SL-2: Litigation Lifecycle", icon: Cpu },
      { path: "/final/litigation-workflow", label: "SL-13: Workflow Stages", icon: WorkflowIcon },
      { path: "/final/artifact-matrix", label: "SL-14: Artifact Matrix", icon: GitBranch },
      { path: "/final/artifact-registry", label: "SL-15: Artifact Registry", icon: Layers },
      // Part 4: Spine & Brain Architecture
      { path: "/final/spine-brain-concept", label: "SL-9: Spine & Brain Concept", icon: GitBranch },
      { path: "/final/spine-brain-architecture", label: "SL-8: Spine & Brain Architecture", icon: Cpu },
      { path: "/final/spine-detail", label: "SL-10: Spine Deep Dive", icon: Cpu },
      { path: "/final/brain-detail", label: "SL-11: Brain Deep Dive", icon: GitBranch },
      // Part 5: Technical Implementation
      { path: "/final/tech-architecture", label: "SL-6: Tech Architecture", icon: Building2 },
      { path: "/final/tech-stack", label: "SL-7: Technology Stack", icon: Layers },
      // Part 6: Development & Input
      { path: "/final/development", label: "Development Status", icon: Activity },
      // HIDDEN: Leadership slide needs update
      // { path: "/final/leadership", label: "Leadership Input", icon: MessageSquare },
    ],
  },
  {
    title: "TECHNICAL DETAILS",
    items: [
      { path: "/final/core-capabilities", label: "CORE CAPABILITIES", icon: Layers },
      { path: "/final/workflow", label: "WORKFLOW", icon: WorkflowIcon },
      { path: "/final/agent-program-map", label: "AGENT → PROGRAM MAP", icon: GitBranch },
      { path: "/final/evidentiary", label: "EVIDENTIARY DEFENSIBILITY", icon: Shield },
      { path: "/final/system-governance", label: "SYSTEM GOVERNANCE", icon: Lock },
      { path: "/final/engineering", label: "ENGINEERING FOUNDATION", icon: Code },
    ],
  },
];

// Flatten for progress tracking
const navigationItems = navigationSections.flatMap(section => section.items);

export function Layout() {
  const location = useLocation();
  const currentIndex = navigationItems.findIndex(item => item.path === location.pathname);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Enable keyboard navigation
  useKeyboardNavigation();

  // Listen for "?" key to show shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "?" && document.activeElement?.tagName !== "INPUT" && document.activeElement?.tagName !== "TEXTAREA") {
        e.preventDefault();
        setShowShortcuts(prev => !prev);
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <>
      <SplashScreen />
      <div className="flex h-screen w-screen overflow-hidden" style={{ backgroundColor: 'var(--light-background)' }}>
        {/* Mobile Menu Button */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="fixed top-4 left-4 z-50 p-3 rounded-lg border lg:hidden"
          style={{
            backgroundColor: 'var(--white)',
            borderColor: 'var(--divider)',
          }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {mobileMenuOpen ? (
              <path d="M18 6L6 18M6 6l12 12" />
            ) : (
              <path d="M3 12h18M3 6h18M3 18h18" />
            )}
          </svg>
        </motion.button>

        {/* Overlay for mobile */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setMobileMenuOpen(false)}
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          />
        )}

        {/* Left Navigation Panel */}
        <aside
          className="w-[280px] h-screen flex-shrink-0 border-r flex flex-col z-40 fixed lg:relative transition-transform duration-300 lg:translate-x-0"
          style={{ 
            backgroundColor: 'var(--white)', 
            borderColor: 'var(--divider)',
            transform: mobileMenuOpen ? 'translateX(0)' : 'translateX(-100%)',
          }}
        >
          {/* Logo/Header */}
          <div className="h-[72px] flex items-center justify-between px-6 border-b" style={{ borderColor: 'var(--divider)' }}>
            <h2 className="text-xl font-bold tracking-wider" style={{ color: 'var(--primary-blue)' }}>
              TRIALFORGE
            </h2>
            <div className="flex items-center gap-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowShortcuts(true)}
                className="p-2 rounded-lg border transition-all"
                style={{
                  backgroundColor: 'var(--white)',
                  borderColor: 'var(--divider)',
                }}
                title="Keyboard shortcuts"
              >
                <HelpCircle size={18} style={{ color: 'var(--primary-blue)' }} />
              </motion.button>
              <ThemeToggle />
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="flex-1 overflow-y-auto py-6">
            {navigationSections.map(section => (
              <div key={section.title}>
                <h3 className="px-6 py-3 text-sm font-bold tracking-wider text-gray-500 uppercase" style={{ color: 'var(--text-secondary)' }}>
                  {section.title}
                </h3>
                {section.items.map((item, index) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  
                  return (
                    <Link key={item.path} to={item.path}>
                      <motion.div
                        className="relative px-6 py-3 flex items-center gap-3 cursor-pointer transition-all"
                        whileHover={{ x: 4 }}
                        style={{
                          backgroundColor: isActive ? 'var(--light-background)' : 'transparent',
                          borderLeft: isActive ? '3px solid var(--primary-blue)' : '3px solid transparent',
                        }}
                      >
                        <Icon 
                          size={18} 
                          style={{ color: isActive ? 'var(--primary-blue)' : 'var(--text-secondary)' }}
                        />
                        <span
                          className="text-sm tracking-wide"
                          style={{
                            color: isActive ? 'var(--primary-blue)' : 'var(--text-secondary)',
                            fontWeight: isActive ? '600' : '400',
                          }}
                        >
                          {item.label}
                        </span>
                      </motion.div>
                    </Link>
                  );
                })}
              </div>
            ))}
          </nav>

          {/* Progress Indicator */}
          <div className="p-6 border-t" style={{ borderColor: 'var(--divider)' }}>
            <ProgressIndicator currentIndex={currentIndex} total={navigationItems.length} />
            
            {/* Version Indicator */}
            <div className="mt-4 pt-4 border-t text-xs text-center" style={{ borderColor: 'var(--divider)', color: 'var(--slide-text-secondary)' }}>
              <div>Version 85.1 Secured</div>
              <div className="mt-1 opacity-60">Hidden Path Structure</div>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[900px] mx-auto px-4 sm:px-6 md:px-8 lg:px-12 py-6 sm:py-8 md:py-12">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
            >
              <Outlet />
            </motion.div>
          </div>
        </main>

        <KeyboardShortcutsModal isOpen={showShortcuts} onClose={() => setShowShortcuts(false)} />
      </div>
    </>
  );
}