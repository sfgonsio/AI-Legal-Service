import { motion } from "motion/react";
import { useState } from "react";

export function LitigationLeverageDiagram() {
  const [hoveredSection, setHoveredSection] = useState<string | null>(null);

  return (
    <div className="space-y-6 md:space-y-8 w-full">
      {/* Top Banner - Platform Model */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="w-full rounded-lg md:rounded-xl flex flex-col items-center justify-center text-center py-5 md:py-6 px-4 md:px-8"
        style={{
          backgroundColor: '#000033',
          minHeight: '90px'
        }}
      >
        <p className="text-sm md:text-base font-bold uppercase tracking-widest mb-2" style={{ color: '#FFFFFF' }}>
          LITIGATION LEVERAGE INFRASTRUCTURE
        </p>
        <p className="text-xs md:text-sm" style={{ color: '#FFFFFF', opacity: 0.88 }}>
          Evidence-Centered • Rule-Evaluated • Strategically Traceable
        </p>
      </motion.div>

      {/* Three-Layer Architecture */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="w-full space-y-4 md:space-y-6"
      >
        {/* LAYER 1: Evidence Foundation Packet */}
        <div
          onMouseEnter={() => setHoveredSection('evidence')}
          onMouseLeave={() => setHoveredSection(null)}
          className="w-full rounded-lg md:rounded-xl border-2 transition-all duration-300 cursor-pointer"
          style={{
            backgroundColor: hoveredSection === 'evidence' ? '#F4F6F8' : '#FFFFFF',
            borderColor: hoveredSection === 'evidence' ? '#000033' : '#C0C5CE'
          }}
        >
          <div className="p-6 md:p-10 lg:p-12">
            {/* Section Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 md:mb-8">
              <div className="mb-4 md:mb-0">
                <h3 className="text-lg md:text-xl font-bold uppercase tracking-wide mb-2" style={{ color: '#000033' }}>
                  Evidence Foundation Packet
                </h3>
                <p className="text-xs md:text-sm font-semibold uppercase tracking-widest" style={{ color: '#000033', opacity: 0.6 }}>
                  Hash-Locked • Deterministic • Case-Scoped
                </p>
              </div>
              <div 
                className="px-4 py-2 rounded-lg text-xs md:text-sm font-semibold uppercase tracking-wide inline-block"
                style={{ backgroundColor: '#000033', color: '#FFFFFF' }}
              >
                ATOMIC UNIT
              </div>
            </div>

            {/* Content Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-6">
              <ComponentItem title="Evidence Item" desc="document, message, recording, object" />
              <ComponentItem title="Source Record" desc="Originating source documentation" />
              <ComponentItem title="SHA-256 Integrity Hash" desc="Cryptographic fingerprint" />
              <ComponentItem title="Chain of Custody" desc="Unbroken lineage tracking" />
              <ComponentItem title="Statements & Declarants" desc="Witness and party attributions" />
              <ComponentItem title="Metadata & Temporal Anchors" desc="Timestamp and context data" />
              <ComponentItem title="Version ID" desc="Immutable version control" />
              <ComponentItem title="Audit Reference" desc="Full audit trail linkage" />
            </div>

            {/* Bottom Principle */}
            <div className="pt-6 border-t" style={{ borderColor: '#E2E8F0' }}>
              <p className="text-sm md:text-base italic text-center" style={{ color: '#4A5568' }}>
                This is the atomic unit of the platform. Nothing downstream exists without it.
              </p>
            </div>
          </div>
        </div>

        {/* LAYER 2: Rule Evaluation Layer */}
        <div
          onMouseEnter={() => setHoveredSection('rules')}
          onMouseLeave={() => setHoveredSection(null)}
          className="w-full rounded-lg md:rounded-xl border-2 transition-all duration-300 cursor-pointer"
          style={{
            backgroundColor: hoveredSection === 'rules' ? '#F4F6F8' : '#FFFFFF',
            borderColor: hoveredSection === 'rules' ? '#000033' : '#C0C5CE'
          }}
        >
          <div className="p-6 md:p-10 lg:p-12">
            {/* Section Header */}
            <div className="mb-6 md:mb-8">
              <h3 className="text-lg md:text-xl font-bold uppercase tracking-wide mb-2" style={{ color: '#000033' }}>
                Rule Evaluation Layer
              </h3>
              <p className="text-xs md:text-sm font-semibold uppercase tracking-widest" style={{ color: '#000033', opacity: 0.6 }}>
                Overlay-Based Rule Families (CA Evidence Code Aligned)
              </p>
            </div>

            {/* Rule Families */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-6">
              <RuleItem title="Relevance & 352 Balancing" desc="Probative value vs prejudice" />
              <RuleItem title="Authentication (CEC 1400+)" desc="Evidence genuineness verification" />
              <RuleItem title="Hearsay & Exceptions" desc="Out-of-court statement evaluation" />
              <RuleItem title="Privilege" desc="Attorney-client, work product" />
              <RuleItem title="Expert / Opinion Foundations" desc="Qualified expert testimony rules" />
            </div>

            {/* Principles */}
            <div className="space-y-3 pt-6 border-t" style={{ borderColor: '#E2E8F0' }}>
              <PrincipleRow text="Each overlay evaluates the foundation packet." />
              <PrincipleRow text="Each evaluation is versioned." />
              <PrincipleRow text="Each result is replayable." />
            </div>

            {/* Bottom Principle */}
            <div className="mt-6 pt-6 border-t" style={{ borderColor: '#E2E8F0' }}>
              <p className="text-sm md:text-base italic text-center font-semibold" style={{ color: '#000033' }}>
                Rules do not replace evidence. They evaluate it.
              </p>
            </div>
          </div>
        </div>

        {/* LAYER 3: Litigation Outputs */}
        <div
          onMouseEnter={() => setHoveredSection('outputs')}
          onMouseLeave={() => setHoveredSection(null)}
          className="w-full rounded-lg md:rounded-xl border-2 transition-all duration-300 cursor-pointer"
          style={{
            backgroundColor: hoveredSection === 'outputs' ? '#F4F6F8' : '#FFFFFF',
            borderColor: hoveredSection === 'outputs' ? '#000033' : '#C0C5CE'
          }}
        >
          <div className="p-6 md:p-10 lg:p-12">
            {/* Section Header */}
            <div className="mb-6 md:mb-8">
              <h3 className="text-lg md:text-xl font-bold uppercase tracking-wide mb-2" style={{ color: '#000033' }}>
                Litigation Outputs
              </h3>
              <p className="text-xs md:text-sm font-semibold uppercase tracking-widest" style={{ color: '#000033', opacity: 0.6 }}>
                Derived Artifacts
              </p>
            </div>

            {/* Outputs Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 mb-6">
              <OutputItem text="Exhibits" />
              <OutputItem text="Objections" />
              <OutputItem text="Admissibility Determinations" />
              <OutputItem text="Complaint Element Mapping" />
              <OutputItem text="Discovery Artifacts" />
              <OutputItem text="Deposition Preparation" />
              <OutputItem text="Trial Brief Components" />
            </div>

            {/* Bottom Principle */}
            <div className="pt-6 border-t" style={{ borderColor: '#E2E8F0' }}>
              <p className="text-sm md:text-base italic text-center" style={{ color: '#4A5568' }}>
                Every artifact can be traced backward to its originating evidence file.
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Platform Guarantees & Strategic Impact - Side by Side */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="w-full grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6"
      >
        {/* Platform Guarantees */}
        <div
          className="rounded-lg md:rounded-xl p-6 md:p-8 border"
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#C0C5CE'
          }}
        >
          <h4 className="text-base md:text-lg font-bold uppercase tracking-wide mb-5" style={{ color: '#000033' }}>
            Platform Guarantees
          </h4>
          <div className="space-y-3">
            <GuaranteeItem text="Deterministic Execution" />
            <GuaranteeItem text="Hash Verification" />
            <GuaranteeItem text="Overlay Governance" />
            <GuaranteeItem text="Audit Logging" />
            <GuaranteeItem text="Replay Equivalence" />
          </div>
        </div>

        {/* Strategic Impact */}
        <div
          className="rounded-lg md:rounded-xl p-6 md:p-8"
          style={{
            backgroundColor: '#000033'
          }}
        >
          <h4 className="text-base md:text-lg font-bold uppercase tracking-wide mb-5" style={{ color: '#FFFFFF' }}>
            Strategic Impact
          </h4>
          <div className="space-y-3">
            <ImpactItem text="Reduces evidentiary exclusion risk" />
            <ImpactItem text="Strengthens motion posture" />
            <ImpactItem text="Improves element-proof clarity" />
            <ImpactItem text="Enables repeatable trial preparation" />
            <ImpactItem text="Increases admissibility confidence" />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Component Item for Evidence Foundation
function ComponentItem({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="flex flex-col">
      <p className="text-sm md:text-base font-semibold mb-1" style={{ color: '#000033' }}>
        {title}
      </p>
      <p className="text-xs md:text-sm" style={{ color: '#718096', lineHeight: '1.5' }}>
        {desc}
      </p>
    </div>
  );
}

// Rule Item for Rule Evaluation
function RuleItem({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="flex flex-col">
      <p className="text-sm md:text-base font-semibold mb-1" style={{ color: '#000033' }}>
        {title}
      </p>
      <p className="text-xs md:text-sm" style={{ color: '#718096', lineHeight: '1.5' }}>
        {desc}
      </p>
    </div>
  );
}

// Principle Row for Rule Layer
function PrincipleRow({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div
        className="rounded-full flex-shrink-0"
        style={{
          width: '6px',
          height: '6px',
          backgroundColor: '#000033'
        }}
      />
      <p className="text-xs md:text-sm" style={{ color: '#4A5568' }}>
        {text}
      </p>
    </div>
  );
}

// Output Item for Litigation Outputs
function OutputItem({ text }: { text: string }) {
  return (
    <div
      className="px-4 py-3 rounded-lg border text-center"
      style={{
        borderColor: '#C0C5CE',
        backgroundColor: '#F9FAFB'
      }}
    >
      <p className="text-xs md:text-sm font-medium" style={{ color: '#000033' }}>
        {text}
      </p>
    </div>
  );
}

// Guarantee Item
function GuaranteeItem({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div
        className="rounded-full flex-shrink-0"
        style={{
          width: '7px',
          height: '7px',
          backgroundColor: '#000033'
        }}
      />
      <p className="text-sm md:text-base font-medium" style={{ color: '#000033' }}>
        {text}
      </p>
    </div>
  );
}

// Impact Item (inverted for dark background)
function ImpactItem({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div
        className="rounded-full flex-shrink-0"
        style={{
          width: '7px',
          height: '7px',
          backgroundColor: '#FFFFFF'
        }}
      />
      <p className="text-sm md:text-base font-medium" style={{ color: '#FFFFFF' }}>
        {text}
      </p>
    </div>
  );
}
