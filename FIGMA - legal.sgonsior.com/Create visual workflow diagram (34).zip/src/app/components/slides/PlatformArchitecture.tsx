import { motion } from "motion/react";

// Architectural Foundation for Litigation Leverage
export function PlatformArchitecture() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1100px]"
    >
      <div className="relative">
        {/* Left Spine - Desktop Only */}
        <div
          className="hidden xl:flex absolute left-0 top-0 bottom-0 items-center justify-center"
          style={{
            width: "64px",
            backgroundColor: "#000033",
            transform: "translateX(-80px)",
            borderRadius: "12px 0 0 12px",
          }}
        >
          <div
            className="text-white text-xs font-semibold uppercase tracking-wider"
            style={{
              writingMode: "vertical-rl",
              transform: "rotate(180deg)",
              letterSpacing: "0.15em",
            }}
          >
            Evidence Foundation
          </div>
        </div>

        {/* Right Spine - Desktop Only */}
        <div
          className="hidden xl:flex absolute right-0 top-0 bottom-0 items-center justify-center"
          style={{
            width: "64px",
            backgroundColor: "#000033",
            transform: "translateX(80px)",
            borderRadius: "0 12px 12px 0",
          }}
        >
          <div
            className="text-white text-xs font-semibold uppercase tracking-wider"
            style={{
              writingMode: "vertical-rl",
              letterSpacing: "0.15em",
            }}
          >
            Litigation Leverage
          </div>
        </div>

        {/* Main Platform Frame */}
        <div
          className="relative rounded-lg md:rounded-xl overflow-hidden"
          style={{
            backgroundColor: "#FFFFFF",
            border: "1px solid #C0C5CE",
          }}
        >
          {/* SECTION 1 — EVIDENCE-FIRST ARCHITECTURE */}
          <div
            className="px-6 md:px-12 py-8 md:py-12 flex flex-col items-center justify-center"
            style={{
              backgroundColor: "#000033",
              minHeight: "280px",
            }}
          >
            <div className="w-full max-w-2xl">
              <h2 className="text-white font-bold uppercase tracking-wide text-center text-lg md:text-xl"
                  style={{ letterSpacing: "0.12em" }}>
                Evidence-First Architecture
              </h2>

              {/* Core principle banner */}
              <div
                className="mt-6 mb-8 px-4 md:px-5 py-3 text-center rounded-lg md:rounded-xl"
                style={{
                  border: "1px solid rgba(255,255,255,0.25)",
                  color: "rgba(255,255,255,0.92)",
                  fontSize: "13px",
                  letterSpacing: "0.06em",
                }}
              >
                HASH-VERIFIED EVIDENCE IS THE ATOMIC UNIT — ALL WORK TRACES BACKWARD
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 md:gap-x-10 gap-y-4">
                <PrincipleItem text="Deterministic Execution" inverted />
                <PrincipleItem text="Hash-Verified Evidence" inverted />
                <PrincipleItem text="Rule-Based Evaluation" inverted />
                <PrincipleItem text="Replay Equivalence Enforced" inverted />
              </div>

              <p
                className="mt-8 text-center italic text-sm"
                style={{ color: "rgba(255,255,255,0.72)" }}
              >
                Architecture begins with evidence integrity, not intelligence assumptions.
              </p>
            </div>
          </div>

          {/* Divider */}
          <div style={{ height: "2px", backgroundColor: "#000033" }} />

          {/* SECTION 2 — OVERLAY GOVERNANCE */}
          <div className="px-6 md:px-12 py-8 md:py-12" style={{ minHeight: "280px" }}>
            <h2
              className="font-bold uppercase tracking-wide text-center text-lg md:text-xl mb-3"
              style={{ color: "#000033", letterSpacing: "0.12em" }}
            >
              Overlay Governance
            </h2>
            <p className="text-center text-sm mb-10" style={{ color: "rgba(0,0,51,0.68)" }}>
              Configurable overlays evaluate immutable evidence foundation
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              <div className="space-y-4">
                <PrincipleItem text="CA Evidence Code Alignment" />
                <PrincipleItem text="Overlay-Based Rule Families" />
                <PrincipleItem text="Versioned Evaluations" />
                <PrincipleItem text="Admissibility Scoring" />
              </div>
              <div className="space-y-4">
                <PrincipleItem text="Extensible Without Rewrite" />
                <PrincipleItem text="Jurisdiction-Specific Rules" />
                <PrincipleItem text="Attorney Override Authority" />
                <PrincipleItem text="Audit-Enforced Decisions" />
              </div>
            </div>

            <p
              className="mt-8 text-center text-sm"
              style={{ color: "rgba(0,0,51,0.72)" }}
            >
              Rules evaluate evidence—they don't replace it. Every evaluation is versioned and replayable.
            </p>
          </div>

          {/* Divider */}
          <div style={{ height: "2px", backgroundColor: "#000033" }} />

          {/* SECTION 3 — TRACEABILITY & SECURITY */}
          <div className="px-6 md:px-12 py-8 md:py-12" style={{ minHeight: "280px" }}>
            <h2
              className="font-bold uppercase tracking-wide text-center text-lg md:text-xl mb-3"
              style={{ color: "#000033", letterSpacing: "0.12em" }}
            >
              Traceability & Security Foundational
            </h2>
            <p className="text-center text-sm mb-10" style={{ color: "rgba(0,0,51,0.68)" }}>
              Every transformation logged, every artifact traceable to source
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              <div className="space-y-4">
                <PrincipleItem text="Evidence Vault (Hash-Locked)" />
                <PrincipleItem text="Chain of Custody Tracking" />
                <PrincipleItem text="Immutable Audit Ledger" />
                <PrincipleItem text="Version Control Enforced" />
              </div>
              <div className="space-y-4">
                <PrincipleItem text="Role-Based Access Control" />
                <PrincipleItem text="Attorney Work Product Protection" />
                <PrincipleItem text="Case Boundary Isolation" />
                <PrincipleItem text="Adversarial Defensibility" />
              </div>
            </div>

            <p
              className="mt-8 text-center text-sm"
              style={{ color: "rgba(0,0,51,0.72)" }}
            >
              Every fact traceable. Every transformation logged. Every output defensible.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function PrincipleItem({
  text,
  inverted = false,
}: {
  text: string;
  inverted?: boolean;
}) {
  return (
    <div className="flex items-start gap-3">
      <div
        className="mt-2 flex-shrink-0"
        style={{
          width: "7px",
          height: "7px",
          borderRadius: "999px",
          backgroundColor: inverted ? "#FFFFFF" : "#000033",
          opacity: inverted ? 0.95 : 0.9,
        }}
      />
      <p
        className="font-medium leading-relaxed text-base md:text-lg"
        style={{
          color: inverted ? "#FFFFFF" : "#000033",
        }}
      >
        {text}
      </p>
    </div>
  );
}
