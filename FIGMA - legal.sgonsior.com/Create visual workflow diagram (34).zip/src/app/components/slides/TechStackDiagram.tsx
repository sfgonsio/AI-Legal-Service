import { motion } from "motion/react";

// Technology Stack — Litigation Infrastructure
export function TechStackDiagram() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1400px] px-4"
    >
      <div className="grid grid-cols-12 gap-3">
        {/* MAIN STACK - 10 columns */}
        <div className="col-span-12 lg:col-span-10 space-y-2">
          
          {/* LAYER 1 — EXPERIENCE LAYER */}
          <StackLayer bgColor="#000033" textColor="#FFFFFF">
            <LayerHeader number="1" title="Experience Layer" />
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-3 text-xs">
              <TechBox>React</TechBox>
              <TechBox>TypeScript</TechBox>
              <TechBox>Tailwind CSS</TechBox>
              <TechBox>shadcn/ui</TechBox>
              <TechBox>motion/react</TechBox>
              <TechBox>Vite</TechBox>
            </div>
            <LayerPurpose>
              Structured, role-based client and attorney interfaces with consistent, controlled UI behavior.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 2 — IDENTITY & ACCESS CONTROL */}
          <StackLayer bgColor="#0d1a40" textColor="#FFFFFF">
            <LayerHeader number="2" title="Identity & Access Control" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3 text-xs">
              <TechBox>AWS Cognito</TechBox>
              <TechBox>Case-scoped RBAC/ABAC</TechBox>
              <TechBox>IAM policy layering</TechBox>
            </div>
            <LayerPurpose>
              Role-based access, case isolation, and privilege-aware enforcement across all workflows.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 3 — GOVERNED ORCHESTRATION RUNTIME */}
          <StackLayer bgColor="#1a2950" textColor="#FFFFFF">
            <LayerHeader number="3" title="Governed Orchestration Runtime" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 text-xs">
              <TechBox>Temporal</TechBox>
              <TechBox>Node.js + TypeScript</TechBox>
              <TechBox>AWS ECS (Fargate)</TechBox>
              <TechBox>SQS + EventBridge</TechBox>
            </div>
            <LayerPurpose>
              Versioned, replayable workflow orchestration. Agents propose. Programs execute under governance.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 4 — TOOL MEDIATION GATEWAY */}
          <StackLayer bgColor="#263a5f" textColor="#FFFFFF">
            <LayerHeader number="4" title="Tool Mediation Gateway" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 text-xs">
              <TechBox>TypeScript (NestJS/Fastify)</TechBox>
              <TechBox>Contract v1 enforcement</TechBox>
              <TechBox>Tool registry validation</TechBox>
              <TechBox>Audit emission service</TechBox>
            </div>
            <LayerPurpose>
              Prevents direct tool access. Enforces role permissions, contract validation, and execution logging.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 5 — AI & TRANSCRIPTION LAYER */}
          <StackLayer bgColor="#334a6e" textColor="#FFFFFF">
            <LayerHeader number="5" title="AI & Transcription Layer" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3 text-xs">
              <TechBox>Claude (reasoning model)</TechBox>
              <TechBox>Optional secondary LLM</TechBox>
              <TechBox>Amazon Transcribe</TechBox>
            </div>
            <LayerPurpose>
              Structured reasoning and interview narration processing, fully mediated and auditable.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 6 — DETERMINISTIC PROGRAM LAYER */}
          <StackLayer bgColor="#405b7d" textColor="#FFFFFF">
            <LayerHeader number="6" title="Deterministic Program Layer" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 text-xs">
              <TechBox>Python services (containerized)</TechBox>
              <TechBox>Docker</TechBox>
              <TechBox>ffmpeg (audio)</TechBox>
              <TechBox>Structured extraction libraries</TechBox>
            </div>
            <LayerPurpose>
              Hashing, parsing, evidence normalization, transcript processing, rule overlays — all deterministic and replayable.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 7 — DATA FOUNDATION */}
          <StackLayer bgColor="#4d6c8c" textColor="#FFFFFF">
            <LayerHeader number="7" title="Data Foundation" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3 text-xs">
              <TechBox>PostgreSQL (Structured Evidence Ledger)</TechBox>
              <TechBox>AWS S3 + Object Lock (Evidence Vault)</TechBox>
              <TechBox>OpenSearch (Search & retrieval)</TechBox>
            </div>
            <LayerPurpose>
              Immutable evidence preservation. Structured fact storage. Searchable litigation record.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 8 — SECURITY & KEY MANAGEMENT */}
          <StackLayer bgColor="#5a7d9b" textColor="#FFFFFF">
            <LayerHeader number="8" title="Security & Key Management" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3 text-xs">
              <TechBox>AWS KMS</TechBox>
              <TechBox>AWS Secrets Manager</TechBox>
              <TechBox>AWS WAF</TechBox>
            </div>
            <LayerPurpose>
              Encryption at rest and in transit. Key control. Internet boundary protection.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 9 — OBSERVABILITY & AUDIT */}
          <StackLayer bgColor="#678eaa" textColor="#FFFFFF">
            <LayerHeader number="9" title="Observability & Audit" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-3 text-xs">
              <TechBox>OpenTelemetry</TechBox>
              <TechBox>AWS CloudWatch</TechBox>
              <TechBox>Append-only audit ledger</TechBox>
            </div>
            <LayerPurpose>
              Replay equivalence. Execution traceability. Defensible audit posture.
            </LayerPurpose>
          </StackLayer>

          {/* LAYER 10 — CI/CD & GOVERNANCE */}
          <StackLayer bgColor="#749fb9" textColor="#FFFFFF">
            <LayerHeader number="10" title="CI/CD & Governance" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 text-xs">
              <TechBox>GitHub</TechBox>
              <TechBox>GitHub Actions</TechBox>
              <TechBox>Terraform</TechBox>
              <TechBox>Container Registry (ECR)</TechBox>
            </div>
            <LayerPurpose>
              Infrastructure as code. Manifest enforcement. Drift prevention via automated validation gates.
            </LayerPurpose>
          </StackLayer>

          {/* FOOTER */}
          <div className="pt-3 text-center">
            <p className="text-xs italic" style={{ color: "rgba(0,0,51,0.6)" }}>
              Architected for adversarial environments.
            </p>
          </div>
        </div>

        {/* RIGHT COLUMN - PLATFORM GUARANTEES - 2 columns */}
        <div className="col-span-12 lg:col-span-2">
          <div
            className="rounded-lg p-4 h-full flex flex-col justify-start"
            style={{
              backgroundColor: "#000033",
              border: "2px solid #FFFFFF",
            }}
          >
            <h3 className="font-bold text-xs mb-4 text-center uppercase tracking-wider text-white leading-snug">
              Platform<br />Guarantees
            </h3>
            <div className="space-y-2">
              <GuaranteeBox>Deterministic<br />Execution</GuaranteeBox>
              <GuaranteeBox>Hash-Locked<br />Evidence</GuaranteeBox>
              <GuaranteeBox>Tool Mediation<br />Enforcement</GuaranteeBox>
              <GuaranteeBox>Case-Scoped<br />Isolation</GuaranteeBox>
              <GuaranteeBox>Replay<br />Equivalence</GuaranteeBox>
              <GuaranteeBox>Audit<br />Traceability</GuaranteeBox>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Helper Components
function StackLayer({
  bgColor,
  textColor,
  children,
}: {
  bgColor: string;
  textColor: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded p-3"
      style={{
        backgroundColor: bgColor,
        color: textColor,
        border: "1px solid rgba(255,255,255,0.15)",
      }}
    >
      {children}
    </div>
  );
}

function LayerHeader({ number, title }: { number: string; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <div
        className="px-2 py-1 rounded text-xs font-bold"
        style={{
          backgroundColor: "rgba(255,255,255,0.2)",
          border: "1px solid rgba(255,255,255,0.3)",
        }}
      >
        {number}
      </div>
      <h3 className="font-bold text-sm uppercase tracking-wide">{title}</h3>
    </div>
  );
}

function TechBox({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="px-2 py-1.5 rounded text-center font-medium"
      style={{
        backgroundColor: "rgba(255,255,255,0.1)",
        border: "1px solid rgba(255,255,255,0.2)",
      }}
    >
      {children}
    </div>
  );
}

function LayerPurpose({ children }: { children: React.ReactNode }) {
  return (
    <p className="mt-2 text-xs italic opacity-75 leading-relaxed">
      {children}
    </p>
  );
}

function GuaranteeBox({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="px-3 py-2 rounded text-xs font-semibold text-center"
      style={{
        backgroundColor: "rgba(255,255,255,0.1)",
        border: "1px solid rgba(255,255,255,0.3)",
        color: "#FFFFFF",
      }}
    >
      {children}
    </div>
  );
}