import { motion } from "motion/react";
import { useState } from "react";

const TRANSFORMATION_STAGES = [
  {
    id: "capture",
    label: "Evidence Capture",
    layer: "DATA",
    description: "Raw evidence enters the platform with cryptographic fingerprinting and chain of custody initialization.",
    transforms: [
      "SHA-256 hash generation",
      "Source attribution logging",
      "Case boundary enforcement",
      "Immutable vault write"
    ],
    input: "Documents, emails, recordings, testimony transcripts",
    output: "Evidence Foundation Packets (hash-locked)",
    guarantee: "Hash Verification"
  },
  {
    id: "parse",
    label: "Structured Parsing",
    layer: "INFORMATION",
    description: "Evidence packets are parsed into structured semantic units while preserving bidirectional source references.",
    transforms: [
      "Entity extraction (parties, dates, amounts)",
      "Relationship mapping",
      "Temporal anchoring",
      "Lineage preservation"
    ],
    input: "Evidence Foundation Packets",
    output: "Structured fact graph with source citations",
    guarantee: "Deterministic Execution"
  },
  {
    id: "evaluate",
    label: "Rule Evaluation",
    layer: "KNOWLEDGE",
    description: "CA Evidence Code overlays evaluate structured facts for relevance, authentication, hearsay, and privilege.",
    transforms: [
      "Relevance assessment (CEC 350-352)",
      "Authentication evaluation (CEC 1400+)",
      "Hearsay analysis with exceptions",
      "Privilege determination"
    ],
    input: "Structured fact graph",
    output: "Rule-evaluated facts with admissibility scores",
    guarantee: "Overlay Governance"
  },
  {
    id: "map",
    label: "Element Mapping",
    layer: "LEGAL KNOWLEDGE",
    description: "Rule-evaluated facts are mapped to cause-of-action elements with evidentiary support analysis.",
    transforms: [
      "Element requirement parsing",
      "Fact-to-element binding",
      "Evidentiary sufficiency scoring",
      "Gap identification"
    ],
    input: "Rule-evaluated facts",
    output: "Element-to-evidence matrix with coverage analysis",
    guarantee: "Audit Logging"
  },
  {
    id: "generate",
    label: "Artifact Generation",
    layer: "STRATEGIC OUTPUTS",
    description: "Court-ready documents generated with complete citation chains traceable to original source evidence.",
    transforms: [
      "Complaint drafting with element support",
      "Discovery response generation",
      "Deposition outline creation",
      "Trial brief compilation"
    ],
    input: "Element-to-evidence matrix",
    output: "Court filings with evidentiary audit trail",
    guarantee: "Replay Equivalence"
  }
];

export function DIKWStrategyArchitecture() {
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const active = activeStage
    ? TRANSFORMATION_STAGES.find((s) => s.id === activeStage) ?? null
    : null;

  return (
    <div className="relative w-full space-y-6 md:space-y-8">
      {/* Silver rule for engineered feel */}
      <div style={{ height: "1px", backgroundColor: "#C0C5CE", marginBottom: "16px" }} />

      {/* Governance band */}
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.05 }}
        className="flex items-center justify-center rounded-lg md:rounded-xl py-4 md:py-5 px-4"
        style={{
          minHeight: "70px",
          backgroundColor: "#000033",
        }}
      >
        <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-white text-xs md:text-sm font-medium tracking-wide text-center">
          <span>Hash-Verified Evidence</span>
          <span className="hidden md:inline" style={{ opacity: 0.45 }}>•</span>
          <span>Rule-Evaluated Facts</span>
          <span className="hidden md:inline" style={{ opacity: 0.45 }}>•</span>
          <span>Traceable Artifacts</span>
        </div>
      </motion.div>

      {/* Invariant principle statement */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.18 }}
        className="mx-auto text-center rounded-lg md:rounded-xl p-4 md:p-5"
        style={{
          border: "1px solid #C0C5CE",
          backgroundColor: "#FFFFFF",
          color: "#000033",
        }}
      >
        <span className="text-sm md:text-base font-semibold" style={{ letterSpacing: "0.04em" }}>
          Every transformation preserves evidence integrity and traceability.
        </span>
      </motion.div>

      {/* Transformation Pipeline - Visual Flow */}
      <motion.div
        initial={{ opacity: 0, scaleX: 0.96 }}
        animate={{ opacity: 1, scaleX: 1 }}
        transition={{ duration: 0.7, delay: 0.25 }}
        className="relative rounded-lg md:rounded-xl overflow-hidden"
        style={{
          backgroundColor: "#FFFFFF",
          border: "1px solid #C0C5CE",
        }}
      >
        {/* Five Stages - Stacked on Mobile, Grid on Desktop */}
        <div className="flex flex-col lg:grid lg:grid-cols-5">
          {TRANSFORMATION_STAGES.map((stage, index) => (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.35 + index * 0.08 }}
              onMouseEnter={() => setActiveStage(stage.id)}
              onMouseLeave={() => setActiveStage(null)}
              className="relative cursor-pointer transition-all duration-200 border-b lg:border-b-0 lg:border-r last:border-b-0 last:border-r-0"
              style={{
                backgroundColor: activeStage === stage.id ? "#F4F6F8" : "transparent",
                borderColor: "#E2E8F0",
                minHeight: "320px"
              }}
            >
              <div className="p-6 md:p-8 h-full flex flex-col">
                {/* Stage Number Badge */}
                <div
                  className="mb-3 px-2.5 py-1 rounded-md inline-block self-start text-xs font-bold"
                  style={{
                    backgroundColor: "var(--slide-navy)",
                    color: "#FFFFFF"
                  }}
                >
                  {index + 1}
                </div>

                {/* Layer Label */}
                <p
                  className="text-[9px] md:text-[10px] font-semibold uppercase tracking-widest mb-2"
                  style={{ color: "var(--slide-navy)", opacity: 0.5 }}
                >
                  {stage.layer}
                </p>

                {/* Stage Title */}
                <h4
                  className="text-xs md:text-sm font-bold uppercase mb-3"
                  style={{ color: "var(--slide-navy)", lineHeight: "1.25" }}
                >
                  {stage.label}
                </h4>

                {/* Description */}
                <p
                  className="text-[11px] md:text-xs mb-4"
                  style={{ color: "var(--slide-text-secondary)", lineHeight: "1.5" }}
                >
                  {stage.description}
                </p>

                {/* Platform Guarantee Badge */}
                <div className="mt-auto">
                  <div
                    className="px-2.5 py-1.5 rounded-lg border text-center"
                    style={{
                      borderColor: "var(--slide-border-subtle)",
                      backgroundColor: "var(--slide-bg-accent)"
                    }}
                  >
                    <p className="text-[9px] md:text-[10px] font-semibold uppercase tracking-wide" style={{ color: "var(--slide-navy)" }}>
                      {stage.guarantee}
                    </p>
                  </div>
                </div>
              </div>

              {/* Arrow Indicator (Desktop Only) */}
              {index < TRANSFORMATION_STAGES.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                  <div
                    style={{
                      width: 0,
                      height: 0,
                      borderTop: "8px solid transparent",
                      borderBottom: "8px solid transparent",
                      borderLeft: "10px solid #000033"
                    }}
                  />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Detail Panel - Appears on Hover */}
      {active && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="w-full rounded-lg md:rounded-xl border p-6 md:p-10"
          style={{
            backgroundColor: "#FFFFFF",
            borderColor: "#C0C5CE"
          }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
            {/* Transforms */}
            <div>
              <h5 className="text-xs md:text-sm font-bold uppercase tracking-wide mb-4" style={{ color: "#000033" }}>
                Transformations Applied
              </h5>
              <div className="space-y-3">
                {active.transforms.map((transform, idx) => (
                  <div key={idx} className="flex items-start gap-2.5">
                    <div
                      className="rounded-full flex-shrink-0 mt-1.5"
                      style={{
                        width: "6px",
                        height: "6px",
                        backgroundColor: "#000033"
                      }}
                    />
                    <p className="text-xs md:text-sm" style={{ color: "#4A5568", lineHeight: "1.5" }}>
                      {transform}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Input */}
            <div>
              <h5 className="text-xs md:text-sm font-bold uppercase tracking-wide mb-4" style={{ color: "#000033" }}>
                Input
              </h5>
              <p className="text-xs md:text-sm" style={{ color: "#4A5568", lineHeight: "1.6" }}>
                {active.input}
              </p>
            </div>

            {/* Output */}
            <div>
              <h5 className="text-xs md:text-sm font-bold uppercase tracking-wide mb-4" style={{ color: "#000033" }}>
                Output
              </h5>
              <p className="text-xs md:text-sm" style={{ color: "#4A5568", lineHeight: "1.6" }}>
                {active.output}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Bottom Foundation - Traceability */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="w-full rounded-lg md:rounded-xl p-6 md:p-8"
        style={{
          backgroundColor: "#000033"
        }}
      >
        <div className="text-center">
          <h4 className="text-sm md:text-base font-bold uppercase tracking-wide mb-3" style={{ color: "#FFFFFF" }}>
            Complete Audit Trail
          </h4>
          <p className="text-xs md:text-sm" style={{ color: "#FFFFFF", opacity: 0.88, lineHeight: "1.6" }}>
            Every output artifact includes a complete citation chain: Strategic Output → Element Mapping → Rule Evaluation → Structured Facts → Evidence Foundation Packet → Original Source Hash
          </p>
        </div>
      </motion.div>
    </div>
  );
}