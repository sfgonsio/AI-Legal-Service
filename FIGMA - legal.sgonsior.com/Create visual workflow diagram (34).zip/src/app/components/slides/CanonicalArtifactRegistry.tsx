import { motion } from "motion/react";
import { useState } from "react";

interface Artifact {
  id: string;
  name: string;
  artifactClass: "Evidence" | "Analysis" | "Pleading" | "Discovery" | "Motion" | "Trial" | "Post-Trial" | "Administrative";
  description: string;
  lifecycleStage: string;
  deterministicStage: string;
}

// Comprehensive artifact catalog organized by class
const ARTIFACT_CATALOG: Artifact[] = [
  // Evidence Class
  {
    id: "ART-EV-DOCUMENT",
    name: "Source Document",
    artifactClass: "Evidence",
    description: "Raw evidence file with cryptographic hash baseline",
    lifecycleStage: "Evidence Collection",
    deterministicStage: "INGESTION"
  },
  {
    id: "ART-EV-DEPOSITION",
    name: "Deposition Transcript",
    artifactClass: "Evidence",
    description: "Certified testimony transcript with line references",
    lifecycleStage: "Discovery",
    deterministicStage: "INGESTION"
  },
  {
    id: "ART-EV-EXHIBIT",
    name: "Trial Exhibit",
    artifactClass: "Evidence",
    description: "Court-admitted evidence with authentication record",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "INGESTION"
  },

  // Analysis Class
  {
    id: "ART-AN-FACTLIST",
    name: "Initial Fact List",
    artifactClass: "Analysis",
    description: "Extracted facts from client interview",
    lifecycleStage: "Client Intake",
    deterministicStage: "NORMALIZATION"
  },
  {
    id: "ART-AN-NORMALIZEDFACTS",
    name: "Normalized Facts",
    artifactClass: "Analysis",
    description: "Structured fact graph with source citations",
    lifecycleStage: "Fact Normalization",
    deterministicStage: "NORMALIZATION"
  },
  {
    id: "ART-AN-TIMELINE",
    name: "Case Timeline",
    artifactClass: "Analysis",
    description: "Chronological event sequence with source references",
    lifecycleStage: "Event Mapping",
    deterministicStage: "COMPOSITION"
  },
  {
    id: "ART-AN-COAMATRIX",
    name: "COA Coverage Matrix",
    artifactClass: "Analysis",
    description: "Element-to-evidence mapping showing coverage",
    lifecycleStage: "Legal Theory Formation",
    deterministicStage: "LEGAL ANALYSIS"
  },
  {
    id: "ART-AN-BURDENMAP",
    name: "Burden of Proof Map",
    artifactClass: "Analysis",
    description: "Element burden allocation with evidentiary support",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "LEGAL ANALYSIS"
  },

  // Pleading Class
  {
    id: "ART-PL-COMPLAINT",
    name: "Complaint",
    artifactClass: "Pleading",
    description: "Initial pleading with COA allegations and prayer for relief",
    lifecycleStage: "Pleading Drafting",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-PL-ANSWER",
    name: "Answer",
    artifactClass: "Pleading",
    description: "Defendant's response with admissions, denials, and affirmative defenses",
    lifecycleStage: "Pleading Drafting",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-PL-CROSSCOMPLAINT",
    name: "Cross-Complaint",
    artifactClass: "Pleading",
    description: "Defendant's claims against plaintiff or third parties",
    lifecycleStage: "Pleading Drafting",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-PL-AMENDMENT",
    name: "Amended Pleading",
    artifactClass: "Pleading",
    description: "Modified complaint or answer with tracked changes",
    lifecycleStage: "Pleading Drafting",
    deterministicStage: "DOCUMENT GENERATION"
  },

  // Discovery Class
  {
    id: "ART-DI-INTERROGATORIES",
    name: "Interrogatories",
    artifactClass: "Discovery",
    description: "Written questions to opposing party under oath",
    lifecycleStage: "Discovery",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-DI-RFP",
    name: "Requests for Production",
    artifactClass: "Discovery",
    description: "Document and ESI production requests",
    lifecycleStage: "Discovery",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-DI-RFA",
    name: "Requests for Admission",
    artifactClass: "Discovery",
    description: "Requests to admit or deny specific facts or documents",
    lifecycleStage: "Discovery",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-DI-SUBPOENA",
    name: "Subpoena",
    artifactClass: "Discovery",
    description: "Court order for testimony or document production",
    lifecycleStage: "Discovery",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-DI-DEPNOTICE",
    name: "Deposition Notice",
    artifactClass: "Discovery",
    description: "Notice of oral examination with topic list",
    lifecycleStage: "Discovery",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-DI-DEPOUTLINE",
    name: "Deposition Outline",
    artifactClass: "Discovery",
    description: "Question outline with evidentiary objectives",
    lifecycleStage: "Discovery",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-DI-RESPONSEMAP",
    name: "Discovery Response Map",
    artifactClass: "Discovery",
    description: "Correlation of responses to case theory",
    lifecycleStage: "Discovery",
    deterministicStage: "COVERAGE ANALYSIS"
  },

  // Motion Class
  {
    id: "ART-MO-DISMISS",
    name: "Motion to Dismiss",
    artifactClass: "Motion",
    description: "Pre-answer motion challenging legal sufficiency",
    lifecycleStage: "Motion Practice",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-MO-SUMMARYJUDGMENT",
    name: "Motion for Summary Judgment",
    artifactClass: "Motion",
    description: "Motion arguing no triable issue of material fact",
    lifecycleStage: "Motion Practice",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-MO-COMPEL",
    name: "Motion to Compel",
    artifactClass: "Motion",
    description: "Motion to enforce discovery obligations",
    lifecycleStage: "Motion Practice",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-MO-PROTECTIVE",
    name: "Motion for Protective Order",
    artifactClass: "Motion",
    description: "Motion to limit or prevent discovery",
    lifecycleStage: "Motion Practice",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-MO-OPPOSITION",
    name: "Opposition Brief",
    artifactClass: "Motion",
    description: "Response to opposing party's motion",
    lifecycleStage: "Motion Practice",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-MO-REPLY",
    name: "Reply Brief",
    artifactClass: "Motion",
    description: "Moving party's response to opposition",
    lifecycleStage: "Motion Practice",
    deterministicStage: "DOCUMENT GENERATION"
  },

  // Trial Class
  {
    id: "ART-TR-EXHIBITLIST",
    name: "Exhibit List",
    artifactClass: "Trial",
    description: "Catalog of trial exhibits with authentication",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-TR-WITNESSLIST",
    name: "Witness List",
    artifactClass: "Trial",
    description: "List of trial witnesses with summaries",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-TR-TRIALBRIEF",
    name: "Trial Brief",
    artifactClass: "Trial",
    description: "Pre-trial legal argument summary",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-TR-DIRECTOUTLINE",
    name: "Direct Examination Outline",
    artifactClass: "Trial",
    description: "Question outline for friendly witness",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-TR-CROSSOUTLINE",
    name: "Cross Examination Outline",
    artifactClass: "Trial",
    description: "Question outline for adverse witness",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-TR-JURYINSTRUCTIONS",
    name: "Proposed Jury Instructions",
    artifactClass: "Trial",
    description: "Requested instructions on law and verdict form",
    lifecycleStage: "Trial Preparation",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-TR-EVIDENCEMAP",
    name: "Trial Evidence Map",
    artifactClass: "Trial",
    description: "Real-time evidence-to-element tracking",
    lifecycleStage: "Trial Support",
    deterministicStage: "COVERAGE ANALYSIS"
  },

  // Post-Trial Class
  {
    id: "ART-PT-JUDGMENT",
    name: "Judgment Analysis",
    artifactClass: "Post-Trial",
    description: "Verdict evaluation with grounds for appeal",
    lifecycleStage: "Post-Trial",
    deterministicStage: "LEGAL ANALYSIS"
  },
  {
    id: "ART-PT-APPEALNOTICE",
    name: "Notice of Appeal",
    artifactClass: "Post-Trial",
    description: "Formal appeal initiation document",
    lifecycleStage: "Post-Trial",
    deterministicStage: "DOCUMENT GENERATION"
  },
  {
    id: "ART-PT-APPELLATEBRIEF",
    name: "Appellate Brief",
    artifactClass: "Post-Trial",
    description: "Legal argument on appeal with record citations",
    lifecycleStage: "Post-Trial",
    deterministicStage: "DOCUMENT GENERATION"
  },

  // Administrative Class
  {
    id: "ART-AD-INTERVIEW",
    name: "Client Interview Transcript",
    artifactClass: "Administrative",
    description: "Structured intake interview record",
    lifecycleStage: "Client Intake",
    deterministicStage: "INGESTION"
  },
  {
    id: "ART-AD-MATTER",
    name: "Matter Intake Record",
    artifactClass: "Administrative",
    description: "Case file initialization record",
    lifecycleStage: "Client Intake",
    deterministicStage: "INGESTION"
  },
  {
    id: "ART-AD-CONFLICT",
    name: "Conflict Check Report",
    artifactClass: "Administrative",
    description: "Law firm conflict validation",
    lifecycleStage: "Client Intake",
    deterministicStage: "INGESTION"
  },
  {
    id: "ART-AD-ENGAGEMENT",
    name: "Engagement Letter",
    artifactClass: "Administrative",
    description: "Attorney-client agreement with scope",
    lifecycleStage: "Client Intake",
    deterministicStage: "DOCUMENT GENERATION"
  }
];

const ARTIFACT_CLASSES = [
  "Evidence",
  "Analysis",
  "Pleading",
  "Discovery",
  "Motion",
  "Trial",
  "Post-Trial",
  "Administrative"
] as const;

export function CanonicalArtifactRegistry() {
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [expandedArtifact, setExpandedArtifact] = useState<string | null>(null);

  const filteredArtifacts = selectedClass
    ? ARTIFACT_CATALOG.filter(a => a.artifactClass === selectedClass)
    : ARTIFACT_CATALOG;

  const getClassColor = (artifactClass: string) => {
    const colors: Record<string, { bg: string; text: string }> = {
      "Evidence": { bg: "#E3F2FD", text: "#0D47A1" },
      "Analysis": { bg: "#F3E5F5", text: "#4A148C" },
      "Pleading": { bg: "#E8F5E9", text: "#1B5E20" },
      "Discovery": { bg: "#FFF3E0", text: "#E65100" },
      "Motion": { bg: "#FCE4EC", text: "#880E4F" },
      "Trial": { bg: "#E0F2F1", text: "#004D40" },
      "Post-Trial": { bg: "#F1F8E9", text: "#33691E" },
      "Administrative": { bg: "#ECEFF1", text: "#263238" }
    };
    return colors[artifactClass] || { bg: "#F5F5F5", text: "#424242" };
  };

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-4"
      >
        <div className="text-center">
          <h3 className="text-base md:text-lg font-bold uppercase tracking-wide mb-3" style={{ color: '#000033' }}>
            CANONICAL ARTIFACT REGISTRY
          </h3>
          <p className="text-sm md:text-base mb-2" style={{ color: '#4A5568' }}>
            Comprehensive catalog of {ARTIFACT_CATALOG.length} litigation artifacts organized by class, lifecycle stage, and deterministic execution pipeline
          </p>
        </div>

        {/* Class Filter */}
        <div className="flex flex-wrap gap-2 justify-center">
          <button
            onClick={() => setSelectedClass(null)}
            className="px-3 py-1.5 text-xs rounded-lg transition-all font-semibold"
            style={{
              backgroundColor: selectedClass === null ? '#000033' : '#FFFFFF',
              color: selectedClass === null ? '#FFFFFF' : '#4A5568',
              border: '1px solid #C0C5CE'
            }}
          >
            All Classes ({ARTIFACT_CATALOG.length})
          </button>
          {ARTIFACT_CLASSES.map((artifactClass) => {
            const count = ARTIFACT_CATALOG.filter(a => a.artifactClass === artifactClass).length;
            const colors = getClassColor(artifactClass);
            return (
              <button
                key={artifactClass}
                onClick={() => setSelectedClass(artifactClass)}
                className="px-3 py-1.5 text-xs rounded-lg transition-all font-semibold"
                style={{
                  backgroundColor: selectedClass === artifactClass ? colors.bg : '#FFFFFF',
                  color: selectedClass === artifactClass ? colors.text : '#4A5568',
                  border: `1px solid ${selectedClass === artifactClass ? colors.text : '#C0C5CE'}`
                }}
              >
                {artifactClass} ({count})
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Artifact Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        {filteredArtifacts.map((artifact, index) => {
          const colors = getClassColor(artifact.artifactClass);
          const isExpanded = expandedArtifact === artifact.id;

          return (
            <motion.div
              key={artifact.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * index }}
              onClick={() => setExpandedArtifact(isExpanded ? null : artifact.id)}
              className="rounded-lg border-2 p-4 cursor-pointer transition-all"
              style={{
                borderColor: isExpanded ? colors.text : '#C0C5CE',
                backgroundColor: isExpanded ? colors.bg : '#FFFFFF'
              }}
            >
              {/* Artifact Class Badge */}
              <div className="mb-3">
                <span
                  className="text-[10px] px-2 py-1 rounded uppercase tracking-wide font-semibold"
                  style={{
                    backgroundColor: colors.bg,
                    color: colors.text
                  }}
                >
                  {artifact.artifactClass}
                </span>
              </div>

              {/* Artifact ID */}
              <p className="text-[10px] font-mono mb-2" style={{ color: '#718096' }}>
                {artifact.id}
              </p>

              {/* Artifact Name */}
              <h4 className="text-sm font-bold mb-2" style={{ color: '#000033' }}>
                {artifact.name}
              </h4>

              {/* Description */}
              <p className="text-xs mb-3" style={{ color: '#4A5568', lineHeight: '1.5' }}>
                {artifact.description}
              </p>

              {/* Metadata - only show when expanded */}
              {isExpanded && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="pt-3 border-t space-y-2"
                  style={{ borderColor: '#E2E8F0' }}
                >
                  <div>
                    <p className="text-[10px] uppercase tracking-wide font-semibold mb-1" style={{ color: '#718096' }}>
                      Lifecycle Stage
                    </p>
                    <p className="text-xs" style={{ color: '#000033' }}>
                      {artifact.lifecycleStage}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wide font-semibold mb-1" style={{ color: '#718096' }}>
                      Deterministic Stage
                    </p>
                    <p className="text-xs font-mono" style={{ color: '#000033' }}>
                      {artifact.deterministicStage}
                    </p>
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </motion.div>

      {/* Registry Stats */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: '#FFFFFF',
          borderTop: '3px solid #000033'
        }}
      >
        <h4 className="font-bold text-sm md:text-base uppercase tracking-wide mb-4" style={{ color: '#000033' }}>
          REGISTRY ARCHITECTURE
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs" style={{ color: '#4A5568' }}>
          <div>
            <span className="font-semibold" style={{ color: '#000033' }}>Artifact Hierarchy:</span> Every artifact follows Class → Category → Type → ID structure enabling systematic organization across case types and jurisdictions.
          </div>
          <div>
            <span className="font-semibold" style={{ color: '#000033' }}>Lifecycle Mapping:</span> Each artifact maps to specific litigation stages with clear triggers for production and validation workflows.
          </div>
          <div>
            <span className="font-semibold" style={{ color: '#000033' }}>Deterministic Pipeline:</span> All artifacts flow through standard processing stages (INGESTION → NORMALIZATION → COMPOSITION → LEGAL ANALYSIS → DOCUMENT GENERATION).
          </div>
        </div>
      </motion.div>
    </div>
  );
}
