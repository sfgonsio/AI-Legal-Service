import { motion } from "motion/react";
import { useState } from "react";

interface WorkflowStage {
  id: number;
  title: string;
  shortTitle: string; // For compact display
  subtitle: string;
  artifacts: string[];
  description: string;
}

const WORKFLOW_STAGES: WorkflowStage[] = [
  {
    id: 1,
    title: "Client Intake",
    shortTitle: "Intake",
    subtitle: "Capture case narrative and initial evidence",
    description: "Documents and client information flow into TrialForge",
    artifacts: ["Interview transcript", "Matter record", "Initial facts", "Evidence uploads"]
  },
  {
    id: 2,
    title: "Early Case Assessment",
    shortTitle: "Early Assessment",
    subtitle: "Strategic analysis and case theory development",
    description: "Timeline graphics appear from structured facts",
    artifacts: ["Fact records", "Event timeline", "Case theory", "Damages estimate"]
  },
  {
    id: 3,
    title: "Pleadings",
    shortTitle: "Pleadings",
    subtitle: "Initial court filings and case framing",
    description: "Legal documents assemble from arguments",
    artifacts: ["Complaint", "Answer", "Counterclaims", "Amended pleadings"]
  },
  {
    id: 4,
    title: "Discovery",
    shortTitle: "Discovery",
    subtitle: "Evidence exchange and information gathering",
    description: "Evidence network graphic emerges",
    artifacts: ["Interrogatories", "Requests for Production", "Requests for Admission", "Subpoenas"]
  },
  {
    id: 5,
    title: "Depositions",
    shortTitle: "Depositions",
    subtitle: "Witness testimony and evidence building",
    description: "Transcripts transform into structured evidence nodes",
    artifacts: ["Deposition outlines", "Exhibits", "Deposition transcript", "Deposition summary"]
  },
  {
    id: 6,
    title: "Motion Practice",
    shortTitle: "Motions",
    subtitle: "Pre-trial legal arguments and rulings",
    description: "Arguments form legal reasoning structures",
    artifacts: ["Motion to dismiss", "Motion to compel", "Summary judgment", "Opposition briefs"]
  },
  {
    id: 7,
    title: "Trial Preparation",
    shortTitle: "Trial Prep",
    subtitle: "Evidence organization and presentation planning",
    description: "Evidence maps to witnesses and exhibits",
    artifacts: ["Witness lists", "Exhibit lists", "Trial briefs", "Jury instructions"]
  },
  {
    id: 8,
    title: "Trial",
    shortTitle: "Trial",
    subtitle: "Courtroom presentation and advocacy",
    description: "Evidence flows into courtroom proceedings",
    artifacts: ["Admitted exhibits", "Trial transcript", "Court rulings", "Verdict"]
  },
  {
    id: 9,
    title: "Post-Trial / Appeal",
    shortTitle: "Appeal",
    subtitle: "Judgment and appellate proceedings",
    description: "Record supports appellate arguments",
    artifacts: ["Judgment", "Notice of appeal", "Appeal brief", "Appellate decision"]
  }
];

export function LitigationWorkflowMap() {
  const [selectedStage, setSelectedStage] = useState<number | null>(null);

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center space-y-3"
      >
        <h3 className="text-lg md:text-xl font-bold uppercase tracking-wide" style={{ color: 'var(--slide-navy)' }}>
          TRIALFORGE LITIGATION WORKFLOW MAP
        </h3>
        <p className="text-base md:text-lg font-semibold" style={{ color: 'var(--slide-text-secondary)' }}>
          Where TrialForge Operates in the Litigation Lifecycle
        </p>
        <p className="text-sm" style={{ color: 'var(--slide-text-muted)' }}>
          Nine critical stages from client intake through post-trial proceedings
        </p>
      </motion.div>

      {/* Desktop: Horizontal Timeline - FIXED for proper text display */}
      <div className="hidden xl:block overflow-x-auto">
        <div className="relative min-w-[1100px]">
          {/* Timeline Bar */}
          <div 
            className="absolute top-12 left-0 right-0 h-1"
            style={{ backgroundColor: 'var(--slide-royal-blue)' }}
          />

          {/* Stage Cards */}
          <div className="grid grid-cols-9 gap-2">
            {WORKFLOW_STAGES.map((stage, index) => {
              const isSelected = selectedStage === stage.id;
              
              return (
                <motion.div
                  key={stage.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * index }}
                  onMouseEnter={() => setSelectedStage(stage.id)}
                  onMouseLeave={() => setSelectedStage(null)}
                  className="relative cursor-pointer"
                >
                  {/* Stage Number Badge */}
                  <div className="flex justify-center mb-2">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-base z-10 transition-all"
                      style={{
                        backgroundColor: isSelected ? 'var(--slide-deep-blue)' : 'var(--slide-royal-blue)',
                        color: 'var(--slide-white)',
                        transform: isSelected ? 'scale(1.15)' : 'scale(1)'
                      }}
                    >
                      {stage.id}
                    </div>
                  </div>

                  {/* Stage Card - FIXED sizing */}
                  <div 
                    className="rounded-lg border-2 px-2 py-3 transition-all flex flex-col justify-between"
                    style={{
                      backgroundColor: isSelected ? 'var(--slide-light-blue)' : 'var(--slide-white)',
                      borderColor: isSelected ? 'var(--slide-royal-blue)' : 'var(--slide-border-subtle)',
                      borderWidth: isSelected ? '3px' : '2px',
                      minHeight: '180px',
                      maxHeight: '180px'
                    }}
                  >
                    {/* Title - Full text, proper wrapping */}
                    <h4 
                      className="text-[11px] font-bold leading-tight mb-2 break-words hyphens-auto" 
                      style={{ color: 'var(--slide-navy)' }}
                    >
                      {stage.title}
                    </h4>
                    
                    {/* Subtitle - Compact */}
                    <p 
                      className="text-[9px] leading-tight break-words" 
                      style={{ color: 'var(--slide-text-muted)' }}
                    >
                      {stage.subtitle}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tablet: 3-column grid */}
      <div className="hidden md:grid xl:hidden grid-cols-3 gap-4">
        {WORKFLOW_STAGES.map((stage, index) => {
          const isSelected = selectedStage === stage.id;
          
          return (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * index }}
              onMouseEnter={() => setSelectedStage(stage.id)}
              onMouseLeave={() => setSelectedStage(null)}
              className="rounded-lg border-2 p-4 cursor-pointer transition-all"
              style={{
                backgroundColor: isSelected ? 'var(--slide-light-blue)' : 'var(--slide-white)',
                borderColor: isSelected ? 'var(--slide-royal-blue)' : 'var(--slide-border-subtle)'
              }}
            >
              <div className="flex items-start gap-3 mb-3">
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 font-bold"
                  style={{
                    backgroundColor: 'var(--slide-royal-blue)',
                    color: 'var(--slide-white)'
                  }}
                >
                  {stage.id}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold mb-1 break-words" style={{ color: 'var(--slide-navy)' }}>
                    {stage.title}
                  </h4>
                </div>
              </div>
              <p className="text-xs leading-relaxed" style={{ color: 'var(--slide-text-muted)' }}>
                {stage.subtitle}
              </p>
            </motion.div>
          );
        })}
      </div>

      {/* Mobile: Vertical list */}
      <div className="md:hidden space-y-3">
        {WORKFLOW_STAGES.map((stage, index) => {
          const isSelected = selectedStage === stage.id;
          
          return (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * index }}
              onMouseEnter={() => setSelectedStage(stage.id)}
              onMouseLeave={() => setSelectedStage(null)}
              className="rounded-lg border-2 p-4 cursor-pointer transition-all"
              style={{
                backgroundColor: isSelected ? 'var(--slide-light-blue)' : 'var(--slide-white)',
                borderColor: isSelected ? 'var(--slide-royal-blue)' : 'var(--slide-border-subtle)'
              }}
            >
              <div className="flex items-start gap-3">
                <div 
                  className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-lg"
                  style={{
                    backgroundColor: 'var(--slide-royal-blue)',
                    color: 'var(--slide-white)'
                  }}
                >
                  {stage.id}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-base font-bold mb-2 break-words" style={{ color: 'var(--slide-navy)' }}>
                    {stage.title}
                  </h4>
                  <p className="text-sm leading-relaxed" style={{ color: 'var(--slide-text-secondary)' }}>
                    {stage.subtitle}
                  </p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Detail Panel - Shows when stage is selected */}
      {selectedStage !== null && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="rounded-lg border-2 p-6"
          style={{
            backgroundColor: 'var(--slide-bg-primary)',
            borderColor: 'var(--slide-navy)'
          }}
        >
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div 
                className="w-14 h-14 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-xl"
                style={{
                  backgroundColor: 'var(--slide-deep-blue)',
                  color: 'var(--slide-white)'
                }}
              >
                {selectedStage}
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="text-lg font-bold mb-2" style={{ color: 'var(--slide-navy)' }}>
                  {WORKFLOW_STAGES[selectedStage - 1].title}
                </h4>
                <p className="text-sm mb-2" style={{ color: 'var(--slide-text-secondary)' }}>
                  {WORKFLOW_STAGES[selectedStage - 1].subtitle}
                </p>
                <p className="text-sm" style={{ color: 'var(--slide-text-muted)' }}>
                  {WORKFLOW_STAGES[selectedStage - 1].description}
                </p>
              </div>
            </div>

            {/* Key Artifacts */}
            <div className="pt-4 border-t" style={{ borderColor: 'var(--slide-border-light)' }}>
              <p className="text-xs uppercase tracking-wide font-semibold mb-3" style={{ color: 'var(--slide-text-muted)' }}>
                Key Artifacts Generated
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {WORKFLOW_STAGES[selectedStage - 1].artifacts.map((artifact, idx) => (
                  <div 
                    key={idx}
                    className="text-xs px-3 py-2 rounded font-medium break-words"
                    style={{
                      backgroundColor: 'var(--slide-light-blue)',
                      color: 'var(--slide-deep-blue)',
                      border: '1px solid var(--slide-royal-blue)'
                    }}
                  >
                    {artifact}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* TrialForge Power Grid */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: 'var(--slide-navy)',
          color: 'var(--slide-white)'
        }}
      >
        <div className="text-center space-y-3">
          <h4 className="text-lg md:text-xl font-bold uppercase tracking-wide">
            TRIALFORGE LITIGATION INTELLIGENCE ENGINE
          </h4>
          <p className="text-base md:text-lg font-semibold opacity-90">
            Transforming Evidence into Legal Strategy Across the Entire Case Lifecycle
          </p>
          <div className="pt-4 flex flex-wrap justify-center gap-3">
            {[
              "Evidence Layer",
              "Artifact Layer", 
              "Program Layer",
              "Agent Layer",
              "Human Layer"
            ].map((layer) => (
              <span 
                key={layer}
                className="text-xs px-3 py-1.5 rounded-full font-semibold"
                style={{
                  backgroundColor: 'var(--slide-royal-blue)',
                  color: 'var(--slide-white)'
                }}
              >
                {layer}
              </span>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Platform Coverage Summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.0 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: 'var(--slide-bg-accent)',
          border: '1px solid var(--slide-border-secondary)'
        }}
      >
        <p className="text-sm text-center leading-relaxed" style={{ color: 'var(--slide-text-secondary)' }}>
          <span className="font-bold" style={{ color: 'var(--slide-navy)' }}>Complete Lifecycle Coverage:</span> TrialForge powers every stage of litigation—from initial client intake through post-trial appeals—with its five-layer intelligence architecture transforming raw evidence into court-ready legal artifacts at each phase.
        </p>
      </motion.div>
    </div>
  );
}
