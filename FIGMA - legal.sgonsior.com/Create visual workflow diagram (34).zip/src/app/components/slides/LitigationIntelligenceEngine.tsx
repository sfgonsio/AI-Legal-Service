import { motion } from "motion/react";
import { useState } from "react";

interface Layer {
  id: number;
  name: string;
  label: string;
  subtitle: string;
  description: string;
  components: string[];
  keyFunction: string;
  color: {
    bg: string;
    border: string;
    text: string;
  };
}

const LAYERS: Layer[] = [
  {
    id: 5,
    name: "Human Decision Layer",
    label: "HUMAN LAYER",
    subtitle: "Review • Strategy • Approval",
    description: "Attorneys maintain full control over case strategy and final work product approval",
    keyFunction: "Attorney reviews all outputs and maintains strategic control",
    components: ["Attorney Review", "Client Interface", "Court Filing", "Strategic Decision"],
    color: {
      bg: "#F0F9FF",
      border: "#0077B6",
      text: "#003D82"
    }
  },
  {
    id: 4,
    name: "AI Agent Layer",
    label: "AGENT LAYER",
    subtitle: "Legal Reasoning & Drafting",
    description: "AI reasoning agents perform bounded legal analysis and document drafting",
    keyFunction: "AI assists with legal reasoning within defined boundaries",
    components: ["Interview Agent", "Mapping Agent", "COA Reasoner", "Opposition Agent"],
    color: {
      bg: "#E6F2FF",
      border: "#0077B6",
      text: "#003D82"
    }
  },
  {
    id: 3,
    name: "Deterministic Processing Layer",
    label: "PROGRAM LAYER",
    subtitle: "Structured Legal Analysis",
    description: "Deterministic programs execute repeatable legal processing and analysis",
    keyFunction: "Programs provide consistent, reproducible legal processing",
    components: ["Fact Normalization", "Tagging Engine", "Composite Engine", "COA Engine", "Coverage Analysis", "Discovery Packet"],
    color: {
      bg: "#E6F2FF",
      border: "#48CAE4",
      text: "#003D82"
    }
  },
  {
    id: 2,
    name: "Litigation Artifact Layer",
    label: "ARTIFACT LAYER",
    subtitle: "Structured Case Intelligence",
    description: "Organized repository of litigation artifacts including facts, timelines, and legal documents",
    keyFunction: "Stores and organizes all structured case information",
    components: ["Normalized Facts", "Case Timeline", "Evidence Graph", "COA Matrix", "Discovery Files", "Legal Documents"],
    color: {
      bg: "#ECEFF1",
      border: "#90A4AE",
      text: "#2C3E50"
    }
  },
  {
    id: 1,
    name: "Evidence Layer",
    label: "EVIDENCE LAYER",
    subtitle: "Source of Truth",
    description: "Raw evidence sources feeding the intelligence engine with cryptographic hash verification",
    keyFunction: "Immutable evidence foundation with cryptographic verification",
    components: ["Documents", "Contracts", "Emails", "Financial Records", "Transcripts", "Photos", "Audio"],
    color: {
      bg: "#F8FAFC",
      border: "#546E7A",
      text: "#2C3E50"
    }
  }
];

export function LitigationIntelligenceEngine() {
  const [selectedLayer, setSelectedLayer] = useState<number | null>(null);

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center space-y-3"
      >
        <h3 className="text-lg md:text-xl font-bold uppercase tracking-wide" style={{ color: 'var(--slide-navy)' }}>
          TRIALFORGE INTELLIGENCE ENGINE
        </h3>
        <p className="text-base md:text-lg font-semibold" style={{ color: 'var(--slide-text-secondary)' }}>
          Transforming Evidence into Court-Ready Litigation Artifacts
        </p>
        <p className="text-sm" style={{ color: 'var(--slide-text-muted)' }}>
          Five-layer architecture with upward information flow and attorney control at the top
        </p>
      </motion.div>

      {/* Information Flow Arrow - Desktop Only */}
      <div className="hidden md:flex justify-center items-center gap-3 py-4">
        <div className="text-center space-y-2">
          <svg width="48" height="120" viewBox="0 0 48 120" className="mx-auto">
            <defs>
              <linearGradient id="flowGradient" x1="0%" y1="100%" x2="0%" y2="0%">
                <stop offset="0%" stopColor="#546E7A" />
                <stop offset="100%" stopColor="#0077B6" />
              </linearGradient>
            </defs>
            <path d="M24 120 L24 10 M14 20 L24 10 L34 20" stroke="url(#flowGradient)" strokeWidth="4" fill="none" />
          </svg>
          <div className="text-xs font-bold uppercase tracking-wide" style={{ color: 'var(--slide-royal-blue)' }}>
            Information Flows Upward
          </div>
          <div className="text-xs" style={{ color: 'var(--slide-text-muted)' }}>
            Raw Evidence → Structured Artifacts → Court Filings
          </div>
        </div>
      </div>

      {/* Layer Stack */}
      <div className="space-y-3">
        {LAYERS.map((layer, index) => {
          const isSelected = selectedLayer === layer.id;
          
          return (
            <motion.div
              key={layer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
              onMouseEnter={() => setSelectedLayer(layer.id)}
              onMouseLeave={() => setSelectedLayer(null)}
              className="relative rounded-lg border-2 p-5 md:p-6 transition-all duration-200 cursor-pointer"
              style={{
                backgroundColor: isSelected ? layer.color.bg : 'var(--slide-white)',
                borderColor: isSelected ? layer.color.border : 'var(--slide-border-subtle)',
                borderWidth: isSelected ? '3px' : '2px',
                boxShadow: isSelected ? 'var(--slide-shadow-md)' : 'none'
              }}
            >
              {/* Layer Header */}
              <div className="flex items-start gap-4">
                <div 
                  className="w-12 h-12 md:w-14 md:h-14 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-lg md:text-xl"
                  style={{
                    backgroundColor: layer.color.border,
                    color: 'var(--slide-white)'
                  }}
                >
                  {layer.id}
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className="text-base md:text-lg font-bold mb-1" style={{ color: 'var(--slide-navy)' }}>
                    {layer.name}
                  </h4>
                  <p className="text-sm font-semibold mb-2" style={{ color: layer.color.text }}>
                    {layer.subtitle}
                  </p>
                  <p className="text-sm mb-3" style={{ color: 'var(--slide-text-secondary)' }}>
                    {layer.description}
                  </p>

                  {/* Key Function - Always Visible */}
                  <div 
                    className="inline-flex items-start gap-2 px-3 py-2 rounded-lg text-xs font-medium"
                    style={{
                      backgroundColor: 'var(--slide-bg-accent)',
                      border: '1px solid var(--slide-border-secondary)'
                    }}
                  >
                    <span className="font-bold" style={{ color: 'var(--slide-navy)' }}>KEY:</span>
                    <span style={{ color: 'var(--slide-text-secondary)' }}>{layer.keyFunction}</span>
                  </div>
                </div>
              </div>

              {/* Components - Show on Hover/Selected */}
              {isSelected && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 pt-4 border-t"
                  style={{ borderColor: 'var(--slide-border-light)' }}
                >
                  <p className="text-xs uppercase tracking-wide font-semibold mb-3" style={{ color: 'var(--slide-text-muted)' }}>
                    System Components
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {layer.components.map((component, idx) => (
                      <motion.span
                        key={idx}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.05 * idx }}
                        className="text-xs px-3 py-1.5 rounded-full font-medium"
                        style={{
                          backgroundColor: layer.color.bg,
                          color: layer.color.text,
                          border: `1px solid ${layer.color.border}`
                        }}
                      >
                        {component}
                      </motion.span>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Transformation Pipeline Summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: 'var(--slide-white)',
          borderTop: '3px solid var(--slide-navy)'
        }}
      >
        <h4 className="font-bold text-sm md:text-base uppercase tracking-wide mb-4" style={{ color: 'var(--slide-navy)' }}>
          EVIDENCE TRANSFORMATION FLOW
        </h4>
        <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3">
          {[
            { label: "Raw Evidence", layer: "L1" },
            { label: "Structured Facts", layer: "L2" },
            { label: "Legal Analysis", layer: "L3" },
            { label: "AI Reasoning", layer: "L4" },
            { label: "Attorney Approval", layer: "L5" }
          ].map((step, idx) => (
            <div key={step.label} className="flex items-center gap-2 md:gap-3">
              <div className="text-center">
                <div 
                  className="px-3 md:px-4 py-2 md:py-2.5 rounded-lg font-semibold text-xs md:text-sm"
                  style={{
                    backgroundColor: 'var(--slide-light-blue)',
                    color: 'var(--slide-deep-blue)',
                    border: '2px solid var(--slide-royal-blue)'
                  }}
                >
                  <div className="font-bold mb-0.5">{step.label}</div>
                  <div className="text-[10px] opacity-75">{step.layer}</div>
                </div>
              </div>
              {idx < 4 && (
                <svg width="20" height="20" viewBox="0 0 20 20" className="flex-shrink-0">
                  <path d="M2 10 L18 10 M13 5 L18 10 L13 15" stroke="var(--slide-royal-blue)" strokeWidth="2.5" fill="none" />
                </svg>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Core Principles */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        {[
          {
            title: "Attorney Control",
            description: "Humans maintain strategic control at Layer 5"
          },
          {
            title: "Traceable Processing",
            description: "Every artifact traces back to source evidence"
          },
          {
            title: "Layered Governance",
            description: "Clear separation ensures quality and compliance"
          }
        ].map((principle, idx) => (
          <motion.div
            key={principle.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 + (idx * 0.1) }}
            className="rounded-lg p-5 border-2"
            style={{
              backgroundColor: 'var(--slide-bg-accent)',
              borderColor: 'var(--slide-border-secondary)'
            }}
          >
            <h5 className="text-sm font-bold uppercase tracking-wide mb-2" style={{ color: 'var(--slide-navy)' }}>
              {principle.title}
            </h5>
            <p className="text-sm leading-relaxed" style={{ color: 'var(--slide-text-secondary)' }}>
              {principle.description}
            </p>
          </motion.div>
        ))}
      </motion.div>

      {/* Key Takeaway */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: 'var(--slide-navy)',
          color: 'var(--slide-white)'
        }}
      >
        <p className="text-sm md:text-base text-center">
          <span className="font-bold">The TrialForge Architecture:</span> Information flows upward from raw evidence (Layer 1) through structured processing (Layers 2-4) to attorney-controlled strategic decision-making (Layer 5). Every transformation is traceable, reproducible, and governed.
        </p>
      </motion.div>
    </div>
  );
}