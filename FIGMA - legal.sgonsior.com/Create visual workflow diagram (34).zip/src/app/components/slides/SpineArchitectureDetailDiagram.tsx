import { motion } from "motion/react";

// Deep Dive: The Spine Architecture
// Central nervous system for legal intelligence platform
export function SpineArchitectureDetailDiagram() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1400px] px-4 space-y-6"
    >
      
      {/* SPINE OVERVIEW */}
      <div className="p-6 bg-slate-900 border-2 border-blue-500 rounded-lg text-white">
        <h3 className="text-lg font-bold mb-3 uppercase tracking-wider text-center">
          The System Spine — Central Coordination Layer
        </h3>
        <p className="text-sm leading-relaxed text-center opacity-90 mb-4">
          Like the human spinal cord, the System Spine is the central nervous system that connects all platform 
          components with traceable signals, ensuring transparency, reproducibility, and legal defensibility.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          <PrincipleBox>All actions are traceable</PrincipleBox>
          <PrincipleBox>All decisions are reproducible</PrincipleBox>
          <PrincipleBox>All outputs are auditable</PrincipleBox>
        </div>
      </div>

      {/* FIVE CORE FUNCTIONS */}
      <div className="space-y-4">
        <h3 className="text-base font-bold uppercase tracking-wide text-center border-b-2 border-slate-300 pb-2">
          Five Core Functions of the Spine
        </h3>

        {/* FUNCTION 1: WORKFLOW ORCHESTRATION */}
        <SpineFunction
          number="1"
          title="Workflow Orchestration"
          color="#1e40af"
          description="Routes tasks and signals between components in a structured, deterministic manner"
        >
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <DetailBox>
                <strong>Input Processing:</strong> Client narrative arrives → Spine creates case signal → Routes to Interview Agent
              </DetailBox>
              <DetailBox>
                <strong>Stage Transitions:</strong> Tracks workflow state from intake → analysis → output
              </DetailBox>
              <DetailBox>
                <strong>Task Queue:</strong> Manages agent execution order based on dependencies
              </DetailBox>
              <DetailBox>
                <strong>Signal Routing:</strong> Connects Interview Agent → Mapping Agent → COA Reasoner → Coverage Engine
              </DetailBox>
            </div>
            <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
              <p className="text-xs opacity-80">
                <strong>Key Principle:</strong> No component operates in isolation. Every step is coordinated through the spine.
              </p>
            </div>
          </div>
        </SpineFunction>

        {/* FUNCTION 2: STATE MANAGEMENT */}
        <SpineFunction
          number="2"
          title="State Management"
          color="#1e3a8a"
          description="Maintains consistent state across the entire platform for every case and entity"
        >
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <DetailBox>
                <strong>Case State:</strong> Tracks which agents have processed the case and what stage it's in
              </DetailBox>
              <DetailBox>
                <strong>Entity State:</strong> Maintains structured facts about parties, events, documents
              </DetailBox>
              <DetailBox>
                <strong>Evidence State:</strong> Links evidence to facts and facts to legal elements
              </DetailBox>
              <DetailBox>
                <strong>Coverage State:</strong> Tracks element coverage status (strong/weak/unknown/not_supported)
              </DetailBox>
            </div>
            <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
              <p className="text-xs opacity-80">
                <strong>Key Principle:</strong> State is the single source of truth. All components read from and write to spine state.
              </p>
            </div>
          </div>
        </SpineFunction>

        {/* FUNCTION 3: AGENT COORDINATION */}
        <SpineFunction
          number="3"
          title="Agent Coordination"
          color="#0f172a"
          description="Manages AI agent execution, prevents conflicts, and ensures deterministic sequencing"
        >
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <DetailBox>
                <strong>Sequential Execution:</strong> Agents execute in order — Interview → Mapping → COA Reasoner
              </DetailBox>
              <DetailBox>
                <strong>Agent Registry:</strong> Tracks which agents are available and their capabilities
              </DetailBox>
              <DetailBox>
                <strong>Input Preparation:</strong> Spine prepares context and state for each agent execution
              </DetailBox>
              <DetailBox>
                <strong>Output Collection:</strong> Spine receives agent output and updates system state
              </DetailBox>
            </div>
            <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
              <p className="text-xs opacity-80">
                <strong>Key Principle:</strong> Agents are specialized tools. The spine decides when and how they execute.
              </p>
            </div>
          </div>
        </SpineFunction>

        {/* FUNCTION 4: AUDIT LEDGER */}
        <SpineFunction
          number="4"
          title="Audit Ledger"
          color="#172554"
          description="Records every action, decision, and state change for legal defensibility and traceability"
        >
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <DetailBox>
                <strong>Action Logging:</strong> Every agent execution, input, and output is recorded with timestamp
              </DetailBox>
              <DetailBox>
                <strong>State Change Tracking:</strong> Every modification to case state is logged with before/after snapshots
              </DetailBox>
              <DetailBox>
                <strong>Decision Provenance:</strong> Every coverage determination is linked to supporting evidence and reasoning
              </DetailBox>
              <DetailBox>
                <strong>Reproduction Guarantee:</strong> Any case can be replayed from audit ledger to verify results
              </DetailBox>
            </div>
            <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
              <p className="text-xs opacity-80">
                <strong>Key Principle:</strong> Litigation-grade defensibility requires complete traceability. The audit ledger is non-negotiable.
              </p>
            </div>
          </div>
        </SpineFunction>

        {/* FUNCTION 5: DETERMINISTIC EXECUTION */}
        <SpineFunction
          number="5"
          title="Deterministic Execution"
          color="#0c4a6e"
          description="Ensures reproducible results by controlling non-deterministic components and validating outputs"
        >
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <DetailBox>
                <strong>AI Agent Control:</strong> Agent outputs are validated against schemas and rules before acceptance
              </DetailBox>
              <DetailBox>
                <strong>Pattern Module Execution:</strong> Legal frameworks execute deterministically with no randomness
              </DetailBox>
              <DetailBox>
                <strong>Coverage Engine:</strong> Evidence evaluation follows strict rules based on CA Evidence Code
              </DetailBox>
              <DetailBox>
                <strong>Version Control:</strong> All pattern modules and rules are versioned for reproducibility
              </DetailBox>
            </div>
            <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
              <p className="text-xs opacity-80">
                <strong>Key Principle:</strong> Same input + same rules = same output, every time. No hallucinations, no guessing.
              </p>
            </div>
          </div>
        </SpineFunction>
      </div>

      {/* SPINE ARCHITECTURE DIAGRAM */}
      <div className="space-y-3">
        <h3 className="text-base font-bold uppercase tracking-wide text-center border-b-2 border-slate-300 pb-2">
          Spine Architecture Flow
        </h3>
        <div className="space-y-2">
          
          {/* INPUT LAYER */}
          <ArchBox color="#1e40af">
            <div className="text-center">
              <div className="font-bold text-sm mb-1">CLIENT INPUT</div>
              <div className="text-xs opacity-70">Unstructured narrative and documents</div>
            </div>
          </ArchBox>

          <FlowArrow />

          {/* SPINE CORE */}
          <ArchBox color="#0f172a">
            <div className="border-2 border-blue-400 p-4 rounded">
              <div className="font-bold text-base mb-3 text-center uppercase tracking-wider">
                SYSTEM SPINE CORE
              </div>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs text-center">
                <SpineModule>Workflow Router</SpineModule>
                <SpineModule>State Manager</SpineModule>
                <SpineModule>Agent Coordinator</SpineModule>
                <SpineModule>Audit Logger</SpineModule>
                <SpineModule>Execution Controller</SpineModule>
              </div>
            </div>
          </ArchBox>

          <FlowArrow />

          {/* AI AGENTS */}
          <ArchBox color="#6366f1">
            <div className="text-center mb-2">
              <div className="font-bold text-sm mb-1">AI AGENT LAYER</div>
              <div className="text-xs opacity-70">Coordinated through spine</div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
              <AgentBox>Interview Agent</AgentBox>
              <AgentBox>Mapping Agent</AgentBox>
              <AgentBox>COA Reasoner</AgentBox>
            </div>
          </ArchBox>

          <FlowArrow />

          {/* DETERMINISTIC PROGRAMS */}
          <ArchBox color="#8b5cf6">
            <div className="text-center mb-2">
              <div className="font-bold text-sm mb-1">DETERMINISTIC PROGRAM LAYER</div>
              <div className="text-xs opacity-70">No AI — pure legal logic</div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <ProgramBox>Pattern Modules</ProgramBox>
              <ProgramBox>Coverage Engine</ProgramBox>
              <ProgramBox>Element Evaluator</ProgramBox>
              <ProgramBox>Evidence Mapper</ProgramBox>
            </div>
          </ArchBox>

          <FlowArrow />

          {/* OUTPUT LAYER */}
          <ArchBox color="#059669">
            <div className="text-center">
              <div className="font-bold text-sm mb-1">ATTORNEY OUTPUT</div>
              <div className="text-xs opacity-70">Structured legal analysis with full traceability</div>
            </div>
          </ArchBox>

        </div>
      </div>

      {/* KEY INSIGHT */}
      <div className="p-5 bg-slate-900 border-2 border-blue-500 rounded-lg text-white">
        <div className="text-sm font-bold mb-2">Why the Spine Architecture Matters</div>
        <p className="text-xs leading-relaxed opacity-90">
          Without a coordinating spine, legal technology platforms become <strong>isolated silos</strong> where 
          components cannot communicate, state becomes inconsistent, and traceability is impossible. The Spine 
          Architecture transforms the platform from a collection of tools into a <strong>connected legal intelligence 
          system</strong> where every signal is traceable, every decision is reproducible, and every output is 
          litigation-grade defensible.
        </p>
      </div>

    </motion.div>
  );
}

// Spine Function Component
function SpineFunction({
  number,
  title,
  color,
  description,
  children,
}: {
  number: string;
  title: string;
  color: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <div className="p-4 bg-white border-2 rounded-lg shadow-sm" style={{ borderColor: color }}>
      <div className="flex items-start gap-3 mb-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
          style={{ backgroundColor: color }}
        >
          {number}
        </div>
        <div className="flex-1">
          <div className="font-bold text-sm mb-1" style={{ color }}>
            {title}
          </div>
          <div className="text-xs opacity-70">{description}</div>
        </div>
      </div>
      <div className="pl-13">{children}</div>
    </div>
  );
}

// Detail Box
function DetailBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-slate-50 border border-slate-300 rounded">
      {children}
    </div>
  );
}

// Architecture Box
function ArchBox({ color, children }: { color: string; children: React.ReactNode }) {
  return (
    <div className="p-4 rounded text-white" style={{ backgroundColor: color }}>
      {children}
    </div>
  );
}

// Flow Arrow
function FlowArrow() {
  return (
    <div className="flex justify-center">
      <div className="w-0.5 h-4 bg-slate-400"></div>
    </div>
  );
}

// Spine Module
function SpineModule({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-blue-600/40 border border-blue-300 rounded">
      {children}
    </div>
  );
}

// Agent Box
function AgentBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-indigo-600/40 border border-indigo-300 rounded text-center">
      {children}
    </div>
  );
}

// Program Box
function ProgramBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-purple-600/40 border border-purple-300 rounded text-center">
      {children}
    </div>
  );
}

// Principle Box
function PrincipleBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-blue-600/30 border border-blue-400 rounded text-center">
      {children}
    </div>
  );
}
