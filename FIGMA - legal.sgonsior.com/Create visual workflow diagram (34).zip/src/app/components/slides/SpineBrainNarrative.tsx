import { motion } from "motion/react";

// The Spine & Brain Concept - Narrative Explanation
// How the system connects people, AI agents, and deterministic programs
export function SpineBrainNarrative() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1200px] px-4 space-y-6"
    >
      
      {/* THE PROBLEM */}
      <Section>
        <SectionTitle>The Problem with Traditional Legal Technology</SectionTitle>
        <div className="space-y-3">
          <NarrativeBox>
            <p className="text-sm leading-relaxed">
              Most legal technology tools are <strong>isolated systems</strong> that manage documents, track deadlines, and store files. 
              They operate independently without understanding the <strong>legal structure</strong> of a case.
            </p>
          </NarrativeBox>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <IsolatedToolBox>Document Storage</IsolatedToolBox>
            <IsolatedToolBox>Deadline Tracking</IsolatedToolBox>
            <IsolatedToolBox>Billing Management</IsolatedToolBox>
          </div>
          <NarrativeBox variant="problem">
            <p className="text-sm">
              <strong>Critical Gap:</strong> These tools cannot answer the fundamental question attorneys need answered: 
              <em>"Which legal elements are supported by evidence?"</em>
            </p>
          </NarrativeBox>
        </div>
      </Section>

      {/* THE SOLUTION - BIOLOGICAL METAPHOR */}
      <Section>
        <SectionTitle>The Solution: A Legal Nervous System</SectionTitle>
        <div className="space-y-3">
          <NarrativeBox>
            <p className="text-sm leading-relaxed">
              Instead of isolated tools, the AI Legal Service platform creates a <strong>connected legal intelligence system</strong> 
              inspired by human biology. Like the human nervous system, it uses a <strong>Spine</strong> to carry signals and a 
              <strong> Brain</strong> to process and reason.
            </p>
          </NarrativeBox>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* THE SPINE */}
            <BiologyCard>
              <div className="text-center mb-3">
                <div className="inline-block px-4 py-2 bg-blue-600 text-white font-bold rounded">
                  THE SPINE
                </div>
              </div>
              <div className="text-sm space-y-2">
                <p className="font-semibold">Central Coordination System</p>
                <p className="text-xs opacity-80 leading-relaxed">
                  Like the human spinal cord, the system spine connects all components and carries signals between them. 
                  It ensures every action is <strong>traceable, reproducible, and auditable</strong>.
                </p>
                <div className="mt-3 space-y-1 text-xs opacity-70 pl-3 border-l-2 border-blue-400">
                  <div>• Workflow routing between components</div>
                  <div>• State management across the system</div>
                  <div>• Agent coordination and execution</div>
                  <div>• Audit tracking for legal defensibility</div>
                  <div>• Deterministic execution guarantees</div>
                </div>
              </div>
            </BiologyCard>

            {/* THE BRAIN */}
            <BiologyCard>
              <div className="text-center mb-3">
                <div className="inline-block px-4 py-2 bg-purple-600 text-white font-bold rounded">
                  THE BRAIN
                </div>
              </div>
              <div className="text-sm space-y-2">
                <p className="font-semibold">Legal Reasoning Center</p>
                <p className="text-xs opacity-80 leading-relaxed">
                  Like the human brain, this layer performs structured legal reasoning through specialized lobes. 
                  It operates using <strong>legal doctrine, not vague AI interpretation</strong>.
                </p>
                <div className="mt-3 space-y-1 text-xs opacity-70 pl-3 border-l-2 border-purple-400">
                  <div>• Perception Lobe: narrative → signals</div>
                  <div>• Mapping Lobe: signals → structured facts</div>
                  <div>• Doctrine Lobe: facts → legal analysis</div>
                  <div>• Grounded in CACI, CA Evidence Code</div>
                  <div>• Pattern modules for legal frameworks</div>
                </div>
              </div>
            </BiologyCard>
          </div>
        </div>
      </Section>

      {/* THE CONNECTION FLOW */}
      <Section>
        <SectionTitle>How It Connects: People → AI → Programs → People</SectionTitle>
        <div className="space-y-4">
          <NarrativeBox>
            <p className="text-sm leading-relaxed">
              The Spine & Brain architecture creates a <strong>closed-loop legal reasoning workflow</strong> that connects 
              human input with AI intelligence and deterministic programs, then returns structured insights to attorneys.
            </p>
          </NarrativeBox>

          {/* THE FLOW */}
          <div className="space-y-3">
            
            {/* STEP 1: CLIENT INPUT */}
            <FlowStep number="1" title="Client Input" color="#1e40af">
              <p className="text-xs opacity-80 mb-2">
                <strong>Person:</strong> Client provides unstructured narrative, documents, and evidence
              </p>
              <div className="text-xs opacity-70 italic">
                Example: "We formed a partnership and he stopped paying me after 6 months..."
              </div>
            </FlowStep>

            <FlowArrow />

            {/* STEP 2: SPINE ROUTING */}
            <FlowStep number="2" title="Spine Routes Signal" color="#1e3a8a">
              <p className="text-xs opacity-80 mb-2">
                <strong>Platform:</strong> System spine receives input and routes to Interview Agent
              </p>
              <div className="text-xs opacity-70 pl-3 border-l-2 border-blue-400">
                • Creates case signal profile
                <br />
                • Tracks workflow state
                <br />
                • Logs all actions for audit
              </div>
            </FlowStep>

            <FlowArrow />

            {/* STEP 3: BRAIN PERCEPTION */}
            <FlowStep number="3" title="Brain Processes (Perception Lobe)" color="#7c3aed">
              <p className="text-xs opacity-80 mb-2">
                <strong>AI Agent:</strong> Interview Agent converts narrative into structured legal signals
              </p>
              <div className="text-xs opacity-70 italic">
                Extracts: agreements • payments • timelines • damages • witnesses
              </div>
            </FlowStep>

            <FlowArrow />

            {/* STEP 4: BRAIN MAPPING */}
            <FlowStep number="4" title="Brain Processes (Mapping Lobe)" color="#6366f1">
              <p className="text-xs opacity-80 mb-2">
                <strong>AI Agent:</strong> Mapping Agent structures facts and links evidence
              </p>
              <div className="text-xs opacity-70 pl-3 border-l-2 border-indigo-400">
                • Entity: Partnership formed
                <br />
                • Entity: Defendant
                <br />
                • Event: Payment obligations
                <br />
                • Event: Payment stopped
                <br />
                • Evidence: contract, email, invoice
              </div>
            </FlowStep>

            <FlowArrow />

            {/* STEP 5: BRAIN DOCTRINE */}
            <FlowStep number="5" title="Brain Processes (Doctrine Lobe)" color="#3b82f6">
              <p className="text-xs opacity-80 mb-2">
                <strong>AI Agent:</strong> COA Reasoner applies legal doctrine to structured facts
              </p>
              <div className="text-xs opacity-70 italic">
                Identifies potential causes of action: Breach of Partnership Agreement
              </div>
            </FlowStep>

            <FlowArrow />

            {/* STEP 6: DETERMINISTIC PROGRAMS */}
            <FlowStep number="6" title="Deterministic Programs Execute" color="#8b5cf6">
              <p className="text-xs opacity-80 mb-2">
                <strong>Platform Programs:</strong> Coverage Engine evaluates evidence against legal elements
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs mt-2">
                <MiniCoverage state="strong">Partnership exists: STRONG</MiniCoverage>
                <MiniCoverage state="weak">Obligations defined: WEAK</MiniCoverage>
                <MiniCoverage state="unknown">Breach occurred: UNKNOWN</MiniCoverage>
                <MiniCoverage state="unknown">Damages: UNKNOWN</MiniCoverage>
              </div>
            </FlowStep>

            <FlowArrow />

            {/* STEP 7: ATTORNEY OUTPUT */}
            <FlowStep number="7" title="Attorney Review & Decision" color="#059669">
              <p className="text-xs opacity-80 mb-2">
                <strong>Person:</strong> Attorney receives structured legal analysis with evidence-element mapping
              </p>
              <div className="text-xs opacity-70 pl-3 border-l-2 border-emerald-400">
                • All reasoning is traceable and reproducible
                <br />
                • Evidence gaps clearly identified
                <br />
                • Strategic recommendations provided
                <br />
                • Litigation-ready artifacts generated
              </div>
            </FlowStep>

          </div>
        </div>
      </Section>

      {/* THE TRANSFORMATION */}
      <Section>
        <SectionTitle>What This Enables</SectionTitle>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <TransformationCard>
            <div className="font-bold text-sm mb-2">Connected Intelligence</div>
            <p className="text-xs opacity-80 leading-relaxed">
              Clients, attorneys, AI agents, and deterministic programs work as a unified legal reasoning organism, 
              not isolated tools.
            </p>
          </TransformationCard>
          
          <TransformationCard>
            <div className="font-bold text-sm mb-2">Evidence-Based Analysis</div>
            <p className="text-xs opacity-80 leading-relaxed">
              The system answers "Which legal elements are supported by evidence?" automatically, 
              transforming intuition into structured analysis.
            </p>
          </TransformationCard>
          
          <TransformationCard>
            <div className="font-bold text-sm mb-2">Legal Defensibility</div>
            <p className="text-xs opacity-80 leading-relaxed">
              Every action is traceable through the spine's audit ledger. Every decision is reproducible. 
              Every output is litigation-grade.
            </p>
          </TransformationCard>
        </div>
      </Section>

      {/* KEY INSIGHT */}
      <div className="p-5 bg-slate-900 border-2 border-blue-500 rounded-lg text-white">
        <div className="text-sm font-bold mb-2">Key Architectural Insight</div>
        <p className="text-xs leading-relaxed opacity-90">
          The Spine & Brain architecture transforms legal work from <strong>document management</strong> to 
          <strong> legal reasoning support</strong>. It creates a nervous system that connects people with 
          AI intelligence and deterministic programs, ensuring every signal is traceable, every decision is 
          reproducible, and every output is grounded in real legal doctrine.
        </p>
      </div>

    </motion.div>
  );
}

// Section Container
function Section({ children }: { children: React.ReactNode }) {
  return <div className="space-y-3">{children}</div>;
}

// Section Title
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="text-base font-bold uppercase tracking-wide border-b-2 border-slate-300 pb-2">
      {children}
    </h2>
  );
}

// Narrative Box
function NarrativeBox({ 
  children, 
  variant = "default" 
}: { 
  children: React.ReactNode; 
  variant?: "default" | "problem" | "solution";
}) {
  const styles = {
    default: "bg-slate-50 border-slate-300",
    problem: "bg-red-50 border-red-400",
    solution: "bg-green-50 border-green-400",
  };

  return (
    <div className={`p-4 border-l-4 rounded ${styles[variant]}`}>
      {children}
    </div>
  );
}

// Isolated Tool Box
function IsolatedToolBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-3 bg-gray-200 border border-gray-400 rounded text-center opacity-60">
      {children}
    </div>
  );
}

// Biology Card
function BiologyCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-4 bg-white border-2 border-slate-300 rounded-lg shadow-sm">
      {children}
    </div>
  );
}

// Flow Step
function FlowStep({ 
  number, 
  title, 
  color, 
  children 
}: { 
  number: string; 
  title: string; 
  color: string; 
  children: React.ReactNode;
}) {
  return (
    <div className="p-4 bg-white border-2 rounded-lg" style={{ borderColor: color }}>
      <div className="flex items-center gap-3 mb-2">
        <div 
          className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
          style={{ backgroundColor: color }}
        >
          {number}
        </div>
        <div className="font-bold text-sm" style={{ color }}>
          {title}
        </div>
      </div>
      <div className="pl-11">
        {children}
      </div>
    </div>
  );
}

// Flow Arrow
function FlowArrow() {
  return (
    <div className="flex justify-center">
      <div className="w-0.5 h-4 bg-slate-400"></div>
    </div>
  );
}

// Mini Coverage Badge
function MiniCoverage({ 
  state, 
  children 
}: { 
  state: string; 
  children: React.ReactNode;
}) {
  const colors = {
    strong: "bg-green-100 border-green-500 text-green-900",
    weak: "bg-yellow-100 border-yellow-500 text-yellow-900",
    unknown: "bg-gray-100 border-gray-500 text-gray-900",
  };

  return (
    <div className={`p-1.5 border rounded text-center ${colors[state as keyof typeof colors]}`}>
      {children}
    </div>
  );
}

// Transformation Card
function TransformationCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-4 bg-blue-50 border-2 border-blue-400 rounded-lg">
      {children}
    </div>
  );
}
