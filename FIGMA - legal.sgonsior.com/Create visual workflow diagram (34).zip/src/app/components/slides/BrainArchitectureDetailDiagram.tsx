import { motion } from "motion/react";

// Deep Dive: The Brain Architecture
// Legal reasoning center structured by specialized cognitive lobes
export function BrainArchitectureDetailDiagram() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1400px] px-4 space-y-6"
    >
      
      {/* BRAIN OVERVIEW */}
      <div className="p-6 bg-slate-900 border-2 border-purple-500 rounded-lg text-white">
        <h3 className="text-lg font-bold mb-3 uppercase tracking-wider text-center">
          The Legal Brain — Structured Reasoning Center
        </h3>
        <p className="text-sm leading-relaxed text-center opacity-90 mb-4">
          Like the human brain with specialized lobes, the Legal Brain performs structured legal reasoning through 
          three distinct cognitive regions. Each lobe has a specific function and connects with the spine for 
          coordinated intelligence.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <PrincipleBox>Grounded in legal doctrine</PrincipleBox>
          <PrincipleBox>No hallucination — only structured reasoning</PrincipleBox>
          <PrincipleBox>Every decision is explainable</PrincipleBox>
        </div>
      </div>

      {/* THREE LOBES ARCHITECTURE */}
      <div className="space-y-4">
        <h3 className="text-base font-bold uppercase tracking-wide text-center border-b-2 border-slate-300 pb-2">
          Three Cognitive Lobes of Legal Intelligence
        </h3>

        {/* LOBE 1: PERCEPTION LOBE */}
        <BrainLobe
          number="1"
          title="Perception Lobe — Interview Agent"
          color="#8b5cf6"
          metaphor="Like the sensory cortex: converts raw input into structured signals"
        >
          <div className="space-y-3">
            
            {/* PRIMARY FUNCTION */}
            <div className="p-3 bg-purple-50 border-l-4 border-purple-500 rounded">
              <div className="font-bold text-sm mb-1">Primary Function</div>
              <p className="text-xs opacity-80 leading-relaxed">
                Converts unstructured human narratives into <strong>structured legal signals</strong> that the 
                platform can process. This is the entry point where human language becomes machine-processable data.
              </p>
            </div>

            {/* WHAT IT DOES */}
            <div>
              <div className="font-bold text-sm mb-2">What the Interview Agent Does</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                <ProcessBox>
                  <strong>Narrative Analysis:</strong> Reads client's story and identifies key legal concepts
                </ProcessBox>
                <ProcessBox>
                  <strong>Signal Extraction:</strong> Pulls out agreements, payments, timelines, damages, witnesses
                </ProcessBox>
                <ProcessBox>
                  <strong>Context Preservation:</strong> Maintains original narrative context for audit trail
                </ProcessBox>
                <ProcessBox>
                  <strong>Structured Output:</strong> Converts signals into JSON format for next processing stage
                </ProcessBox>
              </div>
            </div>

            {/* EXAMPLE TRANSFORMATION */}
            <div>
              <div className="font-bold text-sm mb-2">Example Transformation</div>
              <div className="space-y-2">
                <div className="p-3 bg-slate-100 border border-slate-300 rounded">
                  <div className="text-xs font-semibold mb-1">Input (Human Narrative):</div>
                  <p className="text-xs italic opacity-70">
                    "We formed a partnership in January 2023. He agreed to contribute $50k but only paid $10k. 
                    After 6 months, he stopped responding to emails and hasn't paid anything since."
                  </p>
                </div>
                <div className="flex justify-center">
                  <div className="text-purple-600 font-bold">↓ Interview Agent Processes ↓</div>
                </div>
                <div className="p-3 bg-purple-50 border border-purple-400 rounded">
                  <div className="text-xs font-semibold mb-2">Output (Structured Signals):</div>
                  <div className="space-y-1 text-xs opacity-80 font-mono">
                    <div>• Agreement: Partnership formation (Jan 2023)</div>
                    <div>• Payment: Commitment ($50k), Actual ($10k)</div>
                    <div>• Timeline: 6-month period</div>
                    <div>• Event: Payment cessation</div>
                    <div>• Event: Communication breakdown</div>
                    <div>• Parties: Client, Partner</div>
                  </div>
                </div>
              </div>
            </div>

            {/* GROUNDING */}
            <div className="p-3 bg-blue-50 border border-blue-400 rounded text-xs">
              <strong>How It's Grounded:</strong> Uses legal ontology to identify signal types. Trained on legal 
              intake patterns. Validates output against schema before sending to Mapping Lobe.
            </div>

          </div>
        </BrainLobe>

        {/* LOBE 2: MAPPING LOBE */}
        <BrainLobe
          number="2"
          title="Mapping Lobe — Mapping Agent"
          color="#6366f1"
          metaphor="Like the parietal lobe: organizes spatial relationships and structures information"
        >
          <div className="space-y-3">
            
            {/* PRIMARY FUNCTION */}
            <div className="p-3 bg-indigo-50 border-l-4 border-indigo-500 rounded">
              <div className="font-bold text-sm mb-1">Primary Function</div>
              <p className="text-xs opacity-80 leading-relaxed">
                Converts legal signals into <strong>structured facts, entities, and evidence relationships</strong>. 
                Creates the normalized fact base that legal doctrine will evaluate.
              </p>
            </div>

            {/* WHAT IT DOES */}
            <div>
              <div className="font-bold text-sm mb-2">What the Mapping Agent Does</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                <ProcessBox>
                  <strong>Entity Extraction:</strong> Identifies parties, organizations, locations, agreements
                </ProcessBox>
                <ProcessBox>
                  <strong>Timeline Creation:</strong> Orders events chronologically with precise dates
                </ProcessBox>
                <ProcessBox>
                  <strong>Evidence Linking:</strong> Connects documents and evidence to specific facts
                </ProcessBox>
                <ProcessBox>
                  <strong>Fact Normalization:</strong> Standardizes facts into platform-processable format
                </ProcessBox>
              </div>
            </div>

            {/* EXAMPLE TRANSFORMATION */}
            <div>
              <div className="font-bold text-sm mb-2">Example Transformation</div>
              <div className="space-y-2">
                <div className="p-3 bg-purple-50 border border-purple-400 rounded">
                  <div className="text-xs font-semibold mb-1">Input (Structured Signals from Perception Lobe):</div>
                  <div className="space-y-1 text-xs opacity-70 font-mono">
                    <div>• Agreement: Partnership formation (Jan 2023)</div>
                    <div>• Payment: Commitment ($50k), Actual ($10k)</div>
                  </div>
                </div>
                <div className="flex justify-center">
                  <div className="text-indigo-600 font-bold">↓ Mapping Agent Processes ↓</div>
                </div>
                <div className="p-3 bg-indigo-50 border border-indigo-400 rounded">
                  <div className="text-xs font-semibold mb-2">Output (Structured Fact Base):</div>
                  <div className="space-y-2 text-xs opacity-80">
                    <FactBlock>
                      <strong>Entity:</strong> Partnership Agreement
                      <br />
                      <strong>Date:</strong> 2023-01-15
                      <br />
                      <strong>Parties:</strong> Client (Party A), Partner (Party B)
                      <br />
                      <strong>Evidence:</strong> partnership_agreement.pdf
                    </FactBlock>
                    <FactBlock>
                      <strong>Event:</strong> Payment Obligation
                      <br />
                      <strong>Amount:</strong> $50,000 USD
                      <br />
                      <strong>Responsible Party:</strong> Party B
                      <br />
                      <strong>Evidence:</strong> partnership_agreement.pdf (Section 4.2)
                    </FactBlock>
                    <FactBlock>
                      <strong>Event:</strong> Partial Payment
                      <br />
                      <strong>Amount:</strong> $10,000 USD
                      <br />
                      <strong>Date:</strong> 2023-02-01
                      <br />
                      <strong>Evidence:</strong> bank_transfer.pdf
                    </FactBlock>
                  </div>
                </div>
              </div>
            </div>

            {/* GROUNDING */}
            <div className="p-3 bg-blue-50 border border-blue-400 rounded text-xs">
              <strong>How It's Grounded:</strong> Uses entity recognition models trained on legal documents. 
              Validates entities against schema. Links evidence to facts using document analysis. Creates structured 
              graph of relationships.
            </div>

          </div>
        </BrainLobe>

        {/* LOBE 3: DOCTRINE LOBE */}
        <BrainLobe
          number="3"
          title="Doctrine Lobe — COA Reasoner"
          color="#3b82f6"
          metaphor="Like the prefrontal cortex: applies rules, evaluates evidence, makes reasoned judgments"
        >
          <div className="space-y-3">
            
            {/* PRIMARY FUNCTION */}
            <div className="p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
              <div className="font-bold text-sm mb-1">Primary Function</div>
              <p className="text-xs opacity-80 leading-relaxed">
                Applies <strong>legal doctrine</strong> to structured facts to identify potential causes of action, 
                map evidence to legal elements, and prepare for deterministic coverage evaluation.
              </p>
            </div>

            {/* WHAT IT DOES */}
            <div>
              <div className="font-bold text-sm mb-2">What the COA Reasoner Does</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                <ProcessBox>
                  <strong>Cause of Action Identification:</strong> Analyzes facts to identify viable legal claims
                </ProcessBox>
                <ProcessBox>
                  <strong>Element Mapping:</strong> Maps facts to specific legal elements from CACI instructions
                </ProcessBox>
                <ProcessBox>
                  <strong>Doctrine Application:</strong> Applies CA Evidence Code rules to evaluate evidence
                </ProcessBox>
                <ProcessBox>
                  <strong>Strategy Analysis:</strong> Identifies strengths, weaknesses, and evidence gaps
                </ProcessBox>
              </div>
            </div>

            {/* EXAMPLE TRANSFORMATION */}
            <div>
              <div className="font-bold text-sm mb-2">Example Transformation</div>
              <div className="space-y-2">
                <div className="p-3 bg-indigo-50 border border-indigo-400 rounded">
                  <div className="text-xs font-semibold mb-1">Input (Structured Fact Base from Mapping Lobe):</div>
                  <div className="space-y-1 text-xs opacity-70">
                    <div>• Partnership Agreement (2023-01-15)</div>
                    <div>• Payment Obligation ($50k)</div>
                    <div>• Partial Payment ($10k)</div>
                    <div>• Payment Cessation (6 months later)</div>
                  </div>
                </div>
                <div className="flex justify-center">
                  <div className="text-blue-600 font-bold">↓ COA Reasoner Processes ↓</div>
                </div>
                <div className="p-3 bg-blue-50 border border-blue-400 rounded">
                  <div className="text-xs font-semibold mb-2">Output (Legal Analysis Structure):</div>
                  <div className="space-y-2 text-xs opacity-80">
                    <DoctrineBlock>
                      <strong>Identified COA:</strong> Breach of Partnership Agreement
                      <br />
                      <strong>Pattern Module:</strong> breach_partnership_CA
                      <br />
                      <strong>CACI Reference:</strong> CACI 303 (Breach of Contract)
                    </DoctrineBlock>
                    <DoctrineBlock>
                      <strong>Element 1:</strong> Partnership agreement existed
                      <br />
                      <strong>Mapped Evidence:</strong> partnership_agreement.pdf
                      <br />
                      <strong>Coverage Signal:</strong> STRONG
                    </DoctrineBlock>
                    <DoctrineBlock>
                      <strong>Element 2:</strong> Defendant's obligations under agreement
                      <br />
                      <strong>Mapped Evidence:</strong> partnership_agreement.pdf (Section 4.2)
                      <br />
                      <strong>Coverage Signal:</strong> STRONG
                    </DoctrineBlock>
                    <DoctrineBlock>
                      <strong>Element 3:</strong> Breach of those obligations
                      <br />
                      <strong>Mapped Evidence:</strong> bank_transfer.pdf (partial payment), email thread
                      <br />
                      <strong>Coverage Signal:</strong> WEAK (needs more evidence)
                    </DoctrineBlock>
                  </div>
                </div>
              </div>
            </div>

            {/* GROUNDING */}
            <div className="p-3 bg-blue-50 border border-blue-400 rounded text-xs">
              <strong>How It's Grounded:</strong> Pattern modules encode real legal frameworks (CACI instructions, 
              CA Evidence Code). COA Reasoner identifies applicable patterns and maps facts to elements. Every mapping 
              is explainable and traceable to legal authority.
            </div>

          </div>
        </BrainLobe>
      </div>

      {/* BRAIN FLOW DIAGRAM */}
      <div className="space-y-3">
        <h3 className="text-base font-bold uppercase tracking-wide text-center border-b-2 border-slate-300 pb-2">
          Brain Processing Flow
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* PERCEPTION */}
          <LobeCard color="#8b5cf6">
            <div className="text-center mb-2">
              <div className="font-bold text-sm">PERCEPTION LOBE</div>
              <div className="text-xs opacity-70 mt-1">Interview Agent</div>
            </div>
            <div className="space-y-1 text-xs">
              <div className="p-2 bg-purple-900/30 rounded">Human Narrative</div>
              <div className="text-center text-xs">↓</div>
              <div className="p-2 bg-purple-700/40 rounded">Legal Signals</div>
            </div>
          </LobeCard>

          {/* MAPPING */}
          <LobeCard color="#6366f1">
            <div className="text-center mb-2">
              <div className="font-bold text-sm">MAPPING LOBE</div>
              <div className="text-xs opacity-70 mt-1">Mapping Agent</div>
            </div>
            <div className="space-y-1 text-xs">
              <div className="p-2 bg-indigo-900/30 rounded">Legal Signals</div>
              <div className="text-center text-xs">↓</div>
              <div className="p-2 bg-indigo-700/40 rounded">Structured Facts</div>
            </div>
          </LobeCard>

          {/* DOCTRINE */}
          <LobeCard color="#3b82f6">
            <div className="text-center mb-2">
              <div className="font-bold text-sm">DOCTRINE LOBE</div>
              <div className="text-xs opacity-70 mt-1">COA Reasoner</div>
            </div>
            <div className="space-y-1 text-xs">
              <div className="p-2 bg-blue-900/30 rounded">Structured Facts</div>
              <div className="text-center text-xs">↓</div>
              <div className="p-2 bg-blue-700/40 rounded">Legal Analysis</div>
            </div>
          </LobeCard>

        </div>
      </div>

      {/* BRAIN TO DETERMINISTIC PROGRAMS */}
      <div className="p-5 bg-slate-100 border-2 border-slate-400 rounded-lg">
        <div className="text-sm font-bold mb-2 text-center">Brain → Deterministic Programs Handoff</div>
        <p className="text-xs leading-relaxed text-center opacity-80 mb-3">
          After the Brain's three lobes process the case, structured legal analysis is passed to 
          <strong> deterministic programs</strong> for coverage evaluation and strategic analysis.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2 text-xs text-center">
          <HandoffBox>Pattern Module System</HandoffBox>
          <HandoffBox>Coverage Engine</HandoffBox>
          <HandoffBox>Element Evaluator</HandoffBox>
          <HandoffBox>Evidence Mapper</HandoffBox>
        </div>
      </div>

      {/* KEY INSIGHT */}
      <div className="p-5 bg-slate-900 border-2 border-purple-500 rounded-lg text-white">
        <div className="text-sm font-bold mb-2">Why the Brain Architecture Matters</div>
        <p className="text-xs leading-relaxed opacity-90">
          Traditional AI legal tools attempt to do everything with a single general-purpose model, leading to 
          hallucinations and unreliable outputs. The Brain Architecture separates legal reasoning into 
          <strong> three specialized cognitive lobes</strong>, each grounded in legal doctrine and connected through 
          the spine. This creates <strong>structured, explainable, and reproducible legal intelligence</strong> that 
          attorneys can trust for litigation-grade work.
        </p>
      </div>

    </motion.div>
  );
}

// Brain Lobe Component
function BrainLobe({
  number,
  title,
  color,
  metaphor,
  children,
}: {
  number: string;
  title: string;
  color: string;
  metaphor: string;
  children: React.ReactNode;
}) {
  return (
    <div className="p-5 bg-white border-2 rounded-lg shadow-md" style={{ borderColor: color }}>
      <div className="flex items-start gap-3 mb-4">
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0"
          style={{ backgroundColor: color }}
        >
          {number}
        </div>
        <div className="flex-1">
          <div className="font-bold text-base mb-1" style={{ color }}>
            {title}
          </div>
          <div className="text-xs italic opacity-70">{metaphor}</div>
        </div>
      </div>
      {children}
    </div>
  );
}

// Process Box
function ProcessBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-slate-50 border border-slate-300 rounded">
      {children}
    </div>
  );
}

// Fact Block
function FactBlock({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-white border border-indigo-300 rounded font-mono">
      {children}
    </div>
  );
}

// Doctrine Block
function DoctrineBlock({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-white border border-blue-300 rounded font-mono">
      {children}
    </div>
  );
}

// Lobe Card
function LobeCard({ color, children }: { color: string; children: React.ReactNode }) {
  return (
    <div className="p-4 rounded-lg text-white" style={{ backgroundColor: color }}>
      {children}
    </div>
  );
}

// Handoff Box
function HandoffBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-slate-200 border border-slate-400 rounded">
      {children}
    </div>
  );
}

// Principle Box
function PrincipleBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-purple-600/30 border border-purple-400 rounded text-center">
      {children}
    </div>
  );
}
