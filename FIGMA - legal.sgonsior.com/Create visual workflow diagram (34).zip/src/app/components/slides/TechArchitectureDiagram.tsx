import { motion } from "motion/react";

// Conceptual Technology Architecture Framework — Overall
// Evidence-Centered Litigation Infrastructure
export function TechArchitectureDiagram() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1400px] px-4"
    >
      <div className="grid grid-cols-12 gap-3">
        {/* MAIN ARCHITECTURE - 10 columns */}
        <div className="col-span-12 lg:col-span-10 space-y-3">
          
          {/* TOP LAYER — USERS */}
          <ArchLayer bgColor="#000033" textColor="#FFFFFF">
            <div className="grid grid-cols-3 gap-4 text-center">
              <UserBox label="Client" />
              <UserBox label="Litigation Attorney" />
              <UserBox label="Litigation Operations / Case Command" />
            </div>
            <p className="mt-3 text-center text-xs opacity-70">
              Client simplicity • Attorney control • Structured oversight
            </p>
          </ArchLayer>

          {/* OMNI-CHANNEL COMMUNICATION */}
          <ArchLayer bgColor="#1a1a4d" textColor="#FFFFFF">
            <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
              Omni-Channel Case Communication
            </h3>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-xs">
              <MicroBox>Secure Chat</MicroBox>
              <MicroBox>Email Intake</MicroBox>
              <MicroBox>Voice Recording</MicroBox>
              <MicroBox>Web Upload</MicroBox>
              <MicroBox>Mobile Capture</MicroBox>
              <MicroBox>Document Import</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              All communications versioned and auditable
            </p>
          </ArchLayer>

          {/* INTEGRATED PORTAL SERVICES */}
          <ArchLayer bgColor="#2d2d5c" textColor="#FFFFFF">
            <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
              Integrated Portal Services
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <MicroBox>Client Portal</MicroBox>
              <MicroBox>Attorney Portal</MicroBox>
              <MicroBox>Case Command Portal</MicroBox>
              <MicroBox>Litigation Strategy Workspace</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              Role-based access • Case-scoped visibility
            </p>
          </ArchLayer>

          {/* EXTERNAL APPLICATIONS */}
          <ArchLayer bgColor="#40406b" textColor="#FFFFFF">
            <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
              External Applications / Services
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
              <MicroBox>eDiscovery Platforms</MicroBox>
              <MicroBox>Court Filing Systems</MicroBox>
              <MicroBox>Document Management</MicroBox>
              <MicroBox>Forensic Tools</MicroBox>
              <MicroBox>Financial Analysis</MicroBox>
              <MicroBox>Public Records DB</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              Integrated via governed API layer
            </p>
          </ArchLayer>

          {/* AUTHENTICATION & AUTHORIZATION */}
          <ArchLayer bgColor="#53537a" textColor="#FFFFFF">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-center">
              <MicroBox>Authentication & Authorization</MicroBox>
              <MicroBox>Role-Based Access Control</MicroBox>
              <MicroBox>Case-Scoped Permissions</MicroBox>
              <MicroBox>Audit Logging Enforcement</MicroBox>
            </div>
          </ArchLayer>

          {/* SECURITY / PRIVACY LAYER */}
          <ArchLayer bgColor="#666689" textColor="#FFFFFF">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-center">
              <MicroBox>Encryption Layer</MicroBox>
              <MicroBox>Privilege Controls</MicroBox>
              <MicroBox>Access Governance</MicroBox>
              <MicroBox>Evidence Segregation</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              Privilege-aware architecture
            </p>
          </ArchLayer>

          {/* INTEGRATION SERVICES */}
          <ArchLayer bgColor="#797998" textColor="#FFFFFF">
            <h3 className="font-bold text-sm mb-2 text-center uppercase tracking-wider">
              Integration Services
            </h3>
            <div className="grid grid-cols-5 gap-2 text-xs text-center">
              <MicroBox>Gateway</MicroBox>
              <MicroBox>API</MicroBox>
              <MicroBox>Microservices</MicroBox>
              <MicroBox>Batch</MicroBox>
              <MicroBox>Streaming</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              Tool mediation enforced • No direct external calls • Deterministic execution only
            </p>
          </ArchLayer>

          {/* DATA LAYER (CRITICAL) */}
          <ArchLayer bgColor="#000033" textColor="#FFFFFF">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Evidence Vault */}
              <DataBox title="Evidence Vault">
                <DataItem>Immutable Storage</DataItem>
                <DataItem>Hash-Locked Files</DataItem>
                <DataItem>Chain of Custody</DataItem>
              </DataBox>

              {/* Structured Evidence Ledger */}
              <DataBox title="Structured Evidence Ledger">
                <DataItem>Statements</DataItem>
                <DataItem>Declarants</DataItem>
                <DataItem>Facts</DataItem>
                <DataItem>Entities</DataItem>
                <DataItem>Timeline Events</DataItem>
              </DataBox>

              {/* Rule Evaluation Engine */}
              <DataBox title="Rule Evaluation Engine">
                <DataItem>Authentication Overlay</DataItem>
                <DataItem>Hearsay Overlay</DataItem>
                <DataItem>Privilege Overlay</DataItem>
                <DataItem>Relevance & 352</DataItem>
                <DataItem>Expert Foundation</DataItem>
              </DataBox>

              {/* Litigation Intelligence Layer */}
              <DataBox title="Litigation Intelligence Layer">
                <DataItem>Cause of Action Engine</DataItem>
                <DataItem>Element Mapping</DataItem>
                <DataItem>Pattern Detection</DataItem>
                <DataItem>Contradiction Flagging</DataItem>
                <DataItem>Artifact Generation</DataItem>
              </DataBox>
            </div>
            <p className="mt-3 text-center text-xs opacity-70">
              Deterministic • Versioned • Replayable
            </p>
          </ArchLayer>

          {/* APPLICATION SERVICES */}
          <ArchLayer bgColor="#1a1a4d" textColor="#FFFFFF">
            <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
              Application Services
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <MicroBox>Interview Agent</MicroBox>
              <MicroBox>Mapping Agent</MicroBox>
              <MicroBox>COA Engine</MicroBox>
              <MicroBox>Discovery Engine</MicroBox>
              <MicroBox>Deposition Prep Engine</MicroBox>
              <MicroBox>Deposition Processing Engine</MicroBox>
              <MicroBox>Trial Preparation Engine</MicroBox>
              <MicroBox>Artifact Compiler</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              Agents propose • Programs commit
            </p>
          </ArchLayer>

          {/* DATA PROCESSING LAYER */}
          <ArchLayer bgColor="#2d2d5c" textColor="#FFFFFF">
            <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
              Deterministic Processing Layer
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
              <MicroBox>Hash Generation</MicroBox>
              <MicroBox>Transcript Parsing</MicroBox>
              <MicroBox>Fact Extraction</MicroBox>
              <MicroBox>Element Mapping</MicroBox>
              <MicroBox>Overlay Evaluation</MicroBox>
              <MicroBox>Audit Recording</MicroBox>
            </div>
            <p className="mt-2 text-center text-xs opacity-70">
              Replay equivalence enforced
            </p>
          </ArchLayer>

          {/* DATA SOURCES (BOTTOM) */}
          <ArchLayer bgColor="#40406b" textColor="#FFFFFF">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <DataBox title="Internal Case Data" compact>
                <DataItem>Client Uploads</DataItem>
                <DataItem>Interview Audio</DataItem>
                <DataItem>Attorney Notes</DataItem>
              </DataBox>

              <DataBox title="External Evidence Sources" compact>
                <DataItem>Email Servers</DataItem>
                <DataItem>Cloud Storage</DataItem>
                <DataItem>Financial Records</DataItem>
                <DataItem>Corporate Filings</DataItem>
                <DataItem>Public Records</DataItem>
                <DataItem>Third-Party Custodians</DataItem>
              </DataBox>
            </div>
            <p className="mt-3 text-center text-xs opacity-70">
              All ingested into foundation packet model
            </p>
          </ArchLayer>
        </div>

        {/* RIGHT COLUMN - PLATFORM GUARANTEES - 2 columns */}
        <div className="col-span-12 lg:col-span-2">
          <div
            className="rounded-lg p-4 h-full flex flex-col justify-center"
            style={{
              backgroundColor: "#000033",
              border: "2px solid #FFFFFF",
            }}
          >
            <h3 className="font-bold text-sm mb-4 text-center uppercase tracking-wider text-white">
              Platform Guarantees
            </h3>
            <div className="space-y-3">
              <GuaranteeItem>Deterministic Execution</GuaranteeItem>
              <GuaranteeItem>Hash Verification</GuaranteeItem>
              <GuaranteeItem>Overlay Governance</GuaranteeItem>
              <GuaranteeItem>Audit Logging</GuaranteeItem>
              <GuaranteeItem>Replay Equivalence</GuaranteeItem>
              <GuaranteeItem>Drift Prevention</GuaranteeItem>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Helper Components
function ArchLayer({
  bgColor,
  textColor,
  children,
}: {
  bgColor: string;
  textColor: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-lg p-4"
      style={{
        backgroundColor: bgColor,
        color: textColor,
        border: "1px solid rgba(255,255,255,0.2)",
      }}
    >
      {children}
    </div>
  );
}

function UserBox({ label }: { label: string }) {
  return (
    <div
      className="px-3 py-4 rounded text-sm font-semibold"
      style={{
        backgroundColor: "rgba(255,255,255,0.15)",
        border: "1px solid rgba(255,255,255,0.3)",
      }}
    >
      {label}
    </div>
  );
}

function MicroBox({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="px-2 py-2 rounded text-center font-medium"
      style={{
        backgroundColor: "rgba(255,255,255,0.12)",
        border: "1px solid rgba(255,255,255,0.25)",
      }}
    >
      {children}
    </div>
  );
}

function DataBox({
  title,
  children,
  compact = false,
}: {
  title: string;
  children: React.ReactNode;
  compact?: boolean;
}) {
  return (
    <div
      className={`rounded p-3 ${compact ? "" : ""}`}
      style={{
        backgroundColor: "rgba(255,255,255,0.08)",
        border: "1px solid rgba(255,255,255,0.25)",
      }}
    >
      <h4 className="font-bold text-xs mb-2 uppercase tracking-wide opacity-90">
        {title}
      </h4>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function DataItem({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2">
      <div
        className="mt-1.5 flex-shrink-0"
        style={{
          width: "4px",
          height: "4px",
          borderRadius: "999px",
          backgroundColor: "rgba(255,255,255,0.7)",
        }}
      />
      <p className="text-xs leading-relaxed opacity-85">{children}</p>
    </div>
  );
}

function GuaranteeItem({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="px-3 py-2 rounded text-xs font-semibold text-center"
      style={{
        backgroundColor: "rgba(255,255,255,0.1)",
        border: "1px solid rgba(255,255,255,0.3)",
        color: "#FFFFFF",
      }}
    >
      {children}
    </div>
  );
}
