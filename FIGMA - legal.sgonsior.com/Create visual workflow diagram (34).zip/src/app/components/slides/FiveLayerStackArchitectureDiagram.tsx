import { motion } from "motion/react";
import { useState } from "react";

interface StackLayer {
  id: string;
  name: string;
  order: number;
  purpose: string;
  keyResponsibilities: string[];
  coreRule: string;
  examples: string[];
  color: string;
  borderColor: string;
}

const STACK_LAYERS: StackLayer[] = [
  {
    id: "spine",
    name: "SPINE",
    order: 1,
    purpose: "Deterministic governance layer that ensures all system behavior is controlled, validated, auditable, replayable, and bounded.",
    keyResponsibilities: [
      "Contract validation",
      "Manifest governance",
      "Tool registry & lane enforcement",
      "Replay validation",
      "Audit event requirements",
      "Case boundary enforcement"
    ],
    coreRule: "The Spine is not an app feature. It is the platform control system.",
    examples: ["contract_manifest", "tool_registry", "lanes", "validator", "replay_harness", "audit_governance"],
    color: "#000033",
    borderColor: "#0066CC"
  },
  {
    id: "data-graph",
    name: "DATA GRAPH",
    order: 2,
    purpose: "Authoritative persistent case memory that stores structured legal matter data derived from evidence, analysis, and governed reasoning outputs.",
    keyResponsibilities: [
      "Store cases, documents, entities",
      "Maintain provenance & lineage",
      "Store facts, events, relationships",
      "Track signals, patterns, COAs",
      "Preserve evidence links",
      "Record review & approval status"
    ],
    coreRule: "Nothing material to litigation state may live only inside agent memory.",
    examples: ["cases", "documents", "entities", "facts", "events", "relationships", "signals", "patterns"],
    color: "#0a1929",
    borderColor: "#1976D2"
  },
  {
    id: "programs",
    name: "PROGRAMS",
    order: 3,
    purpose: "Deterministic execution modules that transform governed inputs into governed outputs according to explicit contracts.",
    keyResponsibilities: [
      "Deterministic transformations",
      "Fact normalization",
      "Pattern detection",
      "Legal structuring logic",
      "Coverage analysis",
      "Replayable computations"
    ],
    coreRule: "Programs compute. They do not 'think' in an unconstrained sense.",
    examples: ["FACT_NORMALIZATION", "COMPOSITE_ENGINE", "PATTERN_ENGINE", "COA_ENGINE", "COVERAGE_ENGINE"],
    color: "#1a1a4d",
    borderColor: "#7C4DFF"
  },
  {
    id: "agents",
    name: "AGENTS",
    order: 4,
    purpose: "Bounded reasoning and orchestration components that interpret context, interact with humans, and propose structured outputs.",
    keyResponsibilities: [
      "Question sequencing",
      "Context interpretation",
      "Human interaction",
      "Legal reasoning proposals",
      "Workflow routing",
      "Recommendation generation"
    ],
    coreRule: "Agents think. Programs compute. Agents do not own authoritative truth.",
    examples: ["INTERVIEW_AGENT", "MAPPING_AGENT", "COA_REASONER", "DISCOVERY_AGENT", "DEPOSITION_AGENT"],
    color: "#2d2d5c",
    borderColor: "#AB47BC"
  },
  {
    id: "ui",
    name: "UI",
    order: 5,
    purpose: "Human-facing application shell through which attorneys and staff interact with the platform to collect inputs, present outputs, and route workflows.",
    keyResponsibilities: [
      "Intake surfaces",
      "Workflow visualization",
      "Evidence review screens",
      "Timeline & graph views",
      "Approvals & review actions",
      "Status & audit feedback"
    ],
    coreRule: "The UI is a shell and control surface, not the litigation engine itself.",
    examples: ["intake_workflow", "mapping_review", "evidence_graph_ui", "coverage_review", "approval_interfaces"],
    color: "#40406b",
    borderColor: "#4FC3F7"
  }
];

const ARCHITECTURAL_MAXIMS = [
  "The Spine governs the Brain",
  "Agents think. Programs compute.",
  "The Data Graph is authoritative memory",
  "The UI is not the source of truth",
  "Nothing material may live only in temporary memory",
  "No silent mutation",
  "No uncontrolled tool use",
  "No cross-case leakage",
  "Determinism where state changes matter",
  "Auditability is mandatory, not optional"
];

export function FiveLayerStackArchitectureDiagram() {
  const [selectedLayer, setSelectedLayer] = useState<string | null>(null);

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="text-center space-y-3"
      >
        <h2 className="text-2xl md:text-3xl font-bold" style={{ color: '#000033' }}>
          Five-Layer Stack Architecture
        </h2>
        <p className="text-sm md:text-base" style={{ color: '#4A5568' }}>
          Governed litigation reasoning system with clean separation between governance, memory, computation, reasoning, and presentation
        </p>
      </motion.div>

      {/* Stack Visualization - Layers from top to bottom */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="space-y-3"
      >
        {STACK_LAYERS.slice().reverse().map((layer, index) => (
          <div key={layer.id}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index }}
              onMouseEnter={() => setSelectedLayer(layer.id)}
              onMouseLeave={() => setSelectedLayer(null)}
              className="cursor-pointer transition-all duration-200 rounded-lg p-4 md:p-6 border-l-4"
              style={{
                backgroundColor: selectedLayer === layer.id ? '#F7FAFC' : '#FFFFFF',
                borderLeftColor: layer.borderColor,
                borderTop: '1px solid #E2E8F0',
                borderRight: '1px solid #E2E8F0',
                borderBottom: '1px solid #E2E8F0'
              }}
            >
              <div className="flex flex-col md:flex-row md:items-start gap-4">
                {/* Layer Number & Name */}
                <div className="flex items-center gap-3 md:min-w-[180px]">
                  <div
                    className="w-10 h-10 md:w-12 md:h-12 rounded flex items-center justify-center flex-shrink-0 font-bold text-white"
                    style={{ backgroundColor: layer.color }}
                  >
                    {6 - layer.order}
                  </div>
                  <div>
                    <h3
                      className="text-base md:text-lg font-bold uppercase tracking-wide"
                      style={{ color: layer.color }}
                    >
                      {layer.name}
                    </h3>
                    <p className="text-xs" style={{ color: '#718096' }}>
                      Layer {layer.order}
                    </p>
                  </div>
                </div>

                {/* Purpose */}
                <div className="flex-1">
                  <p className="text-sm md:text-base" style={{ color: '#4A5568', lineHeight: '1.6' }}>
                    {layer.purpose}
                  </p>
                </div>
              </div>

              {/* Expanded details on hover/selection */}
              {selectedLayer === layer.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  transition={{ duration: 0.3 }}
                  className="mt-4 pt-4 border-t grid grid-cols-1 md:grid-cols-2 gap-4"
                  style={{ borderColor: '#E2E8F0' }}
                >
                  {/* Key Responsibilities */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: '#718096' }}>
                      Key Responsibilities
                    </h4>
                    <ul className="space-y-1 text-xs md:text-sm" style={{ color: '#4A5568' }}>
                      {layer.keyResponsibilities.map((resp, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span style={{ color: layer.borderColor }}>•</span>
                          <span>{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Examples */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: '#718096' }}>
                      Examples
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {layer.examples.map((example, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-1 rounded text-xs font-mono"
                          style={{
                            backgroundColor: layer.color,
                            color: '#FFFFFF',
                            opacity: 0.9
                          }}
                        >
                          {example}
                        </span>
                      ))}
                    </div>

                    {/* Core Rule */}
                    <div className="mt-4 p-3 rounded" style={{ backgroundColor: '#F7FAFC', borderLeft: `3px solid ${layer.borderColor}` }}>
                      <p className="text-xs italic" style={{ color: '#2D3748' }}>
                        "{layer.coreRule}"
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>

            {/* Arrow between layers (except after UI) */}
            {layer.order > 1 && (
              <div className="flex justify-center py-2">
                <div className="w-0.5 h-4 bg-slate-300"></div>
              </div>
            )}
          </div>
        ))}
      </motion.div>

      {/* Interaction Rules */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="p-4 md:p-6 rounded-lg border"
        style={{ backgroundColor: '#F7FAFC', borderColor: '#CBD5E0' }}
      >
        <h3 className="text-base md:text-lg font-bold mb-3" style={{ color: '#000033' }}>
          Stack Interaction Rules
        </h3>
        <div className="space-y-2 text-sm" style={{ color: '#4A5568' }}>
          <p><strong>Primary Pattern:</strong> UI → Agents/Programs → Data Graph (governed by Spine)</p>
          <p><strong>Non-Negotiable Rule:</strong> No upper layer may violate lower-layer constraints</p>
          <p><strong>Examples:</strong> UI cannot bypass program contracts • Agents cannot bypass tool registry • Programs cannot silently mutate stores • No component may bypass Spine controls</p>
        </div>
      </motion.div>

      {/* Architectural Maxims */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.0 }}
        className="p-4 md:p-6 rounded-lg"
        style={{ backgroundColor: '#000033', color: '#FFFFFF' }}
      >
        <h3 className="text-base md:text-lg font-bold mb-4 text-center uppercase tracking-wide">
          Architectural Maxims
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 text-xs md:text-sm">
          {ARCHITECTURAL_MAXIMS.map((maxim, idx) => (
            <div key={idx} className="flex items-start gap-2">
              <span style={{ color: '#4FC3F7' }}>▸</span>
              <span>{maxim}</span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Final Directive */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="p-4 md:p-6 rounded-lg border-t-4"
        style={{ backgroundColor: '#FFFFFF', borderTopColor: '#000033' }}
      >
        <p className="text-sm md:text-base text-center font-semibold" style={{ color: '#000033', lineHeight: '1.7' }}>
          This platform must be built as a <strong>governed litigation reasoning system</strong>, not as an unstructured AI application.
          Clean separation between governance, memory, computation, reasoning, and presentation is the primary defense against architectural drift, legal risk, and platform spaghetti.
        </p>
      </motion.div>
    </div>
  );
}
