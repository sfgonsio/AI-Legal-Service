import { motion } from "motion/react";
import { useState } from "react";

interface MatrixRow {
  stage: string;
  artifact: string;
  supplier: string;
  inputs: string;
  process: string;
  output: string;
  consumer: string;
  producerType: "Program" | "Agent" | "Attorney";
  platformComponent: string;
  approvalRequired: boolean;
}

const MATRIX_ROWS: MatrixRow[] = [
  // Stage 1: Client Intake
  {
    stage: "Client Intake",
    artifact: "Interview Transcript",
    supplier: "Client",
    inputs: "Client narrative",
    process: "Structured interview capture",
    output: "Interview Record",
    consumer: "Mapping Agent",
    producerType: "Agent",
    platformComponent: "INTERVIEW_AGENT",
    approvalRequired: false
  },
  {
    stage: "Client Intake",
    artifact: "Initial Fact List",
    supplier: "Interview Agent",
    inputs: "Interview transcript",
    process: "Fact extraction",
    output: "Raw fact candidates",
    consumer: "Fact normalization",
    producerType: "Program",
    platformComponent: "program_FACT_NORMALIZATION",
    approvalRequired: false
  },
  // Stage 2: Case Evaluation
  {
    stage: "Case Evaluation",
    artifact: "Case Theory Draft",
    supplier: "Attorney + system",
    inputs: "Facts + law",
    process: "Legal theory formulation",
    output: "Theory outline",
    consumer: "COA analysis",
    producerType: "Agent",
    platformComponent: "agent_COA_REASONER",
    approvalRequired: true
  },
  // Stage 3: Evidence Collection
  {
    stage: "Evidence Collection",
    artifact: "Evidence Repository",
    supplier: "Client / Documents",
    inputs: "Files, emails, contracts",
    process: "Document ingestion",
    output: "Evidence dataset",
    consumer: "Fact normalization",
    producerType: "Program",
    platformComponent: "program_PROCESSING",
    approvalRequired: false
  },
  {
    stage: "Evidence Collection",
    artifact: "Evidence Metadata",
    supplier: "Processing engine",
    inputs: "Documents",
    process: "Metadata extraction",
    output: "Evidence index",
    consumer: "Tagging engine",
    producerType: "Program",
    platformComponent: "program_PROCESSING",
    approvalRequired: false
  },
  // Stage 4: Fact Normalization
  {
    stage: "Fact Normalization",
    artifact: "Normalized Facts",
    supplier: "Evidence + interview",
    inputs: "Evidence text",
    process: "Fact extraction",
    output: "Structured facts",
    consumer: "Event mapping",
    producerType: "Program",
    platformComponent: "program_FACT_NORMALIZATION",
    approvalRequired: false
  },
  // Stage 5: Event Mapping
  {
    stage: "Event Mapping",
    artifact: "Event Candidates",
    supplier: "Facts",
    inputs: "Normalized facts",
    process: "Event construction",
    output: "Event objects",
    consumer: "Timeline + COA",
    producerType: "Program",
    platformComponent: "program_COMPOSITE_ENGINE",
    approvalRequired: false
  },
  {
    stage: "Event Mapping",
    artifact: "Case Timeline",
    supplier: "Event candidates",
    inputs: "Events",
    process: "Chronological assembly",
    output: "Litigation timeline",
    consumer: "Attorney review",
    producerType: "Agent",
    platformComponent: "MAPPING_AGENT",
    approvalRequired: true
  },
  // Stage 6: Legal Theory
  {
    stage: "Legal Theory",
    artifact: "COA Coverage Matrix",
    supplier: "Timeline + facts",
    inputs: "COA rules",
    process: "Coverage analysis",
    output: "Element coverage map",
    consumer: "Attorney",
    producerType: "Program",
    platformComponent: "program_COA_ENGINE",
    approvalRequired: false
  },
  {
    stage: "Legal Theory",
    artifact: "Legal Argument Proposal",
    supplier: "Coverage matrix",
    inputs: "Evidence + elements",
    process: "Narrative synthesis",
    output: "Argument draft",
    consumer: "Attorney",
    producerType: "Agent",
    platformComponent: "agent_COA_REASONER",
    approvalRequired: true
  },
  // Stage 7: Pleading Drafting
  {
    stage: "Pleading Drafting",
    artifact: "Complaint Draft",
    supplier: "Legal theory",
    inputs: "COA coverage",
    process: "Complaint drafting",
    output: "Complaint document",
    consumer: "Court filing",
    producerType: "Agent",
    platformComponent: "OPPOSITION_AGENT",
    approvalRequired: true
  },
  // Stage 8: Discovery
  {
    stage: "Discovery",
    artifact: "Discovery Request Packet",
    supplier: "Case facts",
    inputs: "Evidence gaps",
    process: "Discovery planning",
    output: "Interrogatories / RFPs",
    consumer: "Opposing party",
    producerType: "Program",
    platformComponent: "program_DISCOVERY_PACKET",
    approvalRequired: true
  },
  {
    stage: "Discovery",
    artifact: "Discovery Response Map",
    supplier: "Opposing responses",
    inputs: "Documents",
    process: "Evidence correlation",
    output: "Response index",
    consumer: "COA coverage",
    producerType: "Program",
    platformComponent: "program_COVERAGE_ANALYSIS",
    approvalRequired: true
  },
  // Stage 9: Motion Practice
  {
    stage: "Motion Practice",
    artifact: "Motion Draft",
    supplier: "Evidence + law",
    inputs: "Legal arguments",
    process: "Motion construction",
    output: "Motion document",
    consumer: "Court filing",
    producerType: "Agent",
    platformComponent: "OPPOSITION_AGENT",
    approvalRequired: true
  },
  // Stage 10: Trial Prep
  {
    stage: "Trial Prep",
    artifact: "Exhibit List",
    supplier: "Evidence repository",
    inputs: "Documents",
    process: "Exhibit selection",
    output: "Exhibit catalog",
    consumer: "Court",
    producerType: "Program",
    platformComponent: "program_BURDEN_MAP_BUILDER",
    approvalRequired: true
  },
  {
    stage: "Trial Prep",
    artifact: "Witness Outline",
    supplier: "Facts + events",
    inputs: "Timeline",
    process: "Witness narrative creation",
    output: "Witness prep guide",
    consumer: "Attorney",
    producerType: "Agent",
    platformComponent: "OPPOSITION_AGENT",
    approvalRequired: true
  }
];

export function ArtifactProductionMatrix() {
  const [selectedRow, setSelectedRow] = useState<number | null>(null);
  const [filterStage, setFilterStage] = useState<string | null>(null);

  const uniqueStages = Array.from(new Set(MATRIX_ROWS.map(row => row.stage)));
  const filteredRows = filterStage 
    ? MATRIX_ROWS.filter(row => row.stage === filterStage)
    : MATRIX_ROWS;

  // Count artifacts by type
  const programCount = MATRIX_ROWS.filter(r => r.producerType === "Program").length;
  const agentCount = MATRIX_ROWS.filter(r => r.producerType === "Agent").length;
  const attorneyCount = MATRIX_ROWS.filter(r => r.producerType === "Attorney").length;

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-4"
      >
        <div className="text-center">
          <h3 className="text-base md:text-lg font-bold uppercase tracking-wide mb-3" style={{ color: '#000033' }}>
            ARTIFACT PRODUCTION MATRIX
          </h3>
          <p className="text-sm md:text-base mb-4" style={{ color: '#4A5568' }}>
            SIPOC-style workflow showing Supplier → Inputs → Process → Output → Consumer for each litigation artifact
          </p>
        </div>

        {/* Stage Filter */}
        <div className="flex flex-wrap gap-2 justify-center">
          <button
            onClick={() => setFilterStage(null)}
            className="px-3 py-1.5 text-xs rounded-lg transition-all font-medium"
            style={{
              backgroundColor: filterStage === null ? '#000033' : '#FFFFFF',
              color: filterStage === null ? '#FFFFFF' : '#4A5568',
              border: '1px solid #C0C5CE'
            }}
          >
            All Stages ({MATRIX_ROWS.length})
          </button>
          {uniqueStages.map((stage) => {
            const stageCount = MATRIX_ROWS.filter(r => r.stage === stage).length;
            return (
              <button
                key={stage}
                onClick={() => setFilterStage(stage)}
                className="px-3 py-1.5 text-xs rounded-lg transition-all font-medium"
                style={{
                  backgroundColor: filterStage === stage ? '#000033' : '#FFFFFF',
                  color: filterStage === stage ? '#FFFFFF' : '#4A5568',
                  border: '1px solid #C0C5CE'
                }}
              >
                {stage} ({stageCount})
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Matrix Table - Scrollable on mobile */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="overflow-x-auto"
      >
        <div className="min-w-[900px]">
          {/* Table Header */}
          <div 
            className="grid grid-cols-9 gap-2 p-3 rounded-t-lg text-xs font-semibold uppercase tracking-wide"
            style={{
              backgroundColor: '#000033',
              color: '#FFFFFF'
            }}
          >
            <div>Stage</div>
            <div>Artifact</div>
            <div>Supplier</div>
            <div>Inputs</div>
            <div>Process</div>
            <div>Output</div>
            <div>Consumer</div>
            <div>Producer</div>
            <div className="text-center">Approval</div>
          </div>

          {/* Table Rows */}
          <div className="rounded-b-lg border border-t-0" style={{ borderColor: '#C0C5CE' }}>
            {filteredRows.map((row, index) => (
              <div
                key={index}
                onMouseEnter={() => setSelectedRow(index)}
                onMouseLeave={() => setSelectedRow(null)}
                className="grid grid-cols-9 gap-2 p-3 border-t transition-all cursor-pointer"
                style={{
                  borderColor: '#E2E8F0',
                  backgroundColor: selectedRow === index ? '#F4F6F8' : '#FFFFFF'
                }}
              >
                <div className="text-xs font-semibold" style={{ color: '#000033' }}>
                  {row.stage}
                </div>
                <div className="text-xs font-semibold" style={{ color: '#003D82' }}>
                  {row.artifact}
                </div>
                <div className="text-xs" style={{ color: '#4A5568' }}>
                  {row.supplier}
                </div>
                <div className="text-xs" style={{ color: '#4A5568' }}>
                  {row.inputs}
                </div>
                <div className="text-xs" style={{ color: '#4A5568' }}>
                  {row.process}
                </div>
                <div className="text-xs" style={{ color: '#4A5568' }}>
                  {row.output}
                </div>
                <div className="text-xs" style={{ color: '#4A5568' }}>
                  {row.consumer}
                </div>
                <div>
                  <span 
                    className="text-[10px] px-2 py-0.5 rounded uppercase tracking-wide"
                    style={{
                      backgroundColor: row.producerType === "Program" ? '#E6F2FF' : 
                                     row.producerType === "Agent" ? '#FFF4E6' : '#F0FFF4',
                      color: row.producerType === "Program" ? '#003D82' : 
                             row.producerType === "Agent" ? '#8B5A00' : '#2D5F3F'
                    }}
                  >
                    {row.producerType}
                  </span>
                </div>
                <div className="text-center">
                  <span 
                    className="text-[10px] px-2 py-0.5 rounded font-semibold"
                    style={{
                      backgroundColor: row.approvalRequired ? '#FFEBEE' : '#E8F5E9',
                      color: row.approvalRequired ? '#C62828' : '#2E7D32'
                    }}
                  >
                    {row.approvalRequired ? 'Required' : 'No'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Matrix Legend */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: '#FFFFFF',
          border: '2px solid #C0C5CE'
        }}
      >
        <h4 className="font-bold text-base uppercase tracking-wide mb-5" style={{ color: '#000033' }}>
          MATRIX LEGEND
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="font-bold text-sm mb-3" style={{ color: '#000033' }}>Producer Types:</div>
            <div className="space-y-2 text-sm leading-relaxed" style={{ color: '#4A5568' }}>
              <div className="flex items-start gap-2">
                <span className="px-2 py-0.5 rounded text-xs font-medium mt-0.5" style={{ backgroundColor: '#E6F2FF', color: '#003D82' }}>Program</span>
                <span>= Deterministic execution</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="px-2 py-0.5 rounded text-xs font-medium mt-0.5" style={{ backgroundColor: '#FFF4E6', color: '#8B5A00' }}>Agent</span>
                <span>= AI-assisted reasoning</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="px-2 py-0.5 rounded text-xs font-medium mt-0.5" style={{ backgroundColor: '#F0FFF4', color: '#2D5F3F' }}>Attorney</span>
                <span>= Human expert</span>
              </div>
            </div>
          </div>
          
          <div>
            <div className="font-bold text-sm mb-3" style={{ color: '#000033' }}>Approval Status:</div>
            <div className="space-y-2 text-sm leading-relaxed" style={{ color: '#4A5568' }}>
              <div className="flex items-start gap-2">
                <span className="px-2 py-0.5 rounded text-xs font-medium mt-0.5" style={{ backgroundColor: '#FFEBEE', color: '#C62828' }}>Required</span>
                <span>= Attorney validation mandatory</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="px-2 py-0.5 rounded text-xs font-medium mt-0.5" style={{ backgroundColor: '#E8F5E9', color: '#2E7D32' }}>No</span>
                <span>= Automated processing</span>
              </div>
            </div>
          </div>
          
          <div>
            <div className="font-bold text-sm mb-3" style={{ color: '#000033' }}>SIPOC Flow:</div>
            <div className="text-sm leading-relaxed" style={{ color: '#4A5568' }}>
              Supplier → Inputs → Process → Output → Consumer ensures complete artifact lineage and traceability.
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}