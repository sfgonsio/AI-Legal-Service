import { motion } from "motion/react";
import { useState } from "react";

interface FlowStage {
  id: number;
  label: string;
  subtitle: string;
  caption: string;
  examples: string[];
  systemComponent: string;
  componentType: "Evidence" | "Program" | "Agent" | "Output";
}

const FLOW_STAGES: FlowStage[] = [
  {
    id: 1,
    label: "Evidence",
    subtitle: "Contracts, emails, records, testimony",
    caption: "Raw information enters the system",
    examples: ["Contract between Supplier and Distributor", "Email correspondence", "Financial records"],
    systemComponent: "Evidence Layer",
    componentType: "Evidence"
  },
  {
    id: 2,
    label: "Fact Extraction",
    subtitle: "Extract legally relevant facts",
    caption: "Text transformed into structured facts",
    examples: ["Supplier and Distributor signed contract in 2022", "Distributor failed to deliver payment", "Payment due date was March 15, 2023"],
    systemComponent: "FACT_NORMALIZATION, TAGGING_ENGINE",
    componentType: "Program"
  },
  {
    id: 3,
    label: "Event Construction",
    subtitle: "Facts assembled into legal events",
    caption: "Timeline of chronological events created",
    examples: ["Contract Signed (Jan 2022)", "Payment Due (Mar 2023)", "Payment Breach (Mar 2023)"],
    systemComponent: "COMPOSITE_ENGINE",
    componentType: "Program"
  },
  {
    id: 4,
    label: "Legal Element Mapping",
    subtitle: "Evidence tested against legal elements",
    caption: "COA elements matched to evidence",
    examples: ["✓ Valid Contract", "✓ Plaintiff Performance", "✓ Defendant Breach", "✓ Damages"],
    systemComponent: "COA_ENGINE, BURDEN_MAP_BUILDER",
    componentType: "Program"
  },
  {
    id: 5,
    label: "Legal Reasoning",
    subtitle: "AI assists legal argument formation",
    caption: "Evidence synthesized into legal arguments",
    examples: ["Defendant breached the contract by failing to pay the agreed amount", "Evidence supports all elements of breach of contract claim"],
    systemComponent: "COA_REASONER",
    componentType: "Agent"
  },
  {
    id: 6,
    label: "Litigation Artifacts",
    subtitle: "Court-ready legal documents",
    caption: "Documents generated for filing",
    examples: ["Complaint", "Interrogatories", "Motion for Summary Judgment", "Trial Brief"],
    systemComponent: "OPPOSITION_AGENT",
    componentType: "Agent"
  },
  {
    id: 7,
    label: "Court Process",
    subtitle: "Litigation supported by structured evidence",
    caption: "Platform supports entire court lifecycle",
    examples: ["Filing", "Discovery", "Motion Practice", "Trial"],
    systemComponent: "Human Decision Layer",
    componentType: "Output"
  }
];

export function LitigationIntelligenceFlow() {
  const [selectedStage, setSelectedStage] = useState<number | null>(null);

  const getStageColor = (componentType: string) => {
    const colors: Record<string, { bg: string; border: string; text: string; badge: string }> = {
      "Evidence": { 
        bg: "var(--slide-pale-silver)", 
        border: "var(--slide-steel)", 
        text: "var(--slide-charcoal)",
        badge: "var(--slide-steel)"
      },
      "Program": { 
        bg: "var(--slide-light-blue)", 
        border: "var(--slide-royal-blue)", 
        text: "var(--slide-deep-blue)",
        badge: "var(--slide-deep-blue)"
      },
      "Agent": { 
        bg: "#D4EDFF", 
        border: "var(--slide-deep-blue)", 
        text: "var(--slide-navy)",
        badge: "var(--slide-royal-blue)"
      },
      "Output": { 
        bg: "#F0F9FF", 
        border: "var(--slide-sky-blue)", 
        text: "var(--slide-deep-blue)",
        badge: "var(--slide-sky-blue)"
      }
    };
    return colors[componentType] || colors["Evidence"];
  };

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center space-y-3"
      >
        <h3 className="text-lg md:text-xl font-bold uppercase tracking-wide" style={{ color: 'var(--slide-navy)' }}>
          TRIALFORGE INTELLIGENCE FLOW
        </h3>
        <p className="text-base md:text-lg font-semibold" style={{ color: 'var(--slide-text-secondary)' }}>
          How Evidence Becomes Legal Strategy
        </p>
        <p className="text-sm" style={{ color: 'var(--slide-text-muted)' }}>
          A single piece of evidence transforms through seven stages into court-ready litigation artifacts
        </p>
      </motion.div>

      {/* Flow Diagram - Horizontal on desktop, vertical on mobile */}
      <div className="relative">
        {/* Desktop: Horizontal Flow */}
        <div className="hidden lg:block">
          <div className="flex items-start justify-between gap-4">
            {FLOW_STAGES.map((stage, index) => {
              const colors = getStageColor(stage.componentType);
              const isSelected = selectedStage === stage.id;

              return (
                <div key={stage.id} className="flex items-center flex-1">
                  {/* Stage Card */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index }}
                    onMouseEnter={() => setSelectedStage(stage.id)}
                    onMouseLeave={() => setSelectedStage(null)}
                    className="rounded-lg border-2 p-4 cursor-pointer transition-all flex-1"
                    style={{
                      backgroundColor: isSelected ? colors.bg : 'var(--slide-white)',
                      borderColor: isSelected ? colors.border : 'var(--slide-border-subtle)',
                      borderWidth: isSelected ? '3px' : '2px',
                      minHeight: '200px'
                    }}
                  >
                    {/* Stage Number */}
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center mb-3 font-bold"
                      style={{
                        backgroundColor: colors.badge,
                        color: 'var(--slide-white)'
                      }}
                    >
                      {stage.id}
                    </div>

                    {/* Label */}
                    <h4 className="text-sm font-bold mb-2" style={{ color: 'var(--slide-navy)' }}>
                      {stage.label}
                    </h4>

                    {/* Subtitle */}
                    <p className="text-xs mb-3" style={{ color: colors.text }}>
                      {stage.subtitle}
                    </p>

                    {/* Component Badge */}
                    <div className="mt-auto">
                      <span 
                        className="text-[10px] px-2 py-1 rounded uppercase tracking-wide font-semibold"
                        style={{
                          backgroundColor: colors.bg,
                          color: colors.text,
                          border: `1px solid ${colors.border}`
                        }}
                      >
                        {stage.componentType}
                      </span>
                    </div>
                  </motion.div>

                  {/* Arrow */}
                  {index < FLOW_STAGES.length - 1 && (
                    <svg width="40" height="24" viewBox="0 0 40 24" className="mx-2 flex-shrink-0">
                      <path 
                        d="M0 12 L32 12 M24 6 L32 12 L24 18" 
                        stroke="var(--slide-royal-blue)" 
                        strokeWidth="2" 
                        fill="none"
                      />
                    </svg>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Mobile/Tablet: Vertical Flow */}
        <div className="lg:hidden space-y-4">
          {FLOW_STAGES.map((stage, index) => {
            const colors = getStageColor(stage.componentType);
            const isSelected = selectedStage === stage.id;

            return (
              <div key={stage.id} className="space-y-3">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * index }}
                  onMouseEnter={() => setSelectedStage(stage.id)}
                  onMouseLeave={() => setSelectedStage(null)}
                  className="rounded-lg border-2 p-5 cursor-pointer transition-all"
                  style={{
                    backgroundColor: isSelected ? colors.bg : 'var(--slide-white)',
                    borderColor: isSelected ? colors.border : 'var(--slide-border-subtle)'
                  }}
                >
                  <div className="flex items-start gap-4">
                    <div 
                      className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-lg"
                      style={{
                        backgroundColor: colors.badge,
                        color: 'var(--slide-white)'
                      }}
                    >
                      {stage.id}
                    </div>

                    <div className="flex-1">
                      <h4 className="text-base font-bold mb-2" style={{ color: 'var(--slide-navy)' }}>
                        {stage.label}
                      </h4>
                      <p className="text-sm mb-3" style={{ color: colors.text }}>
                        {stage.subtitle}
                      </p>
                      <span 
                        className="text-xs px-3 py-1 rounded uppercase tracking-wide font-semibold"
                        style={{
                          backgroundColor: colors.bg,
                          color: colors.text,
                          border: `1px solid ${colors.border}`
                        }}
                      >
                        {stage.componentType}
                      </span>
                    </div>
                  </div>
                </motion.div>

                {index < FLOW_STAGES.length - 1 && (
                  <div className="flex justify-center">
                    <svg width="24" height="40" viewBox="0 0 24 40">
                      <path 
                        d="M12 0 L12 32 M6 24 L12 32 L18 24" 
                        stroke="var(--slide-royal-blue)" 
                        strokeWidth="2" 
                        fill="none"
                      />
                    </svg>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Detail Panel */}
      {selectedStage !== null && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="rounded-lg border-2 p-6"
          style={{
            backgroundColor: 'var(--slide-bg-primary)',
            borderColor: 'var(--slide-navy)'
          }}
        >
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div 
                className="w-14 h-14 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-xl"
                style={{
                  backgroundColor: getStageColor(FLOW_STAGES[selectedStage - 1].componentType).badge,
                  color: 'var(--slide-white)'
                }}
              >
                {selectedStage}
              </div>
              
              <div className="flex-1">
                <h4 className="text-lg font-bold mb-2" style={{ color: 'var(--slide-navy)' }}>
                  {FLOW_STAGES[selectedStage - 1].label}
                </h4>
                <p className="text-sm mb-3" style={{ color: 'var(--slide-text-secondary)' }}>
                  {FLOW_STAGES[selectedStage - 1].caption}
                </p>
              </div>
            </div>

            {/* System Component */}
            <div className="pt-4 border-t" style={{ borderColor: 'var(--slide-border-light)' }}>
              <p className="text-xs uppercase tracking-wide font-semibold mb-2" style={{ color: 'var(--slide-text-muted)' }}>
                System Component
              </p>
              <p className="text-sm font-mono" style={{ color: 'var(--slide-navy)' }}>
                {FLOW_STAGES[selectedStage - 1].systemComponent}
              </p>
            </div>

            {/* Examples */}
            <div className="pt-4 border-t" style={{ borderColor: 'var(--slide-border-light)' }}>
              <p className="text-xs uppercase tracking-wide font-semibold mb-3" style={{ color: 'var(--slide-text-muted)' }}>
                Examples
              </p>
              <div className="space-y-2">
                {FLOW_STAGES[selectedStage - 1].examples.map((example, idx) => (
                  <div 
                    key={idx}
                    className="text-sm px-3 py-2 rounded"
                    style={{
                      backgroundColor: 'var(--slide-bg-secondary)',
                      color: 'var(--slide-text-secondary)'
                    }}
                  >
                    {example}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Transformation Summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: 'var(--slide-bg-primary)',
          borderTop: '3px solid var(--slide-navy)'
        }}
      >
        <h4 className="font-bold text-sm uppercase tracking-wide mb-4" style={{ color: 'var(--slide-navy)' }}>
          TRANSFORMATION PIPELINE
        </h4>
        <div className="flex flex-wrap items-center gap-2 text-sm justify-center">
          {["Document", "Facts", "Events", "Legal Elements", "Argument", "Court Filing"].map((step, idx) => (
            <div key={step} className="flex items-center">
              <span 
                className="px-4 py-2 rounded-lg font-semibold"
                style={{
                  backgroundColor: 'var(--slide-light-blue)',
                  color: 'var(--slide-deep-blue)'
                }}
              >
                {step}
              </span>
              {idx < 5 && (
                <svg width="24" height="24" viewBox="0 0 24 24" className="mx-2">
                  <path 
                    d="M5 12 L19 12 M14 7 L19 12 L14 17" 
                    stroke="var(--slide-royal-blue)" 
                    strokeWidth="2" 
                    fill="none"
                  />
                </svg>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Key Insight */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: 'var(--slide-bg-accent)',
          border: '1px solid var(--slide-border-secondary)'
        }}
      >
        <p className="text-sm text-center" style={{ color: 'var(--slide-text-secondary)' }}>
          <span className="font-bold" style={{ color: 'var(--slide-navy)' }}>Visual Story:</span> Each transformation step shows increasing structure and legal clarity. Raw evidence becomes structured facts, facts become chronological events, events map to legal elements, elements form arguments, and arguments become court filings.
        </p>
      </motion.div>
    </div>
  );
}