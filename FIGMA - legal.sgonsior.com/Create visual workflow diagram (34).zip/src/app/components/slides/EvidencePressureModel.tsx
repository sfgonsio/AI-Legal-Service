import { motion } from "motion/react";

const INTAKE_EVIDENCE = [
  "Emails",
  "Agreements",
  "Board Minutes",
  "Text Messages",
  "Cap Tables",
];

const EVALUATION_GATES = [
  "Authentication",
  "Hearsay Analysis",
  "Privilege Review",
];

const OUTPUT_ARTIFACTS = [
  "Complaint Paragraphs",
  "Exhibits",
  "Motion in Limine",
  "Deposition Outline",
  "Trial Brief",
];

const STRATEGIC_IMPACTS = [
  "Fewer exclusion surprises",
  "Stronger motion posture",
  "Early element weakness detection",
];

export function EvidencePressureModel() {
  return (
    <div className="relative w-full space-y-6 md:space-y-8">
      {/* Silver rule */}
      <div style={{ height: "1px", backgroundColor: "#C0C5CE", marginBottom: "16px" }} />

      {/* Main 3-Stage Transformation Pipeline */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="relative rounded-lg md:rounded-xl overflow-hidden border"
        style={{
          backgroundColor: "#FFFFFF",
          borderColor: "#C0C5CE",
        }}
      >
        {/* Three Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-0">
          
          {/* STAGE 1: EVIDENCE INTAKE */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="p-6 md:p-8 border-b lg:border-b-0 lg:border-r"
            style={{
              backgroundColor: "#F9FAFB",
              borderColor: "#E2E8F0",
            }}
          >
            {/* Stage Label */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                  style={{ backgroundColor: "#000033", color: "#FFFFFF" }}
                >
                  1
                </div>
                <h3
                  className="text-sm md:text-base font-bold uppercase tracking-wide"
                  style={{ color: "#000033" }}
                >
                  Evidence Intake
                </h3>
              </div>
              <div
                style={{
                  width: "40px",
                  height: "3px",
                  backgroundColor: "#000033",
                  opacity: 0.3,
                }}
              />
            </div>

            {/* Evidence Items */}
            <div className="space-y-2.5 mb-6">
              {INTAKE_EVIDENCE.map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.35 + idx * 0.08 }}
                  className="px-3 py-2 rounded-md border"
                  style={{
                    backgroundColor: "#FFFFFF",
                    borderColor: "#C0C5CE",
                    transform: `rotate(${idx % 2 === 0 ? -0.5 : 0.5}deg)`,
                  }}
                >
                  <p className="text-xs font-medium" style={{ color: "#4A5568" }}>
                    {item}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* Conversion to Foundation */}
            <div
              className="px-4 py-3 rounded-lg text-center"
              style={{
                backgroundColor: "#000033",
                color: "#FFFFFF",
              }}
            >
              <p className="text-xs md:text-sm font-semibold leading-snug">
                Foundation Packets
              </p>
              <p className="text-[10px] md:text-xs mt-1.5" style={{ opacity: 0.85 }}>
                Hash Verified • Case Scoped
              </p>
            </div>
          </motion.div>

          {/* STAGE 2: EVALUATION ENGINE */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="p-6 md:p-8 border-b lg:border-b-0 lg:border-r"
            style={{
              backgroundColor: "#FFFFFF",
              borderColor: "#E2E8F0",
            }}
          >
            {/* Stage Label */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                  style={{ backgroundColor: "#000033", color: "#FFFFFF" }}
                >
                  2
                </div>
                <h3
                  className="text-sm md:text-base font-bold uppercase tracking-wide"
                  style={{ color: "#000033" }}
                >
                  Evaluation Engine
                </h3>
              </div>
              <div
                style={{
                  width: "40px",
                  height: "3px",
                  backgroundColor: "#000033",
                }}
              />
            </div>

            {/* Three Gates */}
            <div className="space-y-4 mb-6">
              {EVALUATION_GATES.map((gate, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: 0.55 + idx * 0.12 }}
                  className="relative"
                >
                  <div
                    className="flex items-center justify-between px-4 md:px-5 py-4 rounded-lg border-2"
                    style={{
                      backgroundColor: "#F4F6F8",
                      borderColor: "#000033",
                    }}
                  >
                    <div
                      className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{
                        backgroundColor: "#000033",
                        color: "#FFFFFF",
                      }}
                    >
                      {idx + 1}
                    </div>

                    <p
                      className="flex-1 text-center text-xs md:text-sm font-bold uppercase tracking-wide"
                      style={{ color: "#000033" }}
                    >
                      {gate}
                    </p>

                    <div
                      className="flex-shrink-0 w-3 h-3 rounded-full"
                      style={{
                        backgroundColor: "#000033",
                      }}
                    />
                  </div>

                  {idx < EVALUATION_GATES.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div
                        style={{
                          width: 0,
                          height: 0,
                          borderLeft: "8px solid transparent",
                          borderRight: "8px solid transparent",
                          borderTop: "10px solid #000033",
                        }}
                      />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Audit Ledger Display */}
            <div
              className="px-4 py-3 rounded-lg border mb-4"
              style={{
                backgroundColor: "#F9FAFB",
                borderColor: "#C0C5CE",
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div
                  style={{
                    width: "6px",
                    height: "6px",
                    borderRadius: "999px",
                    backgroundColor: "#000033",
                  }}
                />
                <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "#000033" }}>
                  Audit Ledger
                </p>
              </div>
              <p className="text-[10px] md:text-xs leading-relaxed" style={{ color: "#4A5568" }}>
                Every evaluation logged • Version tracked • Replay enabled
              </p>
            </div>

            {/* Guarantees */}
            <div
              className="text-center px-4 py-3 rounded-lg"
              style={{
                backgroundColor: "#000033",
                color: "#FFFFFF",
              }}
            >
              <p className="text-xs md:text-sm font-semibold tracking-wide">
                Versioned • Deterministic • Replayable
              </p>
            </div>
          </motion.div>

          {/* STAGE 3: LITIGATION OUTPUT */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="p-6 md:p-8"
            style={{
              backgroundColor: "#F9FAFB",
            }}
          >
            {/* Stage Label */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                  style={{ backgroundColor: "#000033", color: "#FFFFFF" }}
                >
                  3
                </div>
                <h3
                  className="text-sm md:text-base font-bold uppercase tracking-wide"
                  style={{ color: "#000033" }}
                >
                  Litigation Output
                </h3>
              </div>
              <div
                style={{
                  width: "40px",
                  height: "3px",
                  backgroundColor: "#000033",
                }}
              />
            </div>

            {/* Output Artifacts */}
            <div className="space-y-3 mb-6">
              {OUTPUT_ARTIFACTS.map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.85 + idx * 0.08 }}
                  className="px-4 py-3 rounded-md border"
                  style={{
                    backgroundColor: "#FFFFFF",
                    borderColor: "#000033",
                  }}
                >
                  <p className="text-xs md:text-sm font-semibold" style={{ color: "#000033" }}>
                    {item}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* Audit Ledger Display (Output Stage) */}
            <div
              className="px-4 py-3 rounded-lg border mb-4"
              style={{
                backgroundColor: "#FFFFFF",
                borderColor: "#C0C5CE",
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div
                  style={{
                    width: "6px",
                    height: "6px",
                    borderRadius: "999px",
                    backgroundColor: "#000033",
                  }}
                />
                <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "#000033" }}>
                  Audit Ledger
                </p>
              </div>
              <p className="text-[10px] md:text-xs leading-relaxed" style={{ color: "#4A5568" }}>
                Output traced to source • Evidence chain preserved
              </p>
            </div>

            {/* Strategic Impact Box */}
            <div
              className="px-4 py-4 rounded-lg border"
              style={{
                backgroundColor: "#FFFFFF",
                borderColor: "#000033",
              }}
            >
              <p
                className="text-xs font-bold uppercase tracking-wide mb-3"
                style={{ color: "#000033" }}
              >
                Strategic Impact
              </p>
              <div className="space-y-2">
                {STRATEGIC_IMPACTS.map((impact, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <div
                      className="rounded-full flex-shrink-0 mt-1"
                      style={{
                        width: "5px",
                        height: "5px",
                        backgroundColor: "#000033",
                      }}
                    />
                    <p className="text-[10px] md:text-xs leading-relaxed" style={{ color: "#4A5568" }}>
                      {impact}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* STAGE 4: ENTITY REGISTRY (Foundation Layer) */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 1.0 }}
        className="rounded-lg md:rounded-xl overflow-hidden border"
        style={{
          backgroundColor: "#F4F6F8",
          borderColor: "#C0C5CE",
        }}
      >
        <div className="p-6 md:p-8">
          <div className="flex items-start gap-4">
            {/* Stage Number */}
            <div
              className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-base font-bold"
              style={{ backgroundColor: "#000033", color: "#FFFFFF" }}
            >
              4
            </div>

            {/* Content */}
            <div className="flex-1">
              <h3
                className="text-base md:text-lg font-bold uppercase tracking-wide mb-3"
                style={{ color: "#000033" }}
              >
                Entity Registry
              </h3>
              <p className="text-xs md:text-sm leading-relaxed mb-4" style={{ color: "#4A5568" }}>
                Canonical source of truth for parties, declarants, relationships, and roles. Every evidence item references registry entities. Every output inherits verified entity data.
              </p>

              {/* Registry Features Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {["Parties", "Declarants", "Relationships", "Roles"].map((feature, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: 1.1 + idx * 0.08 }}
                    className="px-3 py-2 rounded-md border text-center"
                    style={{
                      backgroundColor: "#FFFFFF",
                      borderColor: "#C0C5CE",
                    }}
                  >
                    <p className="text-xs font-semibold" style={{ color: "#000033" }}>
                      {feature}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* BOTTOM STRIP — PLATFORM GUARANTEES */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="flex flex-wrap items-center justify-center gap-4 md:gap-8 px-6 py-4 rounded-lg"
        style={{
          backgroundColor: "#FFFFFF",
          border: "1px solid #E2E8F0",
        }}
      >
        {["Hash Verified", "Overlay Governed", "Audit Logged", "Replay Equivalent"].map(
          (guarantee, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <div
                style={{
                  width: "6px",
                  height: "6px",
                  borderRadius: "999px",
                  backgroundColor: "#000033",
                }}
              />
              <p className="text-xs md:text-sm font-medium tracking-wide" style={{ color: "#000033" }}>
                {guarantee}
              </p>
            </div>
          )
        )}
      </motion.div>

      {/* Visual Story Statement */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.3 }}
        className="text-center px-6 py-5 rounded-lg"
        style={{
          backgroundColor: "#000033",
        }}
      >
        <p className="text-sm md:text-base font-semibold italic" style={{ color: "#FFFFFF", letterSpacing: "0.02em" }}>
          Evidence enters. Evidence is scrutinized. Evidence emerges defensible.
        </p>
      </motion.div>
    </div>
  );
}