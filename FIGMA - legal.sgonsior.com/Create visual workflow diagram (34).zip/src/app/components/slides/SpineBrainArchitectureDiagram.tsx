import { motion } from "motion/react";

// The Spine & Brain Architecture
// Evidence-Centered Legal Intelligence System
export function SpineBrainArchitectureDiagram() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mx-auto w-full max-w-[1400px] px-4"
    >
      <div className="space-y-3">
        
        {/* CLIENT INPUT LAYER */}
        <ArchLayer bgColor="#000033" textColor="#FFFFFF">
          <div className="text-center">
            <h3 className="font-bold text-sm mb-2 uppercase tracking-wider">
              Client Input
            </h3>
            <p className="text-xs opacity-70">
              Unstructured narratives, documents, and evidence
            </p>
          </div>
        </ArchLayer>

        {/* DOWNWARD ARROW */}
        <div className="flex justify-center">
          <div className="w-0.5 h-6 bg-slate-400"></div>
        </div>

        {/* THE SPINE - NERVOUS SYSTEM */}
        <ArchLayer bgColor="#0a1929" textColor="#FFFFFF">
          <div className="border-2 border-blue-500 p-4 rounded">
            <h3 className="font-bold text-base mb-3 text-center uppercase tracking-wider">
              The System Spine
            </h3>
            <p className="text-xs text-center mb-4 opacity-80">
              Central nervous system connecting all components with traceable signals
            </p>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
              <SpineBox>Workflow Orchestration</SpineBox>
              <SpineBox>State Management</SpineBox>
              <SpineBox>Agent Coordination</SpineBox>
              <SpineBox>Audit Ledger</SpineBox>
              <SpineBox>Deterministic Execution</SpineBox>
            </div>
            <p className="mt-3 text-center text-xs opacity-70">
              Ensures transparency • reproducibility • legal defensibility
            </p>
          </div>
        </ArchLayer>

        {/* DOWNWARD ARROW */}
        <div className="flex justify-center">
          <div className="w-0.5 h-6 bg-slate-400"></div>
        </div>

        {/* THE BRAIN - REASONING CENTER */}
        <ArchLayer bgColor="#1a1a4d" textColor="#FFFFFF">
          <div className="border-2 border-purple-500 p-4 rounded">
            <h3 className="font-bold text-base mb-3 text-center uppercase tracking-wider">
              The Legal Brain
            </h3>
            <p className="text-xs text-center mb-4 opacity-80">
              Structured legal reasoning system grounded in doctrine
            </p>
            
            {/* THREE BRAIN LOBES */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
              
              {/* PERCEPTION LOBE */}
              <BrainLobe title="Perception Lobe" color="#8b5cf6">
                <div className="space-y-2">
                  <div className="text-xs font-semibold mb-1 text-center">
                    Interview Agent
                  </div>
                  <p className="text-xs opacity-80">
                    Converts human narratives into structured legal signals
                  </p>
                  <div className="mt-2 space-y-1 text-xs opacity-70">
                    <div>→ Agreements</div>
                    <div>→ Payments</div>
                    <div>→ Timelines</div>
                    <div>→ Damages</div>
                    <div>→ Witnesses</div>
                  </div>
                </div>
              </BrainLobe>

              {/* MAPPING LOBE */}
              <BrainLobe title="Mapping Lobe" color="#6366f1">
                <div className="space-y-2">
                  <div className="text-xs font-semibold mb-1 text-center">
                    Mapping Agent
                  </div>
                  <p className="text-xs opacity-80">
                    Converts signals into structured facts and evidence
                  </p>
                  <div className="mt-2 space-y-1 text-xs opacity-70">
                    <div>→ Entity extraction</div>
                    <div>→ Timeline creation</div>
                    <div>→ Evidence linking</div>
                    <div>→ Fact normalization</div>
                  </div>
                </div>
              </BrainLobe>

              {/* DOCTRINE LOBE */}
              <BrainLobe title="Doctrine Lobe" color="#3b82f6">
                <div className="space-y-2">
                  <div className="text-xs font-semibold mb-1 text-center">
                    COA Reasoner
                  </div>
                  <p className="text-xs opacity-80">
                    Applies legal doctrine to structured facts
                  </p>
                  <div className="mt-2 space-y-1 text-xs opacity-70">
                    <div>→ CACI instructions</div>
                    <div>→ CA Evidence Code</div>
                    <div>→ Element mapping</div>
                    <div>→ Strategy analysis</div>
                  </div>
                </div>
              </BrainLobe>
            </div>

            <div className="text-center text-xs opacity-70 border-t border-white/20 pt-3">
              Grounded in: CACI • CA Evidence Code • Contract Law • Tort Doctrine • Statutory Frameworks
            </div>
          </div>
        </ArchLayer>

        {/* DOWNWARD ARROW */}
        <div className="flex justify-center">
          <div className="w-0.5 h-6 bg-slate-400"></div>
        </div>

        {/* PATTERN MODULE SYSTEM */}
        <ArchLayer bgColor="#2d2d5c" textColor="#FFFFFF">
          <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
            Pattern Module System
          </h3>
          <p className="text-xs text-center mb-3 opacity-80">
            Legal frameworks encoded as deterministic modules
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <PatternBox>breach_contract_CA</PatternBox>
            <PatternBox>fraud_CA</PatternBox>
            <PatternBox>negligence_CA</PatternBox>
            <PatternBox>breach_fiduciary_CA</PatternBox>
          </div>
          <div className="mt-3 text-xs text-center opacity-70">
            Each module contains: legal elements • predicate rules • evidence signals • sufficiency thresholds
          </div>
        </ArchLayer>

        {/* DOWNWARD ARROW */}
        <div className="flex justify-center">
          <div className="w-0.5 h-6 bg-slate-400"></div>
        </div>

        {/* COVERAGE ENGINE */}
        <ArchLayer bgColor="#40406b" textColor="#FFFFFF">
          <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
            Coverage Engine
          </h3>
          <p className="text-xs text-center mb-3 opacity-80">
            Deterministic evaluation of evidence against legal elements
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <CoverageState state="strong" label="Strong" desc="Well-supported by evidence" />
            <CoverageState state="weak" label="Weak" desc="Partial evidence exists" />
            <CoverageState state="unknown" label="Unknown" desc="Insufficient information" />
            <CoverageState state="not_supported" label="Not Supported" desc="Evidence contradicts" />
          </div>
          <div className="mt-3 text-xs text-center opacity-70">
            Produces structured legal analysis automatically
          </div>
        </ArchLayer>

        {/* DOWNWARD ARROW */}
        <div className="flex justify-center">
          <div className="w-0.5 h-6 bg-slate-400"></div>
        </div>

        {/* ATTORNEY OUTPUT */}
        <ArchLayer bgColor="#53537a" textColor="#FFFFFF">
          <h3 className="font-bold text-sm mb-3 text-center uppercase tracking-wider">
            Attorney Review & Decision
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs text-center">
            <OutputBox>Structured Legal Analysis</OutputBox>
            <OutputBox>Evidence-Element Mapping</OutputBox>
            <OutputBox>Strategic Recommendations</OutputBox>
          </div>
          <p className="mt-3 text-center text-xs opacity-70">
            Evidence-driven insights • Traceable reasoning • Litigation-ready artifacts
          </p>
        </ArchLayer>

      </div>

      {/* SIDE ANNOTATION */}
      <div className="mt-6 p-4 bg-slate-900 border border-slate-700 rounded text-xs">
        <div className="font-bold mb-2 text-white">Architecture Principles</div>
        <div className="space-y-1 text-slate-300">
          <div>• Biological metaphor: Spine (coordination) → Brain (reasoning) → Lobes (specialization)</div>
          <div>• Every action is traceable, reproducible, and auditable</div>
          <div>• AI agents structured by specialized function, not general-purpose</div>
          <div>• Deterministic programs eliminate hallucination risk</div>
          <div>• Legal doctrine encoded as pattern modules grounded in real law</div>
        </div>
      </div>
    </motion.div>
  );
}

// Component: Architecture Layer
function ArchLayer({ 
  bgColor, 
  textColor, 
  children 
}: { 
  bgColor: string; 
  textColor: string; 
  children: React.ReactNode;
}) {
  return (
    <div 
      className="p-4 rounded shadow-lg"
      style={{ backgroundColor: bgColor, color: textColor }}
    >
      {children}
    </div>
  );
}

// Component: Spine Box
function SpineBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 rounded text-center font-medium" style={{
      backgroundColor: 'rgba(255, 255, 255, 0.15)',
      border: '1px solid rgba(96, 165, 250, 0.5)',
      color: '#FFFFFF'
    }}>
      {children}
    </div>
  );
}

// Component: Brain Lobe
function BrainLobe({ 
  title, 
  color, 
  children 
}: { 
  title: string; 
  color: string; 
  children: React.ReactNode;
}) {
  return (
    <div 
      className="p-3 rounded border-2"
      style={{ borderColor: color, backgroundColor: 'rgba(0, 0, 0, 0.3)' }}
    >
      <div className="font-bold text-sm mb-2 text-center" style={{ color }}>
        {title}
      </div>
      {children}
    </div>
  );
}

// Component: Pattern Box
function PatternBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-purple-900/30 border border-purple-400 rounded text-center font-mono">
      {children}
    </div>
  );
}

// Component: Coverage State
function CoverageState({ 
  state, 
  label, 
  desc 
}: { 
  state: string; 
  label: string; 
  desc: string;
}) {
  const colors = {
    strong: 'border-green-500 bg-green-900/30',
    weak: 'border-yellow-500 bg-yellow-900/30',
    unknown: 'border-gray-500 bg-gray-900/30',
    not_supported: 'border-red-500 bg-red-900/30',
  };

  return (
    <div className={`p-2 rounded border-2 ${colors[state as keyof typeof colors]}`}>
      <div className="font-bold text-center mb-1">{label}</div>
      <div className="text-center opacity-70">{desc}</div>
    </div>
  );
}

// Component: Output Box
function OutputBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="p-2 bg-indigo-900/30 border border-indigo-400 rounded">
      {children}
    </div>
  );
}