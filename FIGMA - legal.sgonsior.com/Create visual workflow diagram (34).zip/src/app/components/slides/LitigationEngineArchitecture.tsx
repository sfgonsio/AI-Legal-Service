import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";

const LIFECYCLE_STAGES = [
  { 
    id: "capture", 
    label: "EVIDENCE CAPTURE", 
    agent: "Intake Agent", 
    program: "Hash & Vault",
    evidenceInteraction: "Creates Evidence Foundation Packets",
    ruleApplied: "Chain of custody initialization"
  },
  { 
    id: "parse", 
    label: "STRUCTURED PARSING", 
    agent: "Processing Agent", 
    program: "Entity Extractor",
    evidenceInteraction: "Parses packets into semantic units",
    ruleApplied: "Lineage preservation enforced"
  },
  { 
    id: "evaluate", 
    label: "RULE EVALUATION", 
    agent: "Evidence Agent", 
    program: "CA Code Overlay",
    evidenceInteraction: "Evaluates facts against Evidence Code",
    ruleApplied: "CEC 350-352, 1400+, Hearsay rules"
  },
  { 
    id: "mapping", 
    label: "ELEMENT MAPPING", 
    agent: "Mapping Agent", 
    program: "Element Matcher",
    evidenceInteraction: "Binds facts to COA elements",
    ruleApplied: "Evidentiary sufficiency scoring"
  },
  { 
    id: "discovery", 
    label: "DISCOVERY GENERATION", 
    agent: "Discovery Agent", 
    program: "Doc Generator",
    evidenceInteraction: "Produces requests/responses with citations",
    ruleApplied: "Citation chain validation"
  },
  { 
    id: "trial", 
    label: "TRIAL PREPARATION", 
    agent: "Trial Agent", 
    program: "Brief Compiler",
    evidenceInteraction: "Generates court filings with audit trail",
    ruleApplied: "Complete traceability to source hash"
  },
];

const FOUNDATION_MODULES = [
  { name: "Evidence Vault", desc: "Hash-locked evidence packets" },
  { name: "Rule Overlay Registry", desc: "CA Evidence Code overlays" },
  { name: "Audit Ledger", desc: "Immutable transformation log" },
  { name: "Entity Registry", desc: "Parties, dates, amounts" },
  { name: "Artifact Registry", desc: "Generated outputs with provenance" },
];

export function LitigationEngineArchitecture() {
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const active = activeStage
    ? LIFECYCLE_STAGES.find((s) => s.id === activeStage) ?? null
    : null;

  return (
    <div className="relative w-full space-y-6 md:space-y-8" style={{ minHeight: "700px" }}>
      {/* Silver rule for engineered feel */}
      <div style={{ height: "1px", backgroundColor: "#C0C5CE", marginBottom: "16px" }} />

      {/* Governance Band */}
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.1 }}
        className="flex items-center justify-center rounded-lg md:rounded-xl py-4 md:py-5 px-4"
        style={{
          minHeight: "70px",
          backgroundColor: "#000033",
        }}
      >
        <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-white text-xs md:text-sm font-medium tracking-wide text-center">
          <span>Evidence Foundation</span>
          <span className="hidden md:inline" style={{ opacity: 0.45 }}>→</span>
          <span>Rule Evaluation</span>
          <span className="hidden md:inline" style={{ opacity: 0.45 }}>→</span>
          <span>Litigation Outputs</span>
          <span className="hidden md:inline" style={{ opacity: 0.45 }}>•</span>
          <span className="font-bold" style={{ opacity: 0.95, letterSpacing: "0.08em" }}>
            AGENTS PROPOSE. PROGRAMS COMMIT.
          </span>
        </div>
      </motion.div>

      {/* Lifecycle Spine - Interactive Stage Selector */}
      <motion.div
        initial={{ opacity: 0, scaleX: 0.92 }}
        animate={{ opacity: 1, scaleX: 1 }}
        transition={{ duration: 0.7, delay: 0.25 }}
        className="relative rounded-lg md:rounded-xl overflow-hidden"
        style={{
          backgroundColor: "#000033",
          border: "1px solid rgba(255,255,255,0.18)",
        }}
      >
        {/* Desktop: Horizontal Layout */}
        <div className="hidden lg:flex items-center justify-between px-6 md:px-10 py-8 md:py-10">
          {LIFECYCLE_STAGES.map((stage, index) => (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.45 + index * 0.06 }}
              className="flex items-center gap-3 cursor-pointer"
              onMouseEnter={() => setActiveStage(stage.id)}
              onMouseLeave={() => setActiveStage(null)}
            >
              {/* Disciplined marker */}
              <div
                style={{
                  width: "10px",
                  height: "10px",
                  borderRadius: "999px",
                  backgroundColor: activeStage === stage.id ? "#FFFFFF" : "rgba(255,255,255,0.28)",
                  transition: "all 140ms ease",
                }}
              />
              <span
                className="font-bold text-sm md:text-lg"
                style={{
                  letterSpacing: "0.10em",
                  color: activeStage === stage.id ? "#FFFFFF" : "rgba(255,255,255,0.88)",
                  transition: "all 140ms ease",
                }}
              >
                {stage.label}
              </span>
            </motion.div>
          ))}
        </div>

        {/* Mobile/Tablet: Vertical Stack */}
        <div className="lg:hidden flex flex-col divide-y" style={{ borderColor: "rgba(255,255,255,0.18)" }}>
          {LIFECYCLE_STAGES.map((stage, index) => (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.45, delay: 0.45 + index * 0.06 }}
              className="flex items-center gap-3 px-6 py-5 cursor-pointer"
              onMouseEnter={() => setActiveStage(stage.id)}
              onMouseLeave={() => setActiveStage(null)}
              style={{
                backgroundColor: activeStage === stage.id ? "rgba(255,255,255,0.08)" : "transparent"
              }}
            >
              <div
                style={{
                  width: "8px",
                  height: "8px",
                  borderRadius: "999px",
                  backgroundColor: activeStage === stage.id ? "#FFFFFF" : "rgba(255,255,255,0.28)",
                }}
              />
              <span
                className="font-bold text-sm"
                style={{
                  letterSpacing: "0.08em",
                  color: activeStage === stage.id ? "#FFFFFF" : "rgba(255,255,255,0.88)",
                }}
              >
                {stage.label}
              </span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Detail Panel - Evidence Interaction */}
      <AnimatePresence mode="wait">
        {active && (
          <motion.div
            key={active.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.28 }}
            className="rounded-lg md:rounded-xl border p-6 md:p-10"
            style={{
              backgroundColor: "#FFFFFF",
              borderColor: "#C0C5CE",
            }}
          >
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
              {/* Agent & Program */}
              <div>
                <h5 className="text-xs md:text-sm font-bold uppercase tracking-wide mb-4" style={{ color: "#718096" }}>
                  Execution Model
                </h5>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: "#000033", opacity: 0.6 }}>
                      Agent (Proposes)
                    </p>
                    <p className="text-sm md:text-base font-semibold" style={{ color: "#000033" }}>
                      {active.agent}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: "#000033", opacity: 0.6 }}>
                      Program (Commits)
                    </p>
                    <p className="text-sm md:text-base font-semibold" style={{ color: "#000033" }}>
                      {active.program}
                    </p>
                  </div>
                </div>
              </div>

              {/* Evidence Interaction */}
              <div>
                <h5 className="text-xs md:text-sm font-bold uppercase tracking-wide mb-4" style={{ color: "#718096" }}>
                  Evidence Interaction
                </h5>
                <p className="text-sm md:text-base" style={{ color: "#4A5568", lineHeight: "1.6" }}>
                  {active.evidenceInteraction}
                </p>
              </div>

              {/* Rule Applied */}
              <div>
                <h5 className="text-xs md:text-sm font-bold uppercase tracking-wide mb-4" style={{ color: "#718096" }}>
                  Rule Applied
                </h5>
                <p className="text-sm md:text-base" style={{ color: "#4A5568", lineHeight: "1.6" }}>
                  {active.ruleApplied}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Foundation Modules */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.6 }}
        className="rounded-lg md:rounded-xl border overflow-hidden"
        style={{
          backgroundColor: "#FFFFFF",
          borderColor: "#C0C5CE",
        }}
      >
        <div className="px-6 md:px-10 py-5 md:py-6" style={{ backgroundColor: "#F4F6F8" }}>
          <h4 className="text-sm md:text-base font-bold uppercase tracking-wide" style={{ color: "#000033" }}>
            Foundation Modules
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 divide-y md:divide-y-0 md:divide-x" style={{ borderColor: "#E2E8F0" }}>
          {FOUNDATION_MODULES.map((module, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.75 + idx * 0.06 }}
              className="px-6 md:px-8 py-6 md:py-8 flex flex-col"
            >
              <div
                className="mb-3 px-3 py-1.5 rounded-md inline-block self-start text-xs font-bold"
                style={{
                  backgroundColor: "#000033",
                  color: "#FFFFFF"
                }}
              >
                {idx + 1}
              </div>
              <p className="text-sm md:text-base font-semibold mb-2" style={{ color: "#000033" }}>
                {module.name}
              </p>
              <p className="text-xs md:text-sm" style={{ color: "#718096", lineHeight: "1.5" }}>
                {module.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Bottom Principle */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.85 }}
        className="text-center rounded-lg md:rounded-xl p-5 md:p-6"
        style={{
          backgroundColor: "#000033"
        }}
      >
        <p className="text-sm md:text-base font-semibold italic" style={{ color: "#FFFFFF", letterSpacing: "0.02em" }}>
          Every stage writes to the audit ledger. Every output traces back to hash-verified evidence.
        </p>
      </motion.div>
    </div>
  );
}
