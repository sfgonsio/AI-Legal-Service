import { motion } from "motion/react";
import { useState } from "react";

interface WorkflowStage {
  stageNumber: number;
  stageName: string;
  description: string;
  keyArtifacts: string[];
  platformComponent: string;
  party: "Both" | "Plaintiff" | "Defendant";
}

const WORKFLOW_STAGES: WorkflowStage[] = [
  {
    stageNumber: 1,
    stageName: "Client Intake",
    description: "Initial case assessment and evidence collection from client narrative and documentation.",
    keyArtifacts: ["Interview Transcript", "Initial Fact List", "Matter Intake Record"],
    platformComponent: "INTERVIEW_AGENT",
    party: "Both"
  },
  {
    stageNumber: 2,
    stageName: "Case Evaluation",
    description: "Legal theory formulation and cause of action analysis based on normalized facts.",
    keyArtifacts: ["Case Theory Draft", "COA Coverage Matrix", "Defense Position Outline"],
    platformComponent: "agent_COA_REASONER",
    party: "Both"
  },
  {
    stageNumber: 3,
    stageName: "Evidence Collection",
    description: "Document ingestion, metadata extraction, and evidence repository construction.",
    keyArtifacts: ["Evidence Repository", "Evidence Metadata", "Hash-Verified Registry"],
    platformComponent: "program_PROCESSING",
    party: "Both"
  },
  {
    stageNumber: 4,
    stageName: "Fact Normalization",
    description: "Extraction of structured facts from evidence with bidirectional source references.",
    keyArtifacts: ["Normalized Facts", "Fact Graph", "Source Citations"],
    platformComponent: "program_FACT_NORMALIZATION",
    party: "Both"
  },
  {
    stageNumber: 5,
    stageName: "Event Mapping",
    description: "Construction of chronological event timeline from normalized facts with attorney validation.",
    keyArtifacts: ["Event Candidates", "Case Timeline", "Event Graph"],
    platformComponent: "program_COMPOSITE_ENGINE",
    party: "Both"
  },
  {
    stageNumber: 6,
    stageName: "Legal Theory Formation",
    description: "Mapping facts to legal elements with evidentiary support analysis and gap identification.",
    keyArtifacts: ["COA Coverage Matrix", "Legal Argument Proposal", "Element Binding Map"],
    platformComponent: "program_COA_ENGINE",
    party: "Plaintiff"
  },
  {
    stageNumber: 7,
    stageName: "Pleading Drafting",
    description: "Generation of court-ready complaints and answers with complete evidentiary citations.",
    keyArtifacts: ["Complaint Draft", "Answer Draft", "Pleading Package"],
    platformComponent: "OPPOSITION_AGENT",
    party: "Both"
  },
  {
    stageNumber: 8,
    stageName: "Discovery",
    description: "Discovery request generation and response correlation with coverage analysis.",
    keyArtifacts: ["Discovery Request Packet", "Discovery Response Map", "Interrogatories"],
    platformComponent: "program_DISCOVERY_PACKET",
    party: "Both"
  },
  {
    stageNumber: 9,
    stageName: "Motion Practice",
    description: "Motion and opposition drafting with legal argument construction and citation chains.",
    keyArtifacts: ["Motion Draft", "Opposition Brief", "Legal Memorandum"],
    platformComponent: "OPPOSITION_AGENT",
    party: "Both"
  },
  {
    stageNumber: 10,
    stageName: "Trial Preparation",
    description: "Exhibit selection, witness outline creation, and burden map construction for trial.",
    keyArtifacts: ["Exhibit List", "Witness Outline", "Trial Prep Guide"],
    platformComponent: "program_BURDEN_MAP_BUILDER",
    party: "Both"
  },
  {
    stageNumber: 11,
    stageName: "Trial Support",
    description: "Real-time evidence alignment and trial evidence index for courtroom use.",
    keyArtifacts: ["Trial Evidence Map", "Evidence Index", "Courtroom Reference"],
    platformComponent: "program_COVERAGE_ANALYSIS",
    party: "Both"
  },
  {
    stageNumber: 12,
    stageName: "Post-Trial",
    description: "Verdict analysis and appeal assessment with outcome evaluation.",
    keyArtifacts: ["Judgment Analysis", "Appeal Assessment", "Outcome Report"],
    platformComponent: "agent_COA_REASONER",
    party: "Both"
  }
];

export function LitigationWorkflowStages() {
  const [selectedStage, setSelectedStage] = useState<number | null>(null);

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center"
      >
        <h3 className="text-base md:text-lg font-bold uppercase tracking-wide mb-3" style={{ color: '#000033' }}>
          12-STAGE LITIGATION WORKFLOW
        </h3>
        <p className="text-sm md:text-base" style={{ color: '#4A5568' }}>
          Complete lifecycle from client intake through post-trial with deterministic artifact production
        </p>
      </motion.div>

      {/* Workflow Grid - 4x3 layout on desktop, 2x6 on tablet, 1x12 on mobile */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {WORKFLOW_STAGES.map((stage, index) => (
          <motion.div
            key={stage.stageNumber}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
            onMouseEnter={() => setSelectedStage(stage.stageNumber)}
            onMouseLeave={() => setSelectedStage(null)}
            className="rounded-lg border-2 p-5 cursor-pointer transition-all duration-200"
            style={{
              backgroundColor: selectedStage === stage.stageNumber ? '#F4F6F8' : '#FFFFFF',
              borderColor: selectedStage === stage.stageNumber ? '#000033' : '#C0C5CE'
            }}
          >
            {/* Stage Number Badge */}
            <div 
              className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
              style={{
                backgroundColor: '#000033',
                color: '#FFFFFF'
              }}
            >
              <span className="text-base font-bold">{stage.stageNumber}</span>
            </div>

            {/* Stage Name */}
            <h4 className="text-sm md:text-base font-bold mb-2" style={{ color: '#000033' }}>
              {stage.stageName}
            </h4>

            {/* Party Indicator */}
            <div className="mb-3">
              <span 
                className="text-xs uppercase tracking-wide px-2 py-1 rounded"
                style={{
                  backgroundColor: stage.party === "Both" ? '#E6F2FF' : '#FFF4E6',
                  color: stage.party === "Both" ? '#003D82' : '#8B5A00'
                }}
              >
                {stage.party}
              </span>
            </div>

            {/* Description */}
            <p className="text-xs md:text-sm mb-3" style={{ color: '#4A5568', lineHeight: '1.5' }}>
              {stage.description}
            </p>

            {/* Platform Component */}
            <div className="pt-3 border-t" style={{ borderColor: '#E2E8F0' }}>
              <p className="text-[10px] uppercase tracking-wide mb-1" style={{ color: '#718096' }}>
                Platform Component
              </p>
              <p className="text-xs font-mono" style={{ color: '#000033' }}>
                {stage.platformComponent}
              </p>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Stage Detail Panel */}
      {selectedStage !== null && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="rounded-lg border p-6"
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#000033',
            borderWidth: '2px'
          }}
        >
          <div className="flex items-start gap-4">
            <div 
              className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{
                backgroundColor: '#000033',
                color: '#FFFFFF'
              }}
            >
              <span className="text-lg font-bold">{selectedStage}</span>
            </div>
            
            <div className="flex-1">
              <h4 className="text-lg font-bold mb-2" style={{ color: '#000033' }}>
                Stage {selectedStage}: {WORKFLOW_STAGES[selectedStage - 1].stageName}
              </h4>
              <p className="text-sm mb-4" style={{ color: '#4A5568' }}>
                {WORKFLOW_STAGES[selectedStage - 1].description}
              </p>

              <div>
                <p className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: '#718096' }}>
                  Key Artifacts Produced
                </p>
                <div className="flex flex-wrap gap-2">
                  {WORKFLOW_STAGES[selectedStage - 1].keyArtifacts.map((artifact, idx) => (
                    <span
                      key={idx}
                      className="text-xs px-3 py-1 rounded-full"
                      style={{
                        backgroundColor: '#E6F2FF',
                        color: '#003D82'
                      }}
                    >
                      {artifact}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Workflow Principles */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="rounded-lg p-6"
        style={{
          backgroundColor: '#FFFFFF',
          borderTop: '3px solid #000033'
        }}
      >
        <h4 className="font-bold text-sm md:text-base uppercase tracking-wide mb-3" style={{ color: '#000033' }}>
          WORKFLOW GOVERNANCE
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm" style={{ color: '#4A5568' }}>
          <div>
            <span className="font-semibold" style={{ color: '#000033' }}>Deterministic Execution:</span> Every stage produces traceable artifacts through repeatable processes.
          </div>
          <div>
            <span className="font-semibold" style={{ color: '#000033' }}>Attorney Validation:</span> Critical artifacts require explicit attorney approval before downstream use.
          </div>
          <div>
            <span className="font-semibold" style={{ color: '#000033' }}>Bidirectional Traceability:</span> All outputs reference source inputs with hash-verified lineage.
          </div>
        </div>
      </motion.div>
    </div>
  );
}
