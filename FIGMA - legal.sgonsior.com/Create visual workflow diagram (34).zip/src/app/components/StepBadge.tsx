export function StepBadge({ n }: { n: number }) {
  // Start with #000033, step lighter by 2-3 shades in the navy family
  const getStepColor = (step: number) => {
    const colors = [
      "#000033", // Step 1: Original dark navy
      "#0A0F4D", // Step 2: +2 shades lighter
      "#141E67", // Step 3: +2 shades lighter
      "#1E2D81", // Step 4: +2 shades lighter
      "#283C9B", // Step 5: +2 shades lighter
    ];
    return colors[(step - 1) % colors.length] || colors[0];
  };

  return (
    <div
      style={{
        width: "28px",
        height: "28px",
        borderRadius: "999px",
        backgroundColor: getStepColor(n),
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#FFFFFF",
        fontSize: "12px",
        fontWeight: 700,
        letterSpacing: "0.08em",
      }}
    >
      {n}
    </div>
  );
}