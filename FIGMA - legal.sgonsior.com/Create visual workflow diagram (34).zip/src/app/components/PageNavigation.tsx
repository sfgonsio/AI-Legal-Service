import { motion } from "motion/react";
import { Link } from "react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";

interface PageNavigationProps {
  prevLink?: string;
  prevLabel?: string;
  nextLink?: string;
  nextLabel?: string;
}

export function PageNavigation({ prevLink, prevLabel, nextLink, nextLabel }: PageNavigationProps) {
  return (
    <div className="flex items-center justify-between pt-12 mt-12 border-t" style={{ borderColor: 'var(--divider)' }}>
      {prevLink && prevLabel ? (
        <Link to={prevLink}>
          <motion.div
            whileHover={{ x: -4 }}
            className="flex items-center gap-2 text-sm"
            style={{ color: 'var(--primary-blue)' }}
          >
            <ArrowLeft size={16} />
            <span>{prevLabel}</span>
          </motion.div>
        </Link>
      ) : (
        <div />
      )}

      {nextLink && nextLabel ? (
        <Link to={nextLink}>
          <motion.div
            whileHover={{ x: 4 }}
            className="flex items-center gap-2 text-sm"
            style={{ color: 'var(--primary-blue)' }}
          >
            <span>{nextLabel}</span>
            <ArrowRight size={16} />
          </motion.div>
        </Link>
      ) : (
        <div />
      )}
    </div>
  );
}
