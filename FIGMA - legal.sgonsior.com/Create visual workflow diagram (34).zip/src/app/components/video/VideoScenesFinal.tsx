import { motion } from "motion/react";

interface SceneProps {
  scene: {
    id: number;
    title: string;
    voiceover: string;
  };
  isPlaying: boolean;
}

// ACT 10 — DEPOSITION PREPARATION (Phase One - witness tree)
export function Act10DepositionPrepScene({ scene, isPlaying }: SceneProps) {
  const witnesses = ["Dawn (Partner)", "Board Member A", "Board Member B"];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(225deg, #001a33, #000033)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative">
          {/* Root objective */}
          <motion.div
            className="mx-auto mb-20"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.6, type: "spring" }}
          >
            <div
              className="px-10 py-5 rounded-xl"
              style={{
                backgroundColor: "#FFFFFF",
                boxShadow: "0 0 40px rgba(255,255,255,0.4)",
              }}
            >
              <p className="text-base font-bold text-center" style={{ color: "#000033" }}>
                Deposition Objective: Control Transfer Timeline
              </p>
            </div>
          </motion.div>

          {/* Witness branches */}
          <div className="flex gap-12 justify-center">
            {witnesses.map((witness, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: -30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 + idx * 0.4 }}
                className="flex flex-col items-center"
              >
                {/* Connection line up */}
                <motion.div
                  className="w-px h-20 mb-4"
                  style={{ backgroundColor: "rgba(255,255,255,0.4)" }}
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  transition={{ delay: 1.4 + idx * 0.4 }}
                />

                {/* Witness node */}
                <div
                  className="px-6 py-4 rounded-lg border-2 mb-6"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.06)",
                    borderColor: "rgba(255,255,255,0.4)",
                  }}
                >
                  <p className="text-sm font-bold whitespace-nowrap" style={{ color: "#FFFFFF" }}>
                    {witness}
                  </p>
                </div>

                {/* Question sequences */}
                <div className="space-y-2.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-36 h-1.5 rounded-full"
                      style={{ backgroundColor: "rgba(74, 222, 128, 0.4)" }}
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ delay: 2 + idx * 0.4 + i * 0.12 }}
                    />
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Phase badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 3.5 }}
            className="absolute -bottom-16 left-1/2 transform -translate-x-1/2 px-6 py-3 rounded-lg"
            style={{
              backgroundColor: "rgba(74, 222, 128, 0.2)",
              border: "2px solid rgba(74, 222, 128, 0.5)",
            }}
          >
            <p className="text-sm font-bold tracking-wide" style={{ color: "#4ADE80" }}>
              PHASE ONE: PREPARATION
            </p>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

// ACT 11 — DEPOSITION EXECUTION (Phase Two - processing pipeline)
export function Act11DepositionExecScene({ scene, isPlaying }: SceneProps) {
  const stages = ["Video/Audio", "Transcript", "Statements", "Elements", "Record"];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(180deg, #001a33, #000033)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center px-16">
        <div className="flex items-center gap-8">
          {stages.map((stage, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -60 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + idx * 0.6 }}
              className="relative"
            >
              <motion.div
                className="w-36 h-36 rounded-xl flex items-center justify-center"
                style={{
                  backgroundColor: idx === stages.length - 1 ? "#4ADE80" : "rgba(255,255,255,0.08)",
                  border: `2px solid ${idx === stages.length - 1 ? "#4ADE80" : "rgba(255,255,255,0.35)"}`,
                }}
                whileHover={{ scale: 1.05 }}
              >
                <p
                  className="text-sm font-bold text-center px-3"
                  style={{ color: idx === stages.length - 1 ? "#000033" : "#FFFFFF" }}
                >
                  {stage}
                </p>
              </motion.div>

              {/* Processing animation */}
              {isPlaying && idx < stages.length - 1 && (
                <motion.div
                  className="absolute right-0 top-1/2 transform translate-x-full -translate-y-1/2 flex gap-1.5 px-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 1, 0] }}
                  transition={{
                    duration: 1.8,
                    repeat: Infinity,
                    delay: 1.5 + idx * 0.6,
                  }}
                >
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div
                      key={i}
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: "#4ADE80" }}
                    />
                  ))}
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Phase badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4 }}
          className="absolute bottom-24 px-6 py-3 rounded-lg"
          style={{
            backgroundColor: "rgba(74, 222, 128, 0.2)",
            border: "2px solid rgba(74, 222, 128, 0.5)",
          }}
        >
          <p className="text-sm font-bold tracking-wide" style={{ color: "#4ADE80" }}>
            PHASE TWO: EXECUTION & PROCESSING
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}

// ACT 12 — TRIAL READINESS (Exhibits with foundation)
export function Act12TrialScene({ scene, isPlaying }: SceneProps) {
  const exhibits = ["Exhibit A", "Exhibit B", "Exhibit C", "Exhibit D"];
  const checks = ["Authenticated", "Foundation Clear", "Hearsay Mapped", "Chain Preserved"];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(135deg, #000033, #001a4d)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-[700px] h-[500px]">
          {/* Stacked exhibits */}
          {exhibits.map((exhibit, idx) => (
            <motion.div
              key={idx}
              className="absolute"
              style={{
                left: 100 + idx * 40,
                top: 50 + idx * 40,
                zIndex: 4 - idx,
              }}
              initial={{ opacity: 0, y: -80, rotateZ: -15 }}
              animate={{ opacity: 1, y: 0, rotateZ: 0 }}
              transition={{ delay: 0.5 + idx * 0.4, type: "spring", stiffness: 100 }}
            >
              <div
                className="w-72 h-96 rounded-xl p-8"
                style={{
                  backgroundColor: "#FFFFFF",
                  boxShadow: "0 20px 50px rgba(0,0,0,0.4)",
                }}
              >
                <p className="text-3xl font-bold mb-8" style={{ color: "#000033" }}>
                  {exhibit}
                </p>

                {/* Foundation checks */}
                <div className="space-y-4">
                  {checks.map((check, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <motion.div
                        className="w-5 h-5 rounded-full flex-shrink-0"
                        style={{ backgroundColor: "#4ADE80" }}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 1.8 + idx * 0.4 + i * 0.25, type: "spring" }}
                      />
                      <span className="text-sm font-semibold" style={{ color: "#4A5568" }}>
                        {check}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Objection dissolving */}
                {idx === 0 && (
                  <motion.div
                    className="mt-8 px-4 py-3 rounded-lg text-center"
                    style={{
                      backgroundColor: "rgba(239, 68, 68, 0.2)",
                      border: "2px solid rgba(239, 68, 68, 0.5)",
                    }}
                    initial={{ opacity: 1 }}
                    animate={{ opacity: 0 }}
                    transition={{ delay: 3.5, duration: 1.2 }}
                  >
                    <p className="text-sm font-bold" style={{ color: "#EF4444" }}>
                      OBJECTION DISSOLVED
                    </p>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

// ACT 13 — KNOWLEDGE EVOLUTION (DIKW transformation)
export function Act13KnowledgeScene({ scene, isPlaying }: SceneProps) {
  const stages = [
    { name: "Data", color: "#60A5FA" },
    { name: "Information", color: "#818CF8" },
    { name: "Knowledge", color: "#A78BFA" },
    { name: "Insight", color: "#C084FC" }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(225deg, #001a33, #000033)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center px-16">
        <div className="flex items-center gap-16">
          {stages.map((stage, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7 + idx * 0.7, type: "spring", stiffness: 100 }}
              className="relative"
            >
              {/* Stage circle */}
              <motion.div
                className="w-40 h-40 rounded-full flex items-center justify-center relative"
                style={{
                  backgroundColor: stage.color,
                  boxShadow: `0 0 50px ${stage.color}90`,
                }}
                animate={{
                  boxShadow: [`0 0 50px ${stage.color}90`, `0 0 70px ${stage.color}`, `0 0 50px ${stage.color}90`]
                }}
                transition={{ duration: 2.5, repeat: Infinity, delay: idx * 0.7 }}
              >
                <p className="text-xl font-bold" style={{ color: "#FFFFFF" }}>
                  {stage.name}
                </p>

                {/* Expanding rings */}
                {isPlaying &&
                  [0, 1].map((i) => (
                    <motion.div
                      key={i}
                      className="absolute inset-0 rounded-full border-2"
                      style={{ borderColor: stage.color }}
                      initial={{ scale: 1, opacity: 0.6 }}
                      animate={{ scale: 2.2, opacity: 0 }}
                      transition={{
                        duration: 2.5,
                        repeat: Infinity,
                        delay: i * 1.25 + idx * 0.7,
                      }}
                    />
                  ))}
              </motion.div>

              {/* Arrow */}
              {idx < stages.length - 1 && (
                <motion.div
                  className="absolute left-full top-1/2 transform -translate-y-1/2 ml-8"
                  initial={{ opacity: 0, x: -15 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.4 + idx * 0.7 }}
                >
                  <div
                    style={{
                      width: 0,
                      height: 0,
                      borderTop: "16px solid transparent",
                      borderBottom: "16px solid transparent",
                      borderLeft: `24px solid ${stage.color}`,
                    }}
                  />
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Governance badge */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4 }}
          className="absolute bottom-20 px-8 py-4 rounded-xl"
          style={{
            backgroundColor: "rgba(255,255,255,0.1)",
            border: "2px solid rgba(255,255,255,0.35)",
          }}
        >
          <p className="text-base font-bold text-center mb-2" style={{ color: "#FFFFFF" }}>
            Structured Programs Govern AI Agents
          </p>
          <p className="text-sm text-center" style={{ color: "rgba(255,255,255,0.7)" }}>
            Configuration Boundaries Prevent Drift
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}

// FINAL FRAME (Closing message)
export function FinalScene({ scene, isPlaying }: SceneProps) {
  const principles = [
    "Preparation is Structured",
    "Admissibility is Visible",
    "Discovery is Intentional",
    "Deposition is Disciplined",
    "Trial Readiness is Traceable"
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 flex flex-col items-center justify-center"
      style={{
        background: "radial-gradient(ellipse at center, #001a4d, #000033)",
      }}
    >
      {/* Dashboard grid (subtle background) */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.15 }}
        transition={{ delay: 0.5 }}
        className="absolute inset-16 rounded-xl border grid grid-cols-3 gap-5 p-10"
        style={{
          borderColor: "rgba(255,255,255,0.2)",
          backgroundColor: "rgba(255,255,255,0.02)",
        }}
      >
        {Array.from({ length: 9 }).map((_, idx) => (
          <motion.div
            key={idx}
            className="rounded-lg border"
            style={{
              borderColor: "rgba(255,255,255,0.2)",
              backgroundColor: "rgba(255,255,255,0.03)",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 + idx * 0.1 }}
          />
        ))}
      </motion.div>

      {/* Main content */}
      <div className="relative z-10 text-center max-w-5xl space-y-10 px-12">
        <motion.h1
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, delay: 1.5 }}
          className="text-6xl font-bold leading-tight"
          style={{ color: "#FFFFFF" }}
        >
          Evidence-Centered<br />Litigation Architecture
        </motion.h1>

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "220px" }}
          transition={{ delay: 2.2, duration: 0.9 }}
          className="mx-auto"
          style={{ height: "3px", backgroundColor: "#FFFFFF" }}
        />

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.8 }}
          className="text-2xl font-semibold"
          style={{ color: "rgba(255,255,255,0.9)" }}
        >
          Engineered for Adversarial Environments
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 3.4 }}
          className="mt-12 space-y-3"
        >
          {principles.map((principle, idx) => (
            <motion.p
              key={idx}
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 3.8 + idx * 0.25 }}
              className="text-lg font-medium"
              style={{ color: "rgba(255,255,255,0.85)" }}
            >
              {principle}
            </motion.p>
          ))}
        </motion.div>

        <motion.p
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 5.5, type: "spring" }}
          className="text-2xl font-bold italic mt-12"
          style={{ color: "#FFFFFF" }}
        >
          Structure does not replace judgment.<br />
          It strengthens it.
        </motion.p>
      </div>

      {/* Floating particles */}
      {isPlaying &&
        Array.from({ length: 40 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full"
            style={{
              backgroundColor: "rgba(255,255,255,0.4)",
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -40, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3.5 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
          />
        ))}
    </motion.div>
  );
}
