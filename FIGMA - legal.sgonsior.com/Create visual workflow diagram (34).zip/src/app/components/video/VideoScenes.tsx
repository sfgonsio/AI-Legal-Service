import { motion, AnimatePresence } from "motion/react";
import { useState, useEffect, useRef } from "react";
import { ACT2_DIALOGUE, ACT3_DIALOGUE, DialogueLine, VOICE_CONFIG, getVoiceForSpeaker } from "./DialogueScripts";

interface SceneProps {
  scene: {
    id: number;
    title: string;
    voiceover: string;
  };
  isPlaying: boolean;
  volume?: number;
  isMuted?: boolean;
}

// TITLE SCENE - Clean title card
export function TitleScene({ scene, isPlaying }: SceneProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 flex flex-col items-center justify-center"
      style={{ background: "radial-gradient(ellipse at center, #000044, #000033)" }}
    >
      {/* Animated grid background */}
      <div className="absolute inset-0 opacity-10">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-px"
            style={{
              left: 0,
              right: 0,
              top: `${i * 5}%`,
              backgroundColor: "#FFFFFF",
            }}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: isPlaying ? 1 : 0 }}
            transition={{ delay: i * 0.1, duration: 1 }}
          />
        ))}
      </div>

      <motion.h1
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, delay: 0.3 }}
        className="text-5xl md:text-7xl font-bold text-center mb-6 tracking-wide px-12"
        style={{ color: "#FFFFFF" }}
      >
        Engineering Litigation<br />Structure
      </motion.h1>

      <motion.div
        initial={{ width: 0 }}
        animate={{ width: "180px" }}
        transition={{ delay: 1.2, duration: 0.6 }}
        style={{ height: "3px", backgroundColor: "#FFFFFF", marginBottom: "48px" }}
      />

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8 }}
        className="text-xl md:text-2xl"
        style={{ color: "rgba(255,255,255,0.8)" }}
      >
        Evidence-Centered Legal Infrastructure
      </motion.p>
    </motion.div>
  );
}

// ACT 1 — THE CLIENT (Jenny's story told through visuals)
export function Act1ClientScene({ scene, isPlaying }: SceneProps) {
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (!isPlaying) {
      if (utteranceRef.current) {
        window.speechSynthesis.cancel();
        utteranceRef.current = null;
      }
      return;
    }

    // Wait for voices to load
    const startVoiceover = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length === 0) {
        setTimeout(startVoiceover, 100);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(scene.voiceover);
      utterance.rate = 0.85;
      utterance.pitch = 1;
      utterance.volume = 0.8;
      utteranceRef.current = utterance;

      window.speechSynthesis.speak(utterance);
    };

    startVoiceover();

    return () => {
      if (utteranceRef.current) {
        window.speechSynthesis.cancel();
        utteranceRef.current = null;
      }
    };
  }, [isPlaying, scene.voiceover]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(135deg, #001a33, #000033)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center" style={{ top: "-80px" }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 1.5 }}
          className="relative w-64 h-64"
        >
          <div
            className="w-full h-full rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(255,255,255,0.15), transparent)",
            }}
          />
          
          {/* Documents */}
          {[
            { name: "Operating Agreement", angle: 0, delay: 6 },
            { name: "Board Minutes", angle: 120, delay: 10 },
            { name: "Cap Table", angle: 240, delay: 13 }
          ].map((doc, idx) => {
            const radius = 260;
            const angleRad = (doc.angle * Math.PI) / 180;
            const x = Math.cos(angleRad) * radius;
            const y = Math.sin(angleRad) * radius;
            
            return (
              <motion.div
                key={idx}
                className="absolute px-5 py-3 rounded-lg border-2 text-sm font-bold whitespace-nowrap"
                style={{
                  backgroundColor: "rgba(255,255,255,0.1)",
                  borderColor: "rgba(255,255,255,0.4)",
                  color: "#FFFFFF",
                  left: `calc(50% + ${x}px)`,
                  top: `calc(50% + ${y}px)`,
                  transform: "translate(-50%, -50%)",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
                }}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: doc.delay, type: "spring", stiffness: 80 }}
              >
                {doc.name}
              </motion.div>
            );
          })}
        </motion.div>

        {/* Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 20 }}
          className="absolute text-center"
          style={{ bottom: "200px" }}
        >
          <p className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.6)" }}>
            Real Estate Development • Partnership • Control Shift
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}

// ACT 2 — STRUCTURED INTERVIEW (Interview Agent activation)
export function Act2InterviewScene({ scene, isPlaying }: SceneProps) {
  const [currentLineIndex, setCurrentLineIndex] = useState(-1);
  const [activeDialogue, setActiveDialogue] = useState<DialogueLine | null>(null);
  const timeoutsRef = useRef<NodeJS.Timeout[]>([]);
  const utterancesRef = useRef<SpeechSynthesisUtterance[]>([]);

  useEffect(() => {
    // Cleanup function
    const cleanup = () => {
      timeoutsRef.current.forEach(timeout => clearTimeout(timeout));
      timeoutsRef.current = [];
      window.speechSynthesis.cancel();
      utterancesRef.current = [];
      setCurrentLineIndex(-1);
      setActiveDialogue(null);
    };

    if (!isPlaying) {
      cleanup();
      return;
    }

    // Wait for voices to load
    const startDialogue = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length === 0) {
        const timeout = setTimeout(startDialogue, 100);
        timeoutsRef.current.push(timeout);
        return;
      }

      // Schedule all dialogue lines
      ACT2_DIALOGUE.forEach((line, index) => {
        const timeout = setTimeout(() => {
          setCurrentLineIndex(index);
          setActiveDialogue(line);

          // Create and speak utterance
          const utterance = new SpeechSynthesisUtterance(line.text);
          const config = VOICE_CONFIG[line.speaker];
          const voice = getVoiceForSpeaker(line.speaker);

          if (voice) utterance.voice = voice;
          utterance.rate = config.rate;
          utterance.pitch = config.pitch;
          utterance.volume = config.volume;

          utterancesRef.current.push(utterance);
          window.speechSynthesis.speak(utterance);
        }, line.delay);

        timeoutsRef.current.push(timeout);
      });
    };

    startDialogue();

    return cleanup;
  }, [isPlaying]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(180deg, #000033, #001a33)" }}
    >
      {/* Main content area - positioned to avoid control bar */}
      <div className="absolute inset-0" style={{ paddingBottom: "200px", paddingTop: "80px" }}>
        <div className="w-full h-full flex items-center justify-center gap-32 px-16">
          {/* Jenny (left side) */}
          <div className="relative flex flex-col items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="w-28 h-36 rounded-lg"
              style={{ 
                backgroundColor: activeDialogue?.speaker === 'jenny' ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.12)",
                border: activeDialogue?.speaker === 'jenny' ? "2px solid rgba(200,200,255,0.5)" : "1px solid rgba(255,255,255,0.2)",
              }}
            />
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="mt-4 px-4 py-2 rounded text-xs font-bold"
              style={{
                backgroundColor: "rgba(255,255,255,0.1)",
                border: "1px solid rgba(255,255,255,0.3)",
                color: "#FFFFFF",
              }}
            >
              Jenny
            </motion.div>
          </div>

          {/* Interview Agent (right side) */}
          <div className="relative flex flex-col items-center">
            {/* Reference badge - positioned above */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 3 }}
              className="mb-6 px-4 py-2 rounded text-xs text-center whitespace-nowrap"
              style={{
                backgroundColor: "rgba(255,255,255,0.1)",
                border: "1px solid rgba(255,255,255,0.3)",
                color: "#FFFFFF",
              }}
            >
              CA Evidence Code • CACI
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1 }}
            >
              <motion.div
                className="w-44 h-44 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: "#FFFFFF",
                  boxShadow: activeDialogue?.speaker === 'agent' 
                    ? "0 0 80px rgba(255,255,255,0.7)" 
                    : "0 0 60px rgba(255,255,255,0.4)",
                }}
                animate={{ 
                  boxShadow: activeDialogue?.speaker === 'agent' 
                    ? ["0 0 80px rgba(255,255,255,0.7)", "0 0 100px rgba(255,255,255,0.9)", "0 0 80px rgba(255,255,255,0.7)"]
                    : ["0 0 60px rgba(255,255,255,0.4)", "0 0 80px rgba(255,255,255,0.6)", "0 0 60px rgba(255,255,255,0.4)"]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <p className="text-sm font-bold text-center leading-tight" style={{ color: "#000033" }}>
                  INTERVIEW<br />AGENT
                </p>
              </motion.div>
            </motion.div>

            {/* Captured data points */}
            <motion.div
              className="mt-8 flex gap-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 12 }}
            >
              {["Declarant", "Time", "Context", "Fact"].map((label, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: -10, scale: 0 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ delay: 12 + idx * 0.2, type: "spring" }}
                  className="px-3 py-1.5 rounded text-xs font-semibold"
                  style={{
                    backgroundColor: "rgba(74, 222, 128, 0.2)",
                    border: "1px solid rgba(74, 222, 128, 0.4)",
                    color: "#4ADE80",
                  }}
                >
                  {label}
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>

      {/* Speech Bubble - Positioned above control bar with proper z-index */}
      <AnimatePresence mode="wait">
        {activeDialogue && (
          <motion.div
            key={currentLineIndex}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="absolute left-1/2 transform -translate-x-1/2"
            style={{
              bottom: "240px",
              maxWidth: "800px",
              width: "90%",
              zIndex: 30,
            }}
          >
            <div
              className="px-8 py-6 rounded-xl"
              style={{
                backgroundColor: activeDialogue.speaker === 'jenny' 
                  ? "rgba(200, 200, 255, 0.15)" 
                  : "rgba(74, 222, 128, 0.15)",
                border: `2px solid ${activeDialogue.speaker === 'jenny' ? 'rgba(200, 200, 255, 0.4)' : 'rgba(74, 222, 128, 0.4)'}`,
                backdropFilter: "blur(8px)",
              }}
            >
              <p className="text-xs font-bold uppercase tracking-wide mb-3" 
                 style={{ color: activeDialogue.speaker === 'jenny' ? '#C8C8FF' : '#4ADE80' }}>
                {activeDialogue.speaker === 'jenny' ? 'Jenny' : 'Interview Agent'}
              </p>
              <p className="text-base leading-relaxed" style={{ color: "#FFFFFF" }}>
                {activeDialogue.text}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ACT 3 — CASE VALIDATION (Timeline review)
export function Act3ValidationScene({ scene, isPlaying }: SceneProps) {
  const [currentLineIndex, setCurrentLineIndex] = useState(-1);
  const [activeDialogue, setActiveDialogue] = useState<DialogueLine | null>(null);
  const timeoutsRef = useRef<NodeJS.Timeout[]>([]);
  const utterancesRef = useRef<SpeechSynthesisUtterance[]>([]);

  useEffect(() => {
    // Cleanup function
    const cleanup = () => {
      timeoutsRef.current.forEach(timeout => clearTimeout(timeout));
      timeoutsRef.current = [];
      window.speechSynthesis.cancel();
      utterancesRef.current = [];
      setCurrentLineIndex(-1);
      setActiveDialogue(null);
    };

    if (!isPlaying) {
      cleanup();
      return;
    }

    // Wait for voices to load
    const startDialogue = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length === 0) {
        const timeout = setTimeout(startDialogue, 100);
        timeoutsRef.current.push(timeout);
        return;
      }

      // Schedule all dialogue lines
      ACT3_DIALOGUE.forEach((line, index) => {
        const timeout = setTimeout(() => {
          setCurrentLineIndex(index);
          setActiveDialogue(line);

          // Create and speak utterance
          const utterance = new SpeechSynthesisUtterance(line.text);
          const config = VOICE_CONFIG[line.speaker];
          const voice = getVoiceForSpeaker(line.speaker);

          if (voice) utterance.voice = voice;
          utterance.rate = config.rate;
          utterance.pitch = config.pitch;
          utterance.volume = config.volume;

          utterancesRef.current.push(utterance);
          window.speechSynthesis.speak(utterance);
        }, line.delay);

        timeoutsRef.current.push(timeout);
      });
    };

    startDialogue();

    return cleanup;
  }, [isPlaying]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ 
        background: "linear-gradient(225deg, #001a33, #000033)",
        paddingBottom: "140px"
      }}
    >
      <div className="absolute inset-0 flex items-center justify-center px-16" style={{ paddingBottom: "140px" }}>
        <div className="relative w-full max-w-5xl">
          {/* Timeline line */}
          <motion.div
            className="h-1 rounded-full relative"
            style={{ backgroundColor: "rgba(255,255,255,0.2)" }}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.5, duration: 1.5 }}
          >
            {/* Events on timeline */}
            {[
              { label: "Jan 2020: 70-30", position: "10%", delay: 5 },
              { label: "Mar 2021: 55%", position: "40%", delay: 11 },
              { label: "Sep 2022: 45%", position: "70%", delay: 17 },
              { label: "Present", position: "95%", delay: 23 }
            ].map((event, idx) => (
              <motion.div
                key={idx}
                className="absolute top-1/2 transform -translate-y-1/2"
                style={{ left: event.position }}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: event.delay, type: "spring", stiffness: 100 }}
              >
                <div
                  className="w-5 h-5 rounded-full -translate-x-1/2"
                  style={{
                    backgroundColor: idx === 2 ? "#FFA500" : "#FFFFFF",
                    boxShadow: idx === 2 ? "0 0 20px rgba(255, 165, 0, 0.8)" : "0 0 16px rgba(255,255,255,0.6)",
                  }}
                />
                <div
                  className="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap px-3 py-1.5 rounded text-xs font-semibold"
                  style={{
                    backgroundColor: idx === 2 ? "rgba(255, 165, 0, 0.2)" : "rgba(255,255,255,0.1)",
                    border: idx === 2 ? "1px solid rgba(255, 165, 0, 0.5)" : "1px solid rgba(255,255,255,0.3)",
                    color: idx === 2 ? "#FFA500" : "#FFFFFF",
                  }}
                >
                  {event.label}
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Validation badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 25 }}
            className="absolute -bottom-20 right-0 flex gap-3"
          >
            {["Reviewed", "Confirmed", "Traceable"].map((status, idx) => (
              <motion.div
                key={idx}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 25 + idx * 0.2, type: "spring" }}
                className="px-4 py-2 rounded text-xs font-bold"
                style={{
                  backgroundColor: "rgba(74, 222, 128, 0.2)",
                  border: "1px solid rgba(74, 222, 128, 0.4)",
                  color: "#4ADE80",
                }}
              >
                {status}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Speech Bubble - SAFE ZONE POSITIONING */}
      <AnimatePresence mode="wait">
        {activeDialogue && (
          <motion.div
            key={currentLineIndex}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="absolute left-1/2 transform -translate-x-1/2 max-w-3xl px-8 py-5 rounded-xl"
            style={{ 
              bottom: "170px",
              backgroundColor: activeDialogue.speaker === 'jenny' 
                ? "rgba(200, 200, 255, 0.15)" 
                : "rgba(74, 222, 128, 0.15)",
              border: `2px solid ${activeDialogue.speaker === 'jenny' ? 'rgba(200, 200, 255, 0.4)' : 'rgba(74, 222, 128, 0.4)'}`,
              backdropFilter: "blur(8px)",
            }}
          >
            <p className="text-xs font-bold uppercase tracking-wide mb-2" 
               style={{ color: activeDialogue.speaker === 'jenny' ? '#C8C8FF' : '#4ADE80' }}>
              {activeDialogue.speaker === 'jenny' ? 'Jenny' : 'Interview Agent'}
            </p>
            <p className="text-base leading-relaxed" style={{ color: "#FFFFFF" }}>
              {activeDialogue.text}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ACT 4 — EVIDENCE INTAKE & PRESERVATION (SHA-256 hashing)
export function Act4EvidenceScene({ scene, isPlaying }: SceneProps) {
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (!isPlaying) {
      if (utteranceRef.current) {
        window.speechSynthesis.cancel();
        utteranceRef.current = null;
      }
      return;
    }

    const startVoiceover = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length === 0) {
        setTimeout(startVoiceover, 100);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(scene.voiceover);
      utterance.rate = 0.85;
      utterance.pitch = 1;
      utterance.volume = 0.8;
      utteranceRef.current = utterance;

      window.speechSynthesis.speak(utterance);
    };

    startVoiceover();

    return () => {
      if (utteranceRef.current) {
        window.speechSynthesis.cancel();
        utteranceRef.current = null;
      }
    };
  }, [isPlaying, scene.voiceover]);

  const files = [
    "Operating Agreement.pdf",
    "Board Minutes 2023.pdf",
    "Email Thread.eml",
    "Text Messages.txt",
    "Cap Table v3.xlsx"
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(135deg, #001a4d, #000033)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center gap-20 px-16">
        {/* Files uploading */}
        <div className="space-y-5">
          {files.map((file, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + idx * 0.5, duration: 0.6 }}
              className="relative px-6 py-4 rounded-lg border-2 flex items-center justify-between min-w-[360px]"
              style={{
                backgroundColor: "rgba(255,255,255,0.05)",
                borderColor: "rgba(255,255,255,0.25)",
              }}
            >
              <span className="text-sm font-medium" style={{ color: "#FFFFFF" }}>
                {file}
              </span>

              {/* Hash badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.5 + idx * 0.5 }}
                className="flex items-center gap-2 ml-4"
              >
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: "#4ADE80" }} />
                <span className="text-xs font-mono font-bold" style={{ color: "#4ADE80" }}>
                  SHA-256
                </span>
              </motion.div>

              {/* Hash particles animation */}
              {isPlaying && (
                <motion.div
                  className="absolute right-0 top-1/2 transform translate-x-full -translate-y-1/2 px-4"
                  animate={{ opacity: [0, 1, 0], x: [0, 30, 60] }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: 2 + idx * 0.5,
                  }}
                >
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-1.5 h-1.5 rounded-full"
                        style={{ backgroundColor: "#4ADE80" }}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Foundation Packet badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 3.5, type: "spring" }}
          className="px-10 py-8 rounded-xl text-center"
          style={{
            backgroundColor: "#FFFFFF",
            boxShadow: "0 0 50px rgba(255,255,255,0.4)",
          }}
        >
          <p className="text-lg font-bold uppercase tracking-wide mb-2" style={{ color: "#000033" }}>
            Evidence
          </p>
          <p className="text-lg font-bold uppercase tracking-wide mb-4" style={{ color: "#000033" }}>
            Foundation Packet
          </p>
          <div className="pt-4 border-t" style={{ borderColor: "rgba(0,0,51,0.2)" }}>
            <p className="text-xs font-semibold" style={{ color: "#4A5568" }}>
              Hashed • Immutable • Traceable
            </p>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
