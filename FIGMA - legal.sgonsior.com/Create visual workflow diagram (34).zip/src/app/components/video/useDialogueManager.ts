import { useEffect, useRef, useState } from "react";
import { DialogueLine, VOICE_CONFIG, getVoiceForSpeaker } from "./DialogueScripts";

interface DialogueManagerProps {
  dialogue: DialogueLine[];
  isPlaying: boolean;
  isMuted: boolean;
  volume: number;
  onLineChange: (lineIndex: number) => void;
}

export function useDialogueManager({ 
  dialogue, 
  isPlaying, 
  isMuted, 
  volume,
  onLineChange 
}: DialogueManagerProps) {
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const timerRefs = useRef<NodeJS.Timeout[]>([]);

  useEffect(() => {
    if (!isPlaying || isMuted || dialogue.length === 0) {
      // Clear all timers
      timerRefs.current.forEach(timer => clearTimeout(timer));
      timerRefs.current = [];
      window.speechSynthesis.cancel();
      return;
    }

    // Load voices if not already loaded
    let voicesLoaded = false;
    const loadVoices = () => {
      if (!voicesLoaded && window.speechSynthesis.getVoices().length > 0) {
        voicesLoaded = true;
        playDialogue();
      }
    };

    // Some browsers require this event
    if (window.speechSynthesis.getVoices().length > 0) {
      loadVoices();
    } else {
      window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    }

    function playDialogue() {
      dialogue.forEach((line, index) => {
        const timer = setTimeout(() => {
          if (!isPlaying) return;

          setCurrentLineIndex(index);
          onLineChange(index);

          // Create utterance for this line
          const utterance = new SpeechSynthesisUtterance(line.text);
          const config = VOICE_CONFIG[line.speaker];
          const voice = getVoiceForSpeaker(line.speaker);

          if (voice) {
            utterance.voice = voice;
          }

          utterance.rate = config.rate;
          utterance.pitch = config.pitch;
          utterance.volume = volume;

          window.speechSynthesis.speak(utterance);
        }, line.delay);

        timerRefs.current.push(timer);
      });
    }

    return () => {
      // Cleanup
      timerRefs.current.forEach(timer => clearTimeout(timer));
      timerRefs.current = [];
      window.speechSynthesis.cancel();
      window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
    };
  }, [dialogue, isPlaying, isMuted, volume, onLineChange]);

  return currentLineIndex;
}
