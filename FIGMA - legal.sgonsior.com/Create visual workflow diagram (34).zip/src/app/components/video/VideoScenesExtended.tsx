import { motion } from "motion/react";

interface SceneProps {
  scene: {
    id: number;
    title: string;
    voiceover: string;
  };
  isPlaying: boolean;
}

// ACT 5 — STRUCTURED EVALUATION (5 gates with deterministic programs)
export function Act5EvaluationScene({ scene, isPlaying }: SceneProps) {
  const gates = [
    "Authentication",
    "Hearsay Analysis",
    "Privilege Review",
    "Relevance & 352",
    "Expert Foundation"
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ 
        background: "linear-gradient(180deg, #001a33, #000033)",
      }}
    >
      {/* FIXED CONTAINER WITH PROPER BOUNDS - NO OVERFLOW */}
      <div 
        className="absolute left-0 right-0 flex flex-col items-center justify-center"
        style={{ 
          top: "80px",      // Start below title
          bottom: "160px",  // END WELL ABOVE TIMELINE (140px safe zone + 20px buffer)
          overflow: "hidden" // Prevent any overflow
        }}
      >
        <div className="flex flex-col items-center justify-center gap-4 w-full max-w-xl">
          {gates.map((gate, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -120 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + idx * 0.6, duration: 0.7 }}
              className="w-full"
            >
              {/* Gate checkpoint - COMPACT */}
              <div
                className="px-6 py-3 rounded-lg border-2 flex items-center justify-between w-full"
                style={{
                  backgroundColor: "rgba(255,255,255,0.06)",
                  borderColor: "#FFFFFF",
                }}
              >
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                  style={{ backgroundColor: "#FFFFFF", color: "#000033" }}
                >
                  {idx + 1}
                </div>

                <p className="text-sm font-bold uppercase tracking-wider flex-1 text-center" style={{ color: "#FFFFFF" }}>
                  {gate}
                </p>

                <motion.div
                  className="w-3.5 h-3.5 rounded-full flex-shrink-0"
                  style={{ backgroundColor: "#4ADE80" }}
                  initial={{ scale: 0 }}
                  animate={{ scale: [0, 1.3, 1] }}
                  transition={{ delay: 1.8 + idx * 0.6 }}
                />
              </div>

              {/* Arrow down - SMALLER */}
              {idx < gates.length - 1 && (
                <motion.div
                  className="flex justify-center py-1.5"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.2 + idx * 0.6 }}
                >
                  <div
                    style={{
                      width: 0,
                      height: 0,
                      borderLeft: "8px solid transparent",
                      borderRight: "8px solid transparent",
                      borderTop: "10px solid #FFFFFF",
                    }}
                  />
                </motion.div>
              )}
            </motion.div>
          ))}

          {/* Deterministic badge - COMPACT, POSITIONED WITHIN BOUNDS */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 4.5 }}
            className="mt-4 px-5 py-2 rounded-lg text-center"
            style={{
              backgroundColor: "rgba(74, 222, 128, 0.2)",
              border: "1px solid rgba(74, 222, 128, 0.4)",
            }}
          >
            <p className="text-xs font-bold" style={{ color: "#4ADE80" }}>
              Deterministic • Versioned • Auditable
            </p>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

// ACT 6 — LEGAL ELEMENT MAPPING (COA mapping)
export function Act6MappingScene({ scene, isPlaying }: SceneProps) {
  const elements = [
    { name: "Breach of Fiduciary Duty", count: 7 },
    { name: "Constructive Fraud", count: 5 },
    { name: "Conversion", count: 4 },
    { name: "Contract Breach", count: 6 }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(135deg, #000033, #001a4d)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center px-12">
        <div className="grid grid-cols-2 gap-8">
          {elements.map((element, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 + idx * 0.5, type: "spring", stiffness: 100 }}
            >
              <div
                className="px-8 py-8 rounded-xl border-2 text-center relative min-h-[180px] flex flex-col justify-center"
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(255,255,255,0.3)",
                }}
              >
                <p className="text-base font-bold uppercase tracking-wide mb-6" style={{ color: "#FFFFFF" }}>
                  {element.name}
                </p>

                {/* Evidence dots */}
                <div className="flex items-center justify-center gap-2 mb-4">
                  {Array.from({ length: element.count }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: "#4ADE80" }}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 1.8 + idx * 0.5 + i * 0.08 }}
                    />
                  ))}
                </div>

                <p className="text-xs font-mono font-semibold" style={{ color: "#4ADE80" }}>
                  {element.count} EVIDENCE MAPPED
                </p>

                {/* Bottom accent line */}
                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-1"
                  style={{ backgroundColor: "#4ADE80" }}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: 2.2 + idx * 0.5 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

// ACT 7 — PATTERN RECOGNITION (Timeline anomalies)
export function Act7PatternScene({ scene, isPlaying }: SceneProps) {
  // AUDIO-DRIVEN TIMING:
  // Voiceover: "The platform identifies patterns across the record. 
  //             Ownership transfers preceding formal votes. (4s)
  //             Communication clusters before governance changes. (8s)
  //             Inconsistent timestamps. (12s)
  //             Narrative contradictions. (14s)
  //             Patterns that would be difficult to detect manually..."
  const patterns = [
    { label: "Ownership Transfer", angle: 0, delay: 4.0 },      // Synced to voiceover
    { label: "Communication Clusters", angle: 90, delay: 8.0 }, // Synced to voiceover
    { label: "Timestamp Gap", angle: 180, delay: 12.0 },       // Synced to voiceover
    { label: "Narrative Contradiction", angle: 270, delay: 14.0 } // Synced to voiceover
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ 
        background: "linear-gradient(225deg, #001a33, #000033)",
        paddingBottom: "140px" // SAFE ZONE
      }}
    >
      <div className="absolute inset-0 flex items-center justify-center" style={{ paddingBottom: "140px" }}>
        <div className="relative w-[500px] h-[500px]">
          {/* Central detection node */}
          <motion.div
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.6, type: "spring", stiffness: 120 }}
          >
            <motion.div
              className="w-32 h-32 rounded-xl flex items-center justify-center relative"
              style={{
                backgroundColor: "#FFFFFF",
                boxShadow: "0 0 40px rgba(255,255,255,0.5)",
              }}
              animate={{
                boxShadow: ["0 0 40px rgba(255,255,255,0.5)", "0 0 60px rgba(255,255,255,0.7)", "0 0 40px rgba(255,255,255,0.5)"]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <p className="text-sm font-bold text-center" style={{ color: "#000033" }}>
                PATTERN<br />DETECTION
              </p>
            </motion.div>
          </motion.div>

          {/* Surrounding anomalies - SYNCED TO AUDIO */}
          {patterns.map((item, idx) => {
            const radius = 200;
            const angleRad = (item.angle * Math.PI) / 180;
            const x = Math.cos(angleRad) * radius;
            const y = Math.sin(angleRad) * radius;

            return (
              <motion.div
                key={idx}
                className="absolute"
                style={{
                  left: `calc(50% + ${x}px)`,
                  top: `calc(50% + ${y}px)`,
                  transform: "translate(-50%, -50%)",
                }}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: item.delay, type: "spring", stiffness: 100 }}
              >
                <motion.div
                  className="px-5 py-3 rounded-lg text-xs font-bold text-center whitespace-nowrap"
                  style={{
                    backgroundColor: "rgba(255, 165, 0, 0.25)",
                    border: "2px solid rgba(255, 165, 0, 0.7)",
                    color: "#FFA500",
                  }}
                  animate={{
                    borderColor: ["rgba(255, 165, 0, 0.7)", "rgba(255, 165, 0, 1)", "rgba(255, 165, 0, 0.7)"]
                  }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: idx * 0.3 }}
                >
                  {item.label}
                </motion.div>

                {/* Connection line */}
                <svg
                  className="absolute pointer-events-none"
                  style={{
                    left: "50%",
                    top: "50%",
                    width: Math.abs(x) * 1.2,
                    height: Math.abs(y) * 1.2,
                    transform: `translate(${x > 0 ? '-100%' : '0%'}, ${y > 0 ? '-100%' : '0%'})`,
                  }}
                >
                  <motion.line
                    x1="50%"
                    y1="50%"
                    x2={x < 0 ? "100%" : "0%"}
                    y2={y < 0 ? "100%" : "0%"}
                    stroke="rgba(255, 165, 0, 0.5)"
                    strokeWidth="2"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ delay: item.delay + 0.3, duration: 0.6 }}
                  />
                </svg>
              </motion.div>
            );
          })}
        </div>

        {/* Attorney review badge - appears at "The attorney reviews" */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 18.0 }} // Synced to "The attorney reviews" in voiceover
          className="absolute px-6 py-3 rounded-lg"
          style={{
            bottom: "180px", // SAFE ZONE
            backgroundColor: "rgba(255,255,255,0.1)",
            border: "1px solid rgba(255,255,255,0.3)",
          }}
        >
          <p className="text-sm font-semibold" style={{ color: "#FFFFFF" }}>
            Attorney Reviews • Judgment Remains Human
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}

// ACT 8 — COMPLAINT CONSTRUCTION (Backward traceability)
export function Act8ComplaintScene({ scene, isPlaying }: SceneProps) {
  const chain = ["Argument", "Element", "Fact", "Statement", "Original File"];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(180deg, #000033, #001a33)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center px-16">
        <div className="flex items-center gap-10">
          {chain.map((level, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + idx * 0.6 }}
              className="relative flex flex-col items-center"
            >
              <div
                className="w-28 h-28 rounded-xl flex items-center justify-center relative"
                style={{
                  backgroundColor: idx === chain.length - 1 ? "#4ADE80" : "rgba(255,255,255,0.08)",
                  border: `2px solid ${idx === chain.length - 1 ? "#4ADE80" : "rgba(255,255,255,0.3)"}`,
                }}
              >
                <p
                  className="text-xs font-bold text-center px-2"
                  style={{ color: idx === chain.length - 1 ? "#000033" : "#FFFFFF" }}
                >
                  {level}
                </p>
              </div>

              {/* Arrow to next */}
              {idx < chain.length - 1 && (
                <motion.div
                  className="absolute left-full top-1/2 transform -translate-y-1/2 ml-2"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.2 + idx * 0.6 }}
                >
                  <div
                    style={{
                      width: 0,
                      height: 0,
                      borderTop: "10px solid transparent",
                      borderBottom: "10px solid transparent",
                      borderLeft: "16px solid rgba(255,255,255,0.5)",
                    }}
                  />
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Traceability badge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 4 }}
          className="absolute bottom-24 text-center"
        >
          <p className="text-sm font-bold tracking-wide" style={{ color: "#FFFFFF" }}>
            TRACEABLE • INSPECTABLE • REPRODUCIBLE
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}

// ACT 9 — DISCOVERY STRATEGY (Interrogatories, RFAs, Subpoenas)
export function Act9DiscoveryScene({ scene, isPlaying }: SceneProps) {
  const tools = [
    { type: "Interrogatories", count: 25, color: "#60A5FA" },
    { type: "RFAs", count: 35, color: "#818CF8" },
    { type: "Subpoenas", count: 8, color: "#A78BFA" }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0"
      style={{ background: "linear-gradient(135deg, #001a4d, #000033)" }}
    >
      <div className="absolute inset-0 flex items-center justify-center gap-10 px-16">
        {tools.map((tool, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, rotateY: -90 }}
            animate={{ opacity: 1, rotateY: 0 }}
            transition={{ delay: 0.6 + idx * 0.5, duration: 0.7 }}
          >
            <div
              className="w-64 h-96 rounded-xl p-8 flex flex-col justify-between"
              style={{
                backgroundColor: "rgba(255,255,255,0.05)",
                border: `2px solid ${tool.color}40`,
              }}
            >
              <div>
                <p className="text-2xl font-bold mb-8" style={{ color: tool.color }}>
                  {tool.type}
                </p>

                {/* Request lines */}
                <div className="space-y-3">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="h-2 rounded-full"
                      style={{ backgroundColor: `${tool.color}30` }}
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ delay: 1.8 + idx * 0.5 + i * 0.12 }}
                    />
                  ))}
                </div>
              </div>

              {/* Count badge */}
              <motion.div
                className="text-center py-4 rounded-lg"
                style={{
                  backgroundColor: `${tool.color}20`,
                  border: `2px solid ${tool.color}60`,
                }}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 3 + idx * 0.5, type: "spring" }}
              >
                <p className="text-2xl font-bold mb-1" style={{ color: tool.color }}>
                  {tool.count}
                </p>
                <p className="text-xs font-semibold tracking-wide" style={{ color: tool.color }}>
                  STRATEGIC REQUESTS
                </p>
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}