// Dialogue Scripts for Jenny and Interview Agent

export interface DialogueLine {
  speaker: "jenny" | "agent";
  text: string;
  delay: number; // milliseconds from start of scene
  duration: number; // how long to display
}

// ACT 2: Structured Interview Dialogue
export const ACT2_DIALOGUE: DialogueLine[] = [
  {
    speaker: "jenny",
    text: "I started a real estate development company with my colleague Dawn. We were 70-30 partners originally.",
    delay: 500,
    duration: 5000
  },
  {
    speaker: "agent",
    text: "Thank you, Jenny. When was the operating agreement executed, and what governance structure was established?",
    delay: 5800,
    duration: 4500
  },
  {
    speaker: "jenny",
    text: "We signed in January 2020. I had majority control, Dawn had minority interest. We shared board seats.",
    delay: 10600,
    duration: 4500
  },
  {
    speaker: "agent",
    text: "Were there any amendments to ownership percentages or board authority over time?",
    delay: 15400,
    duration: 3500
  },
  {
    speaker: "jenny",
    text: "Yes. Over the next two years, Dawn pushed for changes. My ownership dropped to 45%. Board decisions shifted.",
    delay: 19200,
    duration: 5000
  },
  {
    speaker: "agent",
    text: "Did you consent to these changes? Were they properly documented and voted on?",
    delay: 24500,
    duration: 3800
  },
  {
    speaker: "jenny",
    text: "Some were voted on. Some just... happened. I felt pressured. The company's now worth millions, but I've lost control.",
    delay: 28600,
    duration: 5500
  },
  {
    speaker: "agent",
    text: "Do you believe there was a breach of fiduciary duty in how these transfers occurred?",
    delay: 34400,
    duration: 3500
  },
  {
    speaker: "jenny",
    text: "Yes. I think Dawn violated her duties to me as a partner. Do I have a case?",
    delay: 38200,
    duration: 3800
  },
  {
    speaker: "agent",
    text: "Let me assemble what you've shared and create a structured timeline for your review.",
    delay: 42300,
    duration: 3700
  }
];

// ACT 3: Case Validation Dialogue
export const ACT3_DIALOGUE: DialogueLine[] = [
  {
    speaker: "agent",
    text: "Jenny, here's the structured timeline I've assembled from your statements.",
    delay: 500,
    duration: 3500
  },
  {
    speaker: "agent",
    text: "January 2020: Operating agreement executed. 70-30 partnership. You held majority control.",
    delay: 4300,
    duration: 4000
  },
  {
    speaker: "agent",
    text: "March 2021: First ownership revision. Your stake reduced to 55%.",
    delay: 8600,
    duration: 3500
  },
  {
    speaker: "agent",
    text: "September 2022: Second revision. Your ownership now at 45%. Dawn gained board authority.",
    delay: 12400,
    duration: 4500
  },
  {
    speaker: "jenny",
    text: "That's accurate. The timing matches what I remember.",
    delay: 17200,
    duration: 3000
  },
  {
    speaker: "agent",
    text: "You indicated some changes occurred without proper votes. Can you clarify which ones?",
    delay: 20500,
    duration: 3800
  },
  {
    speaker: "jenny",
    text: "The September 2022 change. I don't recall a formal board vote. Dawn just presented new documents.",
    delay: 24600,
    duration: 4500
  },
  {
    speaker: "agent",
    text: "Understood. This creates a traceable record. Each statement you've made is preserved and timestamped.",
    delay: 29400,
    duration: 4200
  },
  {
    speaker: "jenny",
    text: "So what happens now?",
    delay: 33900,
    duration: 2000
  },
  {
    speaker: "agent",
    text: "We'll map your evidence to legal elements. Upload any documents—agreements, emails, board minutes.",
    delay: 36200,
    duration: 4300
  }
];

// Voice configuration for different speakers
export const VOICE_CONFIG = {
  jenny: {
    rate: 0.9,
    pitch: 1.3, // Higher pitch for female voice
    volume: 1.0,
    voiceIndex: 0 // Will try to select a female voice
  },
  agent: {
    rate: 0.85,
    pitch: 1.0, // Neutral professional tone
    volume: 1.0,
    voiceIndex: 1 // Will try to select a different voice
  }
};

// Helper to get appropriate voice
export function getVoiceForSpeaker(speaker: "jenny" | "agent"): SpeechSynthesisVoice | null {
  const voices = window.speechSynthesis.getVoices();
  
  if (speaker === "jenny") {
    // Try to find a female English voice
    const femaleVoice = voices.find(v => 
      v.lang.startsWith('en') && 
      (v.name.includes('female') || v.name.includes('Female') || 
       v.name.includes('Samantha') || v.name.includes('Victoria') ||
       v.name.includes('Karen') || v.name.includes('Moira'))
    );
    return femaleVoice || voices.find(v => v.lang.startsWith('en')) || voices[0];
  } else {
    // Try to find a different English voice for agent
    const agentVoice = voices.find(v => 
      v.lang.startsWith('en') && 
      !v.name.includes('Samantha') && !v.name.includes('Victoria')
    );
    return agentVoice || voices.find(v => v.lang.startsWith('en')) || voices[1] || voices[0];
  }
}
