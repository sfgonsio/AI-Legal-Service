import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Pause, RotateCcw, Volume2, VolumeX } from "lucide-react";
import {
  TitleScene,
  Act1ClientScene,
  Act2InterviewScene,
  Act3ValidationScene,
  Act4EvidenceScene,
} from "./VideoScenes";
import {
  Act5EvaluationScene,
  Act6MappingScene,
  Act7PatternScene,
  Act8ComplaintScene,
  Act9DiscoveryScene,
} from "./VideoScenesExtended";
import {
  Act10DepositionPrepScene,
  Act11DepositionExecScene,
  Act12TrialScene,
  Act13KnowledgeScene,
  FinalScene,
} from "./VideoScenesFinal";
import { 
  ACT2_DIALOGUE, 
  ACT3_DIALOGUE, 
  DialogueLine, 
  VOICE_CONFIG,
  getVoiceForSpeaker 
} from "./DialogueScripts";

// EXACT SCRIPT FROM YOUR MARKDOWN
interface Scene {
  id: number;
  title: string;
  duration: number;
  voiceover: string;
  visualType: string;
}

// Calculate speech duration based on word count and speech rate
function estimateSpeechDuration(text: string, rate: number = 0.85): number {
  if (!text || text === "") return 0;
  const words = text.trim().split(/\s+/).length;
  const wordsPerSecond = (150 / 60) * rate; // 150 WPM at rate 1.0
  const baseSeconds = words / wordsPerSecond;
  const pauseBuffer = baseSeconds * 0.2; // 20% buffer for natural pauses
  return Math.ceil((baseSeconds + pauseBuffer) * 1000); // milliseconds
}

const SCENES: Scene[] = [
  {
    id: 0,
    title: "TITLE",
    duration: 8000, // Recalculated: 14 words
    voiceover: "Engineering Litigation Structure. Evidence-Centered Legal Infrastructure.",
    visualType: "title"
  },
  {
    id: 1,
    title: "ACT 1 — THE CLIENT",
    duration: 38000, // Recalculated: 74 words (was 15000 - SEVERELY truncated!)
    voiceover: "Jenny founded a real estate development company. She brought in a colleague, Dawn, as a minority partner. They executed operating agreements. They shared governance. They shared equity. Over time, control shifted. Board authority changed. Ownership percentages were revised. Jenny's influence diminished. Today, the company is thriving. Jenny believes the transfer of control violated fiduciary obligations. She wants to understand her legal position.",
    visualType: "act1"
  },
  {
    id: 2,
    title: "ACT 2 — STRUCTURED INTERVIEW",
    duration: 48000, // Dialogue-based, kept extended duration
    voiceover: "", // Dialogue handles audio
    visualType: "act2"
  },
  {
    id: 3,
    title: "ACT 3 — CASE VALIDATION",
    duration: 42000, // Dialogue-based, kept extended duration
    voiceover: "", // Dialogue handles audio
    visualType: "act3"
  },
  {
    id: 4,
    title: "ACT 4 — EVIDENCE INTAKE & PRESERVATION",
    duration: 29000, // Recalculated: 56 words (was 12000)
    voiceover: "Jenny uploads evidence. Operating agreements. Board minutes. Email threads. Text messages. Cap table revisions. Each file becomes an Evidence Foundation Packet. A SHA-256 hash is generated. An immutable storage reference is created. Chain of custody begins immediately. Integrity is preserved before analysis begins. Traceability is engineered at intake.",
    visualType: "act4"
  },
  {
    id: 5,
    title: "ACT 5 — STRUCTURED EVALUATION",
    duration: 32000, // Recalculated: 62 words (was 14000)
    voiceover: "Structured rule overlays evaluate the evidence. Authentication. Hearsay analysis. Privilege review. Relevance and 352 balancing. Expert foundation when required. These evaluations are deterministic programs. Versioned. Replayable. Auditable. No silent assumptions. If foundation is weak, it is flagged. If exceptions are required, they are documented. Admissibility posture becomes visible early.",
    visualType: "act5"
  },
  {
    id: 6,
    title: "ACT 6 — LEGAL ELEMENT MAPPING",
    duration: 22000, // Recalculated: 42 words (was 11000)
    voiceover: "Facts extracted from evidence are mapped to legal elements. Breach of fiduciary duty. Constructive fraud. Conversion. Contract breach. Each element must be supported by admissible evidence. Coverage gaps surface before filings occur. The legal narrative is assembled from structure. Not drafted in isolation.",
    visualType: "act6"
  },
  {
    id: 7,
    title: "ACT 7 — PATTERN RECOGNITION",
    duration: 27000, // Recalculated: 52 words (was 12000)
    voiceover: "The platform identifies patterns across the record. Ownership transfers preceding formal votes. Communication clusters before governance changes. Inconsistent timestamps. Narrative contradictions. Patterns that would be difficult to detect manually. Recommendations surface. The attorney reviews. Judgment remains human. Structure enhances visibility.",
    visualType: "act7"
  },
  {
    id: 8,
    title: "ACT 8 — COMPLAINT CONSTRUCTION",
    duration: 17000, // Recalculated: 32 words (was 10000)
    voiceover: "When the complaint is prepared, each paragraph links backward. From argument, to element, to fact, to statement, to original file. Traceable. Inspectable. Reproducible. Reasoning is bounded by evidence. Outputs remain auditable.",
    visualType: "act8"
  },
  {
    id: 9,
    title: "ACT 9 — DISCOVERY STRATEGY",
    duration: 26000, // Recalculated: 50 words (was 10000)
    voiceover: "Discovery becomes targeted. Interrogatories are generated to close element gaps. Requests for admission are structured to pin down disputed facts. Subpoenas are drafted to secure missing custodial records. Each request ties to a strategic objective. Privilege implications are pre-evaluated. Discovery becomes intentional.",
    visualType: "act9"
  },
  {
    id: 10,
    title: "ACT 10 — DEPOSITION PREPARATION",
    duration: 25000, // Recalculated: 48 words (was 11000)
    voiceover: "Deposition preparation proceeds in two phases. Phase One: Preparation. Witnesses are identified. Question sequences are structured. Contradictions are surfaced. Objectives are mapped to elements. Questions are tied to evidence. Impeachment material is pre-validated. Preparation becomes systematic.",
    visualType: "act10"
  },
  {
    id: 11,
    title: "ACT 11 — DEPOSITION EXECUTION & PROCESSING",
    duration: 30000, // Recalculated: 58 words (was 11000)
    voiceover: "Phase Two: Execution and Processing. Video and audio are ingested. Transcripts are parsed into structured statements. Testimony is mapped back to elements and prior evidence. Discrepancies are flagged. New facts are versioned. Deposition testimony becomes structured data. Tagged. Stored. Retrievable. The record strengthens or weakens visibly.",
    visualType: "act11"
  },
  {
    id: 12,
    title: "ACT 12 — TRIAL READINESS",
    duration: 19000, // Recalculated: 36 words (was 10000)
    voiceover: "Exhibits are pre-evaluated. Authentication foundations are documented. Hearsay exceptions are mapped. Privilege challenges are resolved. If objections arise, the foundation packet is visible. Lineage is clear. Structure holds under scrutiny.",
    visualType: "act12"
  },
  {
    id: 13,
    title: "ACT 13 — KNOWLEDGE EVOLUTION",
    duration: 35000, // Recalculated: 68 words (was 13000)
    voiceover: "At each stage, the system moves from Data, to information, to knowledge, to insight. Structured programs govern AI agents. Configuration boundaries prevent drift. Reasoning is constrained by rules. Learning occurs within governance. Outputs remain deterministic and replayable. Complexity increases internally. Cognitive load remains low externally.",
    visualType: "act13"
  },
  {
    id: 14,
    title: "FINAL FRAME",
    duration: 30000, // Recalculated: 58 words (was 10000)
    voiceover: "This is evidence-centered litigation infrastructure. Where preparation is structured. Admissibility is visible. Discovery is intentional. Deposition is disciplined. Trial readiness is traceable. Structure does not replace judgment. It strengthens it. Evidence-Centered Litigation Architecture. Engineered for Adversarial Environments.",
    visualType: "final"
  }
];

export function CinematicVideo() {
  const [currentScene, setCurrentScene] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [sceneProgress, setSceneProgress] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.8);
  
  const sceneStartTimeRef = useRef<number>(0);
  const animationFrameRef = useRef<number | null>(null);

  // Calculate total progress across all scenes
  const totalDuration = SCENES.reduce((sum, s) => sum + s.duration, 0);
  const elapsedDuration = SCENES.slice(0, currentScene).reduce((sum, s) => sum + s.duration, 0);
  const totalProgress = (elapsedDuration + (sceneProgress * SCENES[currentScene].duration)) / totalDuration;

  // Scene advancement and progress tracking
  useEffect(() => {
    if (!isPlaying) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      return;
    }

    sceneStartTimeRef.current = Date.now();
    const sceneDuration = SCENES[currentScene].duration;

    const updateProgress = () => {
      const elapsed = Date.now() - sceneStartTimeRef.current;
      const progress = Math.min(elapsed / sceneDuration, 1);
      setSceneProgress(progress);

      if (progress >= 1) {
        // Scene complete
        if (currentScene < SCENES.length - 1) {
          setCurrentScene(prev => prev + 1);
          setSceneProgress(0);
        } else {
          setIsPlaying(false);
          setSceneProgress(1);
        }
      } else {
        animationFrameRef.current = requestAnimationFrame(updateProgress);
      }
    };

    animationFrameRef.current = requestAnimationFrame(updateProgress);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, currentScene]);

  // Text-to-Speech for voiceover (only for non-dialogue scenes)
  useEffect(() => {
    const scene = SCENES[currentScene];
    
    // Skip voiceover for dialogue scenes (ACT 2, ACT 3) - they handle their own audio
    const isDialogueScene = scene.visualType === 'act2' || scene.visualType === 'act3';
    
    if (isDialogueScene || !scene.voiceover || !isPlaying || isMuted) {
      // Only cancel if not playing or muted, but don't cancel for dialogue scenes
      if (!isDialogueScene) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    // Wait for voices to be ready
    const speakWhenReady = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length === 0) {
        setTimeout(speakWhenReady, 100);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(scene.voiceover);
      utterance.rate = 0.85;
      utterance.pitch = 1;
      utterance.volume = volume;

      window.speechSynthesis.speak(utterance);
    };

    speakWhenReady();

    return () => {
      window.speechSynthesis.cancel();
    };
  }, [currentScene, isPlaying, isMuted, volume]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleRestart = () => {
    window.speechSynthesis.cancel();
    setCurrentScene(0);
    setSceneProgress(0);
    setIsPlaying(true);
  };

  const handleMuteToggle = () => {
    setIsMuted(!isMuted);
  };

  const handleSceneJump = (sceneIndex: number) => {
    window.speechSynthesis.cancel();
    setCurrentScene(sceneIndex);
    setSceneProgress(0);
    if (!isPlaying) {
      setIsPlaying(true);
    }
  };

  // Handle timeline scrub
  const handleTimelineScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    const targetTime = percentage * totalDuration;

    // Find which scene this corresponds to
    let accumulatedTime = 0;
    for (let i = 0; i < SCENES.length; i++) {
      if (accumulatedTime + SCENES[i].duration > targetTime) {
        const sceneElapsed = targetTime - accumulatedTime;
        const sceneProgress = sceneElapsed / SCENES[i].duration;
        
        window.speechSynthesis.cancel();
        setCurrentScene(i);
        setSceneProgress(sceneProgress);
        sceneStartTimeRef.current = Date.now() - sceneElapsed;
        
        if (!isPlaying) {
          setIsPlaying(true);
        }
        break;
      }
      accumulatedTime += SCENES[i].duration;
    }
  };

  const scene = SCENES[currentScene];

  return (
    <div className="relative w-full h-screen overflow-hidden" style={{ backgroundColor: "#000033" }}>
      {/* Scene Content - CLEAN VISUALS ONLY */}
      <AnimatePresence mode="wait">
        <SceneRenderer key={scene.id} scene={scene} isPlaying={isPlaying} />
      </AnimatePresence>

      {/* Title Overlay - Only shows scene title, not voiceover */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute top-8 left-8 z-40"
      >
        <p 
          className="text-sm font-semibold tracking-wide uppercase"
          style={{ 
            color: "rgba(255,255,255,0.6)",
            textShadow: "0 2px 8px rgba(0,0,0,0.8)"
          }}
        >
          {scene.title}
        </p>
      </motion.div>

      {/* Control Bar - REDUCED SIZE, PUSHED TO BOTTOM */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="absolute bottom-0 left-0 right-0 z-50"
        style={{
          background: "linear-gradient(to top, rgba(0,0,51,0.98), transparent)",
          paddingTop: "32px",
          paddingBottom: "20px",
          paddingLeft: "24px",
          paddingRight: "24px",
        }}
      >
        <div className="max-w-6xl mx-auto">
          {/* Timeline Progress Bar - Clickable */}
          <div className="mb-4">
            <div
              className="w-full h-1.5 rounded-full overflow-hidden cursor-pointer"
              style={{ backgroundColor: "rgba(255,255,255,0.2)" }}
              onClick={handleTimelineScrub}
            >
              <motion.div
                className="h-full pointer-events-none"
                style={{ backgroundColor: "#FFFFFF" }}
                animate={{ width: `${totalProgress * 100}%` }}
                transition={{ duration: 0.1, ease: "linear" }}
              />
            </div>
            
            {/* Scene Markers */}
            <div className="flex justify-between mt-2">
              {SCENES.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => handleSceneJump(idx)}
                  className="group relative"
                >
                  <div
                    className="w-2 h-2 rounded-full transition-all"
                    style={{
                      backgroundColor: idx === currentScene ? "#FFFFFF" : "rgba(255,255,255,0.3)",
                      transform: idx === currentScene ? "scale(1.4)" : "scale(1)",
                      boxShadow: idx === currentScene ? "0 0 8px rgba(255,255,255,0.6)" : "none",
                    }}
                  />
                  <div
                    className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 rounded text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                    style={{ 
                      backgroundColor: "rgba(0,0,51,0.95)", 
                      color: "#FFFFFF",
                      border: "1px solid rgba(255,255,255,0.2)",
                      fontSize: "10px",
                    }}
                  >
                    {s.title}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Controls Row - COMPACT */}
          <div className="flex items-center justify-between">
            {/* Left: Playback Controls */}
            <div className="flex items-center gap-3">
              <button
                onClick={handlePlayPause}
                className="w-9 h-9 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{ backgroundColor: "#FFFFFF", color: "#000033" }}
              >
                {isPlaying ? <Pause size={16} /> : <Play size={16} style={{ marginLeft: "2px" }} />}
              </button>

              <button
                onClick={handleRestart}
                className="w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{ backgroundColor: "rgba(255,255,255,0.2)", color: "#FFFFFF" }}
              >
                <RotateCcw size={14} />
              </button>

              <div className="w-px h-6 mx-1" style={{ backgroundColor: "rgba(255,255,255,0.2)" }} />

              {/* Volume Controls */}
              <button
                onClick={handleMuteToggle}
                className="w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
                style={{ backgroundColor: "rgba(255,255,255,0.2)", color: "#FFFFFF" }}
              >
                {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
              </button>

              {/* Volume Slider - Compact */}
              <div 
                className="flex items-center gap-2"
                onMouseDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume * 100}
                  onChange={(e) => {
                    e.stopPropagation();
                    const newVolume = parseInt(e.target.value) / 100;
                    setVolume(newVolume);
                    if (newVolume === 0) {
                      setIsMuted(true);
                    } else if (isMuted) {
                      setIsMuted(false);
                    }
                  }}
                  onMouseDown={(e) => e.stopPropagation()}
                  onClick={(e) => e.stopPropagation()}
                  className="w-20 h-1.5 rounded-full cursor-pointer"
                  style={{
                    appearance: "none",
                    WebkitAppearance: "none",
                    backgroundColor: "rgba(255,255,255,0.2)",
                    outline: "none",
                    background: `linear-gradient(to right, #FFFFFF 0%, #FFFFFF ${volume * 100}%, rgba(255,255,255,0.2) ${volume * 100}%, rgba(255,255,255,0.2) 100%)`,
                  }}
                />
                <span className="text-xs font-mono font-semibold w-8 text-right" style={{ color: "#FFFFFF", fontSize: "10px" }}>
                  {Math.round(volume * 100)}%
                </span>
              </div>
            </div>

            {/* Right: Scene Counter - COMPACT */}
            <div className="text-right">
              <p className="text-xs font-semibold" style={{ color: "rgba(255,255,255,0.9)" }}>
                Scene {currentScene + 1} / {SCENES.length}
              </p>
              <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.5)", fontSize: "10px" }}>
                {Math.round(totalProgress * 100)}% Complete
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Optional: Closed Captions toggle */}
      {/* You could add a CC button here that shows/hides subtitles if needed */}
    </div>
  );
}

// Scene Renderer - Routes to correct scene component
function SceneRenderer({ scene, isPlaying }: { scene: Scene; isPlaying: boolean }) {
  switch (scene.visualType) {
    case "title":
      return <TitleScene scene={scene} isPlaying={isPlaying} />;
    case "act1":
      return <Act1ClientScene scene={scene} isPlaying={isPlaying} />;
    case "act2":
      return <Act2InterviewScene scene={scene} isPlaying={isPlaying} />;
    case "act3":
      return <Act3ValidationScene scene={scene} isPlaying={isPlaying} />;
    case "act4":
      return <Act4EvidenceScene scene={scene} isPlaying={isPlaying} />;
    case "act5":
      return <Act5EvaluationScene scene={scene} isPlaying={isPlaying} />;
    case "act6":
      return <Act6MappingScene scene={scene} isPlaying={isPlaying} />;
    case "act7":
      return <Act7PatternScene scene={scene} isPlaying={isPlaying} />;
    case "act8":
      return <Act8ComplaintScene scene={scene} isPlaying={isPlaying} />;
    case "act9":
      return <Act9DiscoveryScene scene={scene} isPlaying={isPlaying} />;
    case "act10":
      return <Act10DepositionPrepScene scene={scene} isPlaying={isPlaying} />;
    case "act11":
      return <Act11DepositionExecScene scene={scene} isPlaying={isPlaying} />;
    case "act12":
      return <Act12TrialScene scene={scene} isPlaying={isPlaying} />;
    case "act13":
      return <Act13KnowledgeScene scene={scene} isPlaying={isPlaying} />;
    case "final":
      return <FinalScene scene={scene} isPlaying={isPlaying} />;
    default:
      return <TitleScene scene={scene} isPlaying={isPlaying} />;
  }
}