import { ReactNode, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HelpCircle } from "lucide-react";

interface TermDefinitionProps {
  term: string | ReactNode;
  definition: string;
  variant?: "inline" | "icon" | "underline";
  position?: "top" | "bottom" | "left" | "right";
  className?: string;
}

/**
 * TermDefinition - Generalized component for hover definitions
 * 
 * Usage:
 * <TermDefinition 
 *   term="State Machine Controller" 
 *   definition="Orchestrates workflow transitions between stages"
 *   variant="underline"
 * />
 * 
 * Variants:
 * - "inline": Text with dotted underline (default)
 * - "icon": Shows help icon next to term
 * - "underline": Bold text with hover underline
 */
export function TermDefinition({ 
  term, 
  definition, 
  variant = "inline",
  position = "top",
  className = "",
}: TermDefinitionProps) {
  const [isHovered, setIsHovered] = useState(false);

  const renderTerm = () => {
    switch (variant) {
      case "icon":
        return (
          <span className={`inline-flex items-center gap-1.5 ${className}`}>
            {term}
            <HelpCircle 
              size={14} 
              style={{ color: 'var(--primary-blue)', opacity: 0.7 }} 
            />
          </span>
        );
      case "underline":
        return (
          <span 
            className={`font-semibold border-b-2 border-dotted cursor-help ${className}`}
            style={{ 
              borderColor: 'var(--primary-blue)',
              color: 'var(--primary-blue)',
            }}
          >
            {term}
          </span>
        );
      case "inline":
      default:
        return (
          <span 
            className={`border-b border-dotted cursor-help ${className}`}
            style={{ 
              borderColor: 'var(--text-secondary)',
            }}
          >
            {term}
          </span>
        );
    }
  };

  const getPositionStyles = () => {
    switch (position) {
      case "bottom":
        return "top-full mt-2";
      case "left":
        return "right-full mr-2 top-1/2 -translate-y-1/2";
      case "right":
        return "left-full ml-2 top-1/2 -translate-y-1/2";
      case "top":
      default:
        return "bottom-full mb-2";
    }
  };

  return (
    <span 
      className="relative inline-block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {renderTerm()}
      
      <AnimatePresence>
        {isHovered && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: position === "top" ? 5 : -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: position === "top" ? 5 : -5 }}
            transition={{ duration: 0.15 }}
            className={`absolute ${getPositionStyles()} z-50 w-64 pointer-events-none`}
          >
            <div
              className="px-3 py-2 rounded-lg shadow-lg border text-xs leading-relaxed"
              style={{
                backgroundColor: 'var(--deep-navy)',
                color: 'var(--white)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
              }}
            >
              {definition}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </span>
  );
}

/**
 * Alternative compact version for use in diagrams or tight spaces
 */
interface TermIconProps {
  definition: string;
  size?: number;
}

export function TermIcon({ definition, size = 14 }: TermIconProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <span 
      className="relative inline-block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <HelpCircle 
        size={size}
        className="cursor-help"
        style={{ color: 'var(--primary-blue)', opacity: 0.6 }} 
      />
      
      <AnimatePresence>
        {isHovered && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 z-50 w-64 pointer-events-none"
          >
            <div
              className="px-3 py-2 rounded-lg shadow-lg border text-xs leading-relaxed"
              style={{
                backgroundColor: 'var(--deep-navy)',
                color: 'var(--white)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
              }}
            >
              {definition}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </span>
  );
}
