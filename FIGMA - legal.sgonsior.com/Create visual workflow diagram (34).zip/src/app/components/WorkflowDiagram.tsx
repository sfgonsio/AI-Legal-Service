import { motion } from "motion/react";
import { useState } from "react";
import { 
  User, 
  Sparkles, 
  Database, 
  FileText, 
  AlertCircle, 
  CheckCircle2,
  ArrowRight,
  Zap
} from "lucide-react";

// Legal moments of truth with their deliverables
const legalMoments = [
  {
    stage: "1. Case Intake",
    moment: "Initial Complaint",
    human: "Attorney reviews facts, decides to take case",
    agent: "Interview Agent conducts structured intake, validates completeness",
    program: "Locks factual baseline, generates intake fingerprint",
    output: "Verified case file ready for complaint drafting",
    color: "#2563eb"
  },
  {
    stage: "2. Filing",
    moment: "Court Complaint",
    human: "Attorney authorizes legal claims and strategy",
    agent: "Mapping Agent aligns facts to cause-of-action elements",
    program: "Generates complaint with evidence citations, audit trail",
    output: "Court-ready complaint with evidentiary support",
    color: "#7c3aed"
  },
  {
    stage: "3. Discovery",
    moment: "Interrogatories",
    human: "Attorney reviews responses, identifies gaps",
    agent: "Processing Agent structures incoming documents and responses",
    program: "Maps responses to case elements, flags contradictions",
    output: "Organized discovery responses with analysis",
    color: "#db2777"
  },
  {
    stage: "4. Evidence Review",
    moment: "Deposition Prep",
    human: "Attorney determines key questions and witnesses",
    agent: "Output Agent generates question sequences from evidence",
    program: "Cross-references testimony with prior statements",
    output: "Deposition outline with evidence citations",
    color: "#dc2626"
  },
  {
    stage: "5. Subpoena Response",
    moment: "Document Production",
    human: "Attorney validates scope and privilege claims",
    agent: "Processing Agent organizes and redacts documents",
    program: "Generates production log with metadata tracking",
    output: "Compliant document production with privilege log",
    color: "#ea580c"
  }
];

// Helper function for step colors
const getStepColor = (step: number) => {
  const colors = [
    "#000033", // Step 1: Original dark navy
    "#1a2966", // Step 2: Much lighter jump
    "#334d99", // Step 3: Mid-range blue
    "#4d70cc", // Step 4: Brighter blue
    "#6694ff", // Step 5: Brightest blue
  ];
  return colors[step] || colors[0];
};

export function WorkflowDiagram() {
  const [selectedMoment, setSelectedMoment] = useState<number | null>(null);

  return (
    <div className="space-y-8">
      {/* Header: The System */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h3 className="text-2xl font-bold mb-3" style={{ color: '#000033' }}>
          Human + AI + Program = Legal Deliverables
        </h3>
        <p className="text-base" style={{ color: '#718096' }}>
          Three system layers working together to deliver at critical legal moments of truth
        </p>
      </motion.div>

      {/* The Three Layers */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        <SystemLayer
          icon={User}
          title="Human Attorney"
          description="Legal judgment, strategy, and final authorization"
          color="#000033"
        />
        <SystemLayer
          icon={Sparkles}
          title="AI Agents"
          description="Structured work, pattern recognition, and drafting"
          color="#336699"
        />
        <SystemLayer
          icon={Database}
          title="Governed Program"
          description="State control, fingerprinting, and audit trails"
          color="#718096"
        />
      </motion.div>

      {/* Visual Explanation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="p-6 rounded-lg border-l-4"
        style={{
          backgroundColor: '#F4F6F8',
          borderColor: '#336699'
        }}
      >
        <div className="flex items-center gap-3 mb-4">
          <Zap size={20} style={{ color: '#336699' }} />
          <h4 className="font-semibold" style={{ color: '#336699' }}>
            How It Works: Case Journey Through Legal Moments
          </h4>
        </div>
        <p className="text-sm mb-4" style={{ color: '#4A5568' }}>
          Click any stage below to see how Human + Agent + Program collaborate to deliver at that legal moment of truth.
        </p>
        <div className="flex items-center gap-4 text-xs flex-wrap">
          <div className="flex items-center gap-2">
            <User size={16} style={{ color: '#000033' }} />
            <span style={{ color: '#718096' }}>Attorney decides & authorizes</span>
          </div>
          <ArrowRight size={16} style={{ color: '#336699' }} />
          <div className="flex items-center gap-2">
            <Sparkles size={16} style={{ color: '#336699' }} />
            <span style={{ color: '#718096' }}>Agent executes structured work</span>
          </div>
          <ArrowRight size={16} style={{ color: '#336699' }} />
          <div className="flex items-center gap-2">
            <Database size={16} style={{ color: '#718096' }} />
            <span style={{ color: '#718096' }}>Program governs & delivers output</span>
          </div>
        </div>
      </motion.div>

      {/* Case Journey Timeline - Cards with Aligned Rows */}
      <div className="relative">
        <div className="flex gap-6 overflow-x-auto pb-4">
          {legalMoments.map((moment, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + index * 0.1 }}
              whileHover={{ y: -4 }}
              onClick={() => setSelectedMoment(selectedMoment === index ? null : index)}
              className="flex-shrink-0 rounded-lg border cursor-pointer"
              style={{
                width: '280px',
                backgroundColor: selectedMoment === index ? '#F4F6F8' : '#FFFFFF',
                borderColor: selectedMoment === index ? moment.color : '#E2E8F0',
                borderWidth: selectedMoment === index ? '2px' : '1px',
              }}
            >
              {/* Stage Number Circle */}
              <div className="flex justify-center py-4" style={{ height: '72px' }}>
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center font-bold text-white text-lg"
                  style={{ 
                    backgroundColor: getStepColor(index),
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                  }}
                >
                  {index + 1}
                </div>
              </div>

              {/* Row 1: Stage - Fixed Height */}
              <div style={{ height: '60px' }}>
                <div className="px-4 py-3 h-full flex items-start">
                  <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#718096', lineHeight: '18px' }}>
                    {moment.stage}
                  </p>
                </div>
              </div>

              {/* Row 2: Moment - Fixed Height */}
              <div style={{ height: '72px' }}>
                <div className="px-4 py-3 h-full flex items-start">
                  <h4 className="font-bold text-base" style={{ color: moment.color, lineHeight: '22px' }}>
                    {moment.moment}
                  </h4>
                </div>
              </div>

              {/* Row 3: Human - Fixed Height */}
              <div style={{ height: '96px' }}>
                <div className="px-4 py-3 h-full">
                  <div className="flex items-start gap-2">
                    <User size={14} className="flex-shrink-0" style={{ color: '#000033', marginTop: '2px' }} />
                    <div>
                      <p className="text-xs font-semibold mb-1" style={{ color: '#000033' }}>Attorney</p>
                      <p className="text-xs" style={{ color: '#4A5568', lineHeight: '18px' }}>{moment.human}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 4: Agent - Fixed Height */}
              <div style={{ height: '96px' }}>
                <div className="px-4 py-3 h-full">
                  <div className="flex items-start gap-2">
                    <Sparkles size={14} className="flex-shrink-0" style={{ color: '#336699', marginTop: '2px' }} />
                    <div>
                      <p className="text-xs font-semibold mb-1" style={{ color: '#336699' }}>AI Agent</p>
                      <p className="text-xs" style={{ color: '#4A5568', lineHeight: '18px' }}>{moment.agent}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 5: Program - Fixed Height */}
              <div style={{ height: '96px' }}>
                <div className="px-4 py-3 h-full">
                  <div className="flex items-start gap-2">
                    <Database size={14} className="flex-shrink-0" style={{ color: '#718096', marginTop: '2px' }} />
                    <div>
                      <p className="text-xs font-semibold mb-1" style={{ color: '#718096' }}>Program</p>
                      <p className="text-xs" style={{ color: '#4A5568', lineHeight: '18px' }}>{moment.program}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 6: Output - Fixed Height */}
              <div style={{ height: '110px', borderTop: '1px solid #E2E8F0' }}>
                <div className="px-4 py-3 h-full">
                  <div className="flex items-start gap-2 mb-2">
                    <FileText size={14} style={{ color: moment.color }} />
                    <p className="text-xs font-semibold" style={{ color: '#2D3748' }}>Output</p>
                  </div>
                  <p className="text-xs font-medium" style={{ color: moment.color, lineHeight: '18px' }}>
                    {moment.output}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Detailed View */}
      {selectedMoment !== null && (
        <DetailedMomentView moment={legalMoments[selectedMoment]} />
      )}

      {/* Key Principles */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        <PrincipleCard
          icon={User}
          title="Attorney Controls"
          description="Human judgment authorizes every critical decision and output"
        />
        <PrincipleCard
          icon={CheckCircle2}
          title="Agents Execute"
          description="AI performs structured work under program governance"
        />
        <PrincipleCard
          icon={FileText}
          title="Program Delivers"
          description="System generates traceable, reproducible legal outputs"
        />
      </motion.div>
    </div>
  );
}

// System Layer Component
function SystemLayer({ 
  icon: Icon, 
  title, 
  description, 
  color 
}: { 
  icon: any; 
  title: string; 
  description: string; 
  color: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="p-6 rounded-lg border text-center"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#E2E8F0'
      }}
    >
      <div 
        className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
        style={{ backgroundColor: color }}
      >
        <Icon size={28} color="#FFFFFF" />
      </div>
      <h4 className="font-bold mb-2" style={{ color: '#2D3748' }}>
        {title}
      </h4>
      <p className="text-sm" style={{ color: '#718096' }}>
        {description}
      </p>
    </motion.div>
  );
}

// Legal Moment Card Component
function LegalMomentCard({ 
  moment, 
  index, 
  isSelected, 
  onClick 
}: { 
  moment: any; 
  index: number; 
  isSelected: boolean; 
  onClick: () => void;
}) {
  return (
    <div className="relative z-10">
      {/* Stage Number Circle */}
      <div className="flex justify-center mb-4">
        <motion.div
          whileHover={{ scale: 1.1 }}
          className="w-12 h-12 rounded-full flex items-center justify-center cursor-pointer font-bold text-white text-lg"
          style={{ 
            backgroundColor: getStepColor(index),
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
          }}
          onClick={onClick}
        >
          {index + 1}
        </motion.div>
      </div>

      {/* Card - FIXED HEIGHT TABLE for perfect horizontal alignment */}
      <motion.div
        whileHover={{ y: -4 }}
        onClick={onClick}
        className="rounded-lg border cursor-pointer"
        style={{
          backgroundColor: isSelected ? '#F4F6F8' : '#FFFFFF',
          borderColor: isSelected ? moment.color : '#E2E8F0',
          borderWidth: isSelected ? '2px' : '1px',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Row 1: Stage - FIXED HEIGHT 44px */}
        <div style={{ 
          padding: '12px 16px',
          borderBottom: '1px solid #E2E8F0',
          height: '44px',
          display: 'flex',
          alignItems: 'flex-start',
          overflow: 'hidden'
        }}>
          <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#718096', lineHeight: '18px' }}>
            {moment.stage}
          </p>
        </div>

        {/* Row 2: Moment Title - FIXED HEIGHT 52px */}
        <div style={{ 
          padding: '12px 16px',
          borderBottom: '1px solid #E2E8F0',
          height: '52px',
          display: 'flex',
          alignItems: 'flex-start',
          overflow: 'hidden'
        }}>
          <h4 className="font-bold text-base" style={{ color: moment.color, lineHeight: '22px' }}>
            {moment.moment}
          </h4>
        </div>

        {/* Row 3: Human - FIXED HEIGHT 70px */}
        <div style={{ 
          padding: '12px 16px',
          borderBottom: '1px solid #E2E8F0',
          height: '70px',
          display: 'flex',
          alignItems: 'flex-start',
          gap: '8px'
        }}>
          <User size={14} className="flex-shrink-0" style={{ color: '#000033', marginTop: '2px' }} />
          <p className="text-xs" style={{ color: '#4A5568', lineHeight: '18px' }}>{moment.human}</p>
        </div>

        {/* Row 4: Agent - FIXED HEIGHT 70px */}
        <div style={{ 
          padding: '12px 16px',
          borderBottom: '1px solid #E2E8F0',
          height: '70px',
          display: 'flex',
          alignItems: 'flex-start',
          gap: '8px'
        }}>
          <Sparkles size={14} className="flex-shrink-0" style={{ color: '#336699', marginTop: '2px' }} />
          <p className="text-xs" style={{ color: '#4A5568', lineHeight: '18px' }}>{moment.agent}</p>
        </div>

        {/* Row 5: Program - FIXED HEIGHT 70px */}
        <div style={{ 
          padding: '12px 16px',
          borderBottom: '1px solid #E2E8F0',
          height: '70px',
          display: 'flex',
          alignItems: 'flex-start',
          gap: '8px'
        }}>
          <Database size={14} className="flex-shrink-0" style={{ color: '#718096', marginTop: '2px' }} />
          <p className="text-xs" style={{ color: '#4A5568', lineHeight: '18px' }}>{moment.program}</p>
        </div>

        {/* Row 6: Output - FIXED HEIGHT 90px */}
        <div style={{ 
          padding: '12px 16px',
          height: '90px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-start'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <FileText size={14} style={{ color: moment.color }} />
            <p className="text-xs font-semibold" style={{ color: '#2D3748', lineHeight: '18px' }}>
              Output:
            </p>
          </div>
          <p className="text-xs font-medium" style={{ color: moment.color, lineHeight: '18px' }}>
            {moment.output}
          </p>
        </div>
      </motion.div>
    </div>
  );
}

// Detailed Moment View Component
function DetailedMomentView({ moment }: { moment: any }) {
  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      className="p-8 rounded-lg border"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: moment.color,
        borderWidth: '2px'
      }}
    >
      <div className="mb-6">
        <h3 className="text-xl font-bold mb-2" style={{ color: moment.color }}>
          {moment.moment}
        </h3>
        <p className="text-sm" style={{ color: '#718096' }}>
          Detailed collaboration at this legal moment of truth
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Human Attorney */}
        <div className="p-6 rounded-lg" style={{ backgroundColor: '#F9FAFB' }}>
          <div className="flex items-center gap-3 mb-3">
            <User size={20} style={{ color: '#000033' }} />
            <h4 className="font-bold" style={{ color: '#000033' }}>
              Human Attorney
            </h4>
          </div>
          <p className="text-sm" style={{ color: '#4A5568' }}>
            {moment.human}
          </p>
          <div className="mt-4 pt-4 border-t" style={{ borderColor: '#E2E8F0' }}>
            <p className="text-xs font-semibold" style={{ color: '#718096' }}>
              Role: Decision & Authorization
            </p>
          </div>
        </div>

        {/* AI Agent */}
        <div className="p-6 rounded-lg" style={{ backgroundColor: '#EFF6FF' }}>
          <div className="flex items-center gap-3 mb-3">
            <Sparkles size={20} style={{ color: '#336699' }} />
            <h4 className="font-bold" style={{ color: '#336699' }}>
              AI Agent
            </h4>
          </div>
          <p className="text-sm" style={{ color: '#4A5568' }}>
            {moment.agent}
          </p>
          <div className="mt-4 pt-4 border-t" style={{ borderColor: '#DBEAFE' }}>
            <p className="text-xs font-semibold" style={{ color: '#718096' }}>
              Role: Structured Execution
            </p>
          </div>
        </div>

        {/* Program */}
        <div className="p-6 rounded-lg" style={{ backgroundColor: '#F4F6F8' }}>
          <div className="flex items-center gap-3 mb-3">
            <Database size={20} style={{ color: '#718096' }} />
            <h4 className="font-bold" style={{ color: '#718096' }}>
              Governed Program
            </h4>
          </div>
          <p className="text-sm" style={{ color: '#4A5568' }}>
            {moment.program}
          </p>
          <div className="mt-4 pt-4 border-t" style={{ borderColor: '#E2E8F0' }}>
            <p className="text-xs font-semibold" style={{ color: '#718096' }}>
              Role: Control & Delivery
            </p>
          </div>
        </div>
      </div>

      {/* Final Output */}
      <div className="p-6 rounded-lg border-l-4" style={{ 
        backgroundColor: '#F4F6F8',
        borderColor: moment.color 
      }}>
        <div className="flex items-center gap-3 mb-3">
          <CheckCircle2 size={20} style={{ color: moment.color }} />
          <h4 className="font-bold" style={{ color: '#2D3748' }}>
            Delivered Output
          </h4>
        </div>
        <p className="text-base font-semibold" style={{ color: moment.color }}>
          {moment.output}
        </p>
        <p className="text-sm mt-2" style={{ color: '#718096' }}>
          Traceable, reproducible, and audit-ready for the legal record
        </p>
      </div>
    </motion.div>
  );
}

// Principle Card Component
function PrincipleCard({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: any; 
  title: string; 
  description: string;
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="p-6 rounded-lg border"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#E2E8F0'
      }}
    >
      <div className="flex items-center gap-3 mb-3">
        <div 
          className="p-2 rounded-lg"
          style={{ backgroundColor: '#F4F6F8' }}
        >
          <Icon size={20} style={{ color: '#336699' }} />
        </div>
        <h4 className="font-bold" style={{ color: '#2D3748' }}>
          {title}
        </h4>
      </div>
      <p className="text-sm" style={{ color: '#718096' }}>
        {description}
      </p>
    </motion.div>
  );
}