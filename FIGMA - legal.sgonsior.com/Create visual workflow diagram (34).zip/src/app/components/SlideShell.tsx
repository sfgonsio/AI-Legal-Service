import { ReactNode } from "react";
import { motion } from "motion/react";
import { useLocation, Link } from "react-router";
import { ArrowLeft, ArrowRight, Grid3x3 } from "lucide-react";
import { getAdjacentSlides, getCurrentSlide, SLIDE_SEQUENCE } from "../config/slideNavigation";

interface SlideShellProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
}

export function SlideShell({ title, subtitle, children }: SlideShellProps) {
  const location = useLocation();
  const { prev, next } = getAdjacentSlides(location.pathname);
  const currentSlide = getCurrentSlide(location.pathname);

  return (
    <div 
      className="min-h-screen w-full"
      style={{ backgroundColor: '#F4F6F8' }}
    >
      <div className="w-full flex flex-col items-center justify-center py-8 md:py-12 px-4 md:px-6">
        {/* Frame Width: 1440px with 96px margins on desktop, responsive on mobile */}
        <div className="w-full max-w-[1440px] mx-auto px-4 md:px-12 lg:px-24">
          
          {/* Slide Number & Index Link */}
          {currentSlide && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="flex items-center justify-between mb-4"
            >
              <div 
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider"
                style={{ 
                  backgroundColor: 'var(--primary-blue)',
                  color: 'white',
                }}
              >
                Slide {currentSlide.order} of {SLIDE_SEQUENCE.length}
              </div>
              
              <Link to="/presentation">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs"
                  style={{
                    borderColor: 'var(--divider)',
                    backgroundColor: 'var(--white)',
                    color: 'var(--primary-blue)',
                  }}
                  title="View all slides"
                >
                  <Grid3x3 size={14} />
                  <span className="hidden sm:inline">All Slides</span>
                </motion.button>
              </Link>
            </motion.div>
          )}
          
          {/* Title & Subtitle - Consistent across all slides */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8 md:mb-12 text-center"
          >
            <h1
              className="font-bold tracking-tight text-3xl md:text-4xl lg:text-5xl"
              style={{ color: "#000033", lineHeight: "1.1" }}
            >
              {title}
            </h1>
            {subtitle && (
              <p
                className="mt-2 md:mt-3 text-sm md:text-base lg:text-lg"
                style={{
                  color: "rgba(0,0,51,0.72)",
                  lineHeight: "1.5",
                }}
              >
                {subtitle}
              </p>
            )}
          </motion.div>

          {/* Slide Content */}
          {children}

          {/* Navigation Controls */}
          {(prev || next) && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="flex items-center justify-between pt-12 mt-12 border-t"
              style={{ borderColor: 'var(--divider)' }}
            >
              {prev ? (
                <Link to={prev.path}>
                  <motion.div
                    whileHover={{ x: -4 }}
                    className="flex flex-col items-start gap-1 group"
                  >
                    <div 
                      className="flex items-center gap-2 text-xs uppercase tracking-wide"
                      style={{ color: 'var(--text-secondary)' }}
                    >
                      <ArrowLeft size={14} />
                      <span>Previous</span>
                    </div>
                    <span 
                      className="text-sm font-semibold group-hover:underline"
                      style={{ color: 'var(--primary-blue)' }}
                    >
                      {prev.shortLabel}
                    </span>
                  </motion.div>
                </Link>
              ) : (
                <div />
              )}

              {next ? (
                <Link to={next.path}>
                  <motion.div
                    whileHover={{ x: 4 }}
                    className="flex flex-col items-end gap-1 group"
                  >
                    <div 
                      className="flex items-center gap-2 text-xs uppercase tracking-wide"
                      style={{ color: 'var(--text-secondary)' }}
                    >
                      <span>Next</span>
                      <ArrowRight size={14} />
                    </div>
                    <span 
                      className="text-sm font-semibold group-hover:underline"
                      style={{ color: 'var(--primary-blue)' }}
                    >
                      {next.shortLabel}
                    </span>
                  </motion.div>
                </Link>
              ) : (
                <div />
              )}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}