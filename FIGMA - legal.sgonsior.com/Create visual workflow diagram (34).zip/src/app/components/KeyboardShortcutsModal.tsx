import { motion, AnimatePresence } from "motion/react";
import { X, Keyboard } from "lucide-react";

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const shortcuts = [
  { keys: ["→", "↓"], description: "Next page/slide" },
  { keys: ["←", "↑"], description: "Previous page/slide" },
  { keys: ["Home"], description: "Go to Welcome (or Presentation Index on slides)" },
  { keys: ["End"], description: "Go to last page" },
  { keys: ["?"], description: "Show/hide shortcuts" },
];

export function KeyboardShortcutsModal({ isOpen, onClose }: KeyboardShortcutsModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50"
            style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md p-6 rounded-lg border shadow-2xl"
            style={{
              backgroundColor: "var(--white)",
              borderColor: "var(--divider)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Keyboard size={24} style={{ color: "var(--primary-blue)" }} />
                <h3>Keyboard Shortcuts</h3>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded hover:bg-gray-100 transition-colors"
              >
                <X size={20} style={{ color: "var(--text-secondary)" }} />
              </button>
            </div>

            {/* Shortcuts List */}
            <div className="space-y-3">
              {shortcuts.map((shortcut, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between py-2"
                >
                  <span className="text-sm" style={{ color: "var(--text-primary)" }}>
                    {shortcut.description}
                  </span>
                  <div className="flex gap-2">
                    {shortcut.keys.map((key, j) => (
                      <kbd
                        key={j}
                        className="px-2 py-1 rounded text-xs font-mono border"
                        style={{
                          backgroundColor: "var(--light-background)",
                          borderColor: "var(--divider)",
                          color: "var(--text-primary)",
                        }}
                      >
                        {key}
                      </kbd>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}