interface ProgressIndicatorProps {
  currentIndex: number;
  total: number;
}

export function ProgressIndicator({ currentIndex, total }: ProgressIndicatorProps) {
  const progress = currentIndex === -1 ? 0 : ((currentIndex + 1) / total) * 100;

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center text-xs" style={{ color: 'var(--text-secondary)' }}>
        <span>PROGRESS</span>
        <span>{currentIndex + 1} / {total}</span>
      </div>
      <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--divider)' }}>
        <div
          className="h-full transition-all duration-500 ease-out rounded-full"
          style={{
            width: `${progress}%`,
            backgroundColor: 'var(--primary-blue)',
          }}
        />
      </div>
    </div>
  );
}
