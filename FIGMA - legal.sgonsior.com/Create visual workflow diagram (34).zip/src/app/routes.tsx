import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Welcome } from "./pages/Welcome";
import { WhatThisIs } from "./pages/WhatThisIs";
import { WhatThisChanges } from "./pages/WhatThisChanges";
import { CoreCapabilities } from "./pages/CoreCapabilities";
import { Workflow } from "./pages/Workflow";
import { AgentProgramMap } from "./pages/AgentProgramMap";
import { Evidentiary } from "./pages/Evidentiary";
import { EngineeringFoundation } from "./pages/EngineeringFoundation";
import { DevelopmentStatus } from "./pages/DevelopmentStatus";
import { LeadershipInput } from "./pages/LeadershipInput";
import { SystemGovernance } from "./pages/SystemGovernance";
import { PlatformArchitectureSlide } from "./pages/PlatformArchitectureSlide";
import { TechArchitectureSlide } from "./pages/TechArchitectureSlide";
import { TechStackSlide } from "./pages/TechStackSlide";
import { LitigationEngineSlide } from "./pages/LitigationEngineSlide";
import { DIKWStrategySlide } from "./pages/DIKWStrategySlide";
import { DataArchitectureSlide } from "./pages/DataArchitectureSlide";
import { EvidencePressureSlide } from "./pages/EvidencePressureSlide";
import { SpineBrainArchitectureSlide } from "./pages/SpineBrainArchitectureSlide";
import { SpineBrainConceptSlide } from "./pages/SpineBrainConceptSlide";
import { SpineArchitectureDetailSlide } from "./pages/SpineArchitectureDetailSlide";
import { BrainArchitectureDetailSlide } from "./pages/BrainArchitectureDetailSlide";
import { PresentationIndex } from "./pages/PresentationIndex";
import { FiveLayerStackSlide } from "./pages/FiveLayerStackSlide";
import { LitigationWorkflowSlide } from "./pages/LitigationWorkflowSlide";
import { ArtifactMatrixSlide } from "./pages/ArtifactMatrixSlide";
import { ArtifactRegistrySlide } from "./pages/ArtifactRegistrySlide";
import { LitigationIntelligenceSlide } from "./pages/LitigationIntelligenceSlide";
import { LitigationFlowSlide } from "./pages/LitigationFlowSlide";
import { WorkflowMapSlide } from "./pages/WorkflowMapSlide";

export const router = createBrowserRouter([
  // ROOT BLOCKED - No Layout, just blocked message
  {
    path: "/",
    element: (
      <div className="flex items-center justify-center h-screen w-screen" style={{ backgroundColor: '#0A0E1A' }}>
        <div className="text-center px-6">
          <div className="mb-6" style={{ color: '#4A90E2' }}>
            <svg className="mx-auto h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold mb-4" style={{ color: '#FFFFFF' }}>Access Restricted</h1>
          <p className="text-lg mb-2" style={{ color: '#A0AEC0' }}>This portal is private and requires authorization.</p>
          <p className="text-sm" style={{ color: '#718096' }}>Contact the administrator for access credentials.</p>
        </div>
      </div>
    ),
  },
  // ALL CONTENT UNDER /final/ WITH LAYOUT
  {
    path: "/final",
    Component: Layout,
    children: [
      // ALL CONTENT MOVED TO /final/ PREFIX
      { path: "welcome", Component: Welcome },
      { path: "what-this-is", Component: WhatThisIs },
      { path: "what-this-changes", Component: WhatThisChanges },
      { path: "core-capabilities", Component: CoreCapabilities },
      { path: "workflow", Component: Workflow },
      { path: "agent-program-map", Component: AgentProgramMap },
      { path: "evidentiary", Component: Evidentiary },
      { path: "system-governance", Component: SystemGovernance },
      { path: "engineering", Component: EngineeringFoundation },
      
      // EXECUTIVE SLIDES UNDER /final/
      { path: "presentation", Component: PresentationIndex },
      { path: "platform-architecture", Component: PlatformArchitectureSlide },
      { path: "tech-architecture", Component: TechArchitectureSlide },
      { path: "tech-stack", Component: TechStackSlide },
      { path: "litigation-engine", Component: LitigationEngineSlide },
      { path: "dikw-strategy", Component: DIKWStrategySlide },
      { path: "data-architecture", Component: DataArchitectureSlide },
      { path: "evidence-pressure", Component: EvidencePressureSlide },
      { path: "spine-brain-architecture", Component: SpineBrainArchitectureSlide },
      { path: "spine-brain-concept", Component: SpineBrainConceptSlide },
      { path: "spine-detail", Component: SpineArchitectureDetailSlide },
      { path: "brain-detail", Component: BrainArchitectureDetailSlide },
      { path: "litigation-workflow", Component: LitigationWorkflowSlide },
      { path: "artifact-matrix", Component: ArtifactMatrixSlide },
      { path: "artifact-registry", Component: ArtifactRegistrySlide },
      { path: "litigation-intelligence", Component: LitigationIntelligenceSlide },
      { path: "litigation-flow", Component: LitigationFlowSlide },
      { path: "workflow-map", Component: WorkflowMapSlide },
      { path: "development", Component: DevelopmentStatus },
      { path: "leadership", Component: LeadershipInput },
    ],
  },
]);