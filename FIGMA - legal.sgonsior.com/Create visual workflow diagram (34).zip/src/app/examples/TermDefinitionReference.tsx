import { TermDefinition, TermIcon } from "../components/TermDefinition";

/**
 * TERM DEFINITION SYSTEM - QUICK REFERENCE
 * 
 * This component provides elegant hover definitions throughout the app.
 * It's fully responsive and follows strict brand discipline.
 */

// ============================================================================
// VARIANT 1: INLINE (Default - Subtle Dotted Underline)
// ============================================================================

export function InlineVariantExample() {
  return (
    <p>
      The system uses{" "}
      <TermDefinition 
        term="state machine"
        definition="Deterministic workflow controller ensuring proper stage transitions"
      />
      {" "}to manage case progression through five stages.
    </p>
  );
}

// Result: "state machine" appears with subtle dotted underline
//         Hover shows dark navy tooltip with definition


// ============================================================================
// VARIANT 2: UNDERLINE (Bold Blue - For Emphasis)
// ============================================================================

export function UnderlineVariantExample() {
  return (
    <p>
      Each case relies on a{" "}
      <TermDefinition 
        term="Evidence Foundation Packet"
        definition="Atomic unit containing facts, evidence, CA Evidence Code mappings, and admissibility assessments"
        variant="underline"
      />
      {" "}as its fundamental data structure.
    </p>
  );
}

// Result: "Evidence Foundation Packet" appears in bold blue with dotted underline
//         Hover shows tooltip


// ============================================================================
// VARIANT 3: ICON (Help Icon - For Diagrams/Tight Spaces)
// ============================================================================

export function IconVariantExample() {
  return (
    <div>
      <h4>
        Spine Architecture{" "}
        <TermDefinition 
          term=""
          definition="Provides five core functions: state management, evidence storage, integrity checks, audit trails, and lookup services"
          variant="icon"
        />
      </h4>
    </div>
  );
}

// Result: Small help icon (?) appears after text
//         Hover shows tooltip


// ============================================================================
// TERM ICON ONLY (For Diagrams)
// ============================================================================

export function TermIconOnlyExample() {
  return (
    <div className="flex items-center gap-2">
      <span>Layer 2: Workflow</span>
      <TermIcon 
        definition="Orchestrates deterministic state transitions between case stages"
        size={14}
      />
    </div>
  );
}

// Result: Just the help icon, no term text
//         Perfect for tight diagram labels


// ============================================================================
// POSITION CONTROL
// ============================================================================

export function PositionControlExample() {
  return (
    <div className="space-y-8">
      {/* Top positioned (default) */}
      <div>
        <TermDefinition 
          term="Default positioning"
          definition="Tooltip appears above the term"
          position="top"
        />
      </div>

      {/* Bottom positioned */}
      <div>
        <TermDefinition 
          term="Bottom positioning"
          definition="Tooltip appears below the term"
          position="bottom"
        />
      </div>

      {/* Left positioned */}
      <div className="text-right">
        <TermDefinition 
          term="Left positioning"
          definition="Tooltip appears to the left"
          position="left"
        />
      </div>

      {/* Right positioned */}
      <div>
        <TermDefinition 
          term="Right positioning"
          definition="Tooltip appears to the right"
          position="right"
        />
      </div>
    </div>
  );
}


// ============================================================================
// REAL-WORLD EXAMPLES
// ============================================================================

// Example 1: In a paragraph
export function ParagraphExample() {
  return (
    <p style={{ color: 'var(--text-primary)' }}>
      The{" "}
      <TermDefinition 
        term="Litigation Lifecycle Engine"
        definition="Five-stage workflow system that transforms raw case intake into court-ready litigation artifacts"
        variant="underline"
      />
      {" "}processes cases through{" "}
      <TermDefinition 
        term="moment-of-truth deliverables"
        definition="Critical legal outputs required at specific points: complaints, discovery responses, deposition prep"
      />
      {" "}at each stage.
    </p>
  );
}

// Example 2: In a list
export function ListExample() {
  return (
    <ul className="space-y-2">
      <li>
        <TermDefinition 
          term="State Management"
          definition="Controls workflow transitions with deterministic logic and version tracking"
          variant="underline"
        />
      </li>
      <li>
        <TermDefinition 
          term="Evidence Storage"
          definition="Immutable repository for all case artifacts with cryptographic fingerprinting"
          variant="underline"
        />
      </li>
      <li>
        <TermDefinition 
          term="Audit Trail"
          definition="Append-only log of all system operations for compliance and defensibility"
          variant="underline"
        />
      </li>
    </ul>
  );
}

// Example 3: In a technical description
export function TechnicalExample() {
  return (
    <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)' }}>
      <h4 className="mb-3">Evidence Transformation Pipeline</h4>
      <p style={{ color: 'var(--text-primary)' }}>
        Raw facts enter the{" "}
        <TermDefinition 
          term="Intake Lobe"
          definition="First brain component that structures client information into validated evidence packets"
          variant="inline"
        />
        , undergo{" "}
        <TermDefinition 
          term="rule evaluation"
          definition="Systematic assessment against CA Evidence Code sections for admissibility"
          variant="inline"
        />
        {" "}in the{" "}
        <TermDefinition 
          term="Rule Evaluation Lobe"
          definition="Second brain component that applies evidentiary rules and hearsay exceptions"
          variant="inline"
        />
        , and finally reach the{" "}
        <TermDefinition 
          term="Output Construction Lobe"
          definition="Third brain component that generates court-ready complaints and motions"
          variant="inline"
        />
        .
      </p>
    </div>
  );
}

// Example 4: In a diagram label
export function DiagramExample() {
  return (
    <div className="grid grid-cols-3 gap-4">
      <DiagramBox 
        label={
          <div className="flex items-center gap-2 justify-center">
            <span>Layer 1</span>
            <TermIcon definition="Human governance and authorization layer" />
          </div>
        }
      />
      <DiagramBox 
        label={
          <div className="flex items-center gap-2 justify-center">
            <span>Layer 2</span>
            <TermIcon definition="Workflow orchestration and state control" />
          </div>
        }
      />
      <DiagramBox 
        label={
          <div className="flex items-center gap-2 justify-center">
            <span>Layer 3</span>
            <TermIcon definition="AI agents performing structured legal work" />
          </div>
        }
      />
    </div>
  );
}

function DiagramBox({ label }: { label: React.ReactNode }) {
  return (
    <div 
      className="p-4 rounded-lg border-2 text-sm"
      style={{ 
        borderColor: 'var(--primary-blue)', 
        backgroundColor: 'var(--white)' 
      }}
    >
      {label}
    </div>
  );
}


// ============================================================================
// STYLING NOTES
// ============================================================================

/*
TOOLTIP STYLING:
- Background: var(--deep-navy) - Dark navy for contrast
- Text: var(--white) - White for readability
- Border: rgba(255, 255, 255, 0.1) - Subtle light border
- Padding: 0.75rem (12px) - Comfortable reading space
- Border radius: 0.5rem (8px) - Rounded corners
- Max width: 16rem (256px) - Prevents too-wide tooltips
- Font size: 0.75rem (12px) - Readable but not overwhelming

ANIMATION:
- Duration: 150ms - Quick but not jarring
- Easing: Built-in Motion easing
- Transform: Slight scale (0.95 → 1.0)
- Opacity: 0 → 1

TERM STYLING:
- Inline: Subtle gray dotted underline
- Underline: Bold blue with blue dotted underline
- Icon: Help circle icon in primary blue, 60% opacity

ACCESSIBILITY:
- Cursor changes to "help" on hover
- Works with keyboard focus
- Sufficient color contrast
- Clear visual hierarchy
*/


// ============================================================================
// WHEN TO USE
// ============================================================================

/*
✅ USE FOR:
- Technical terms (State Machine, Brain Lobe, Spine Function)
- Legal terms (COA, Evidence Foundation Packet, Hearsay Exception)
- System concepts (Governed Program, Controlled Rerun, Fingerprint)
- Architecture terms (Layer 2 Workflow, Manifest, Audit Trail)

❌ DON'T USE FOR:
- Common words everyone knows
- Terms already defined in context nearby
- Navigation elements
- Button labels
- Page titles
*/


// ============================================================================
// BEST PRACTICES
// ============================================================================

/*
1. DEFINITION LENGTH
   - Keep definitions concise (1-2 sentences)
   - Focus on "what it is" and "why it matters"
   - Avoid jargon in definitions

2. VARIANT SELECTION
   - Use "inline" for casual mentions
   - Use "underline" for first mention or emphasis
   - Use "icon" in diagrams or when space is tight

3. PLACEMENT
   - Don't overuse - only define unclear terms
   - Place on first mention of term per page
   - Consider whether term needs definition for audience

4. DEFINITION STYLE
   - Be specific and clear
   - Avoid circular definitions
   - Focus on practical meaning

GOOD: "State Machine Controller" → "Orchestrates workflow transitions between stages"
BAD:  "State Machine Controller" → "A controller that controls state machines"
*/


// ============================================================================
// COMPONENT API REFERENCE
// ============================================================================

interface TermDefinitionProps {
  term: string | ReactNode;          // The term to define
  definition: string;                 // The definition (1-2 sentences)
  variant?: "inline" | "icon" | "underline";  // Visual style
  position?: "top" | "bottom" | "left" | "right";  // Tooltip position
  className?: string;                 // Optional additional classes
}

interface TermIconProps {
  definition: string;                 // The definition
  size?: number;                      // Icon size in pixels (default: 14)
}
