import { motion } from "motion/react";
import { Link } from "react-router";

/**
 * Example: Adding TermDefinition to a Slide
 * 
 * This demonstrates how to enhance any slide with hover definitions
 */

// 1. Import the component
import { TermDefinition } from "../components/TermDefinition";

export function ExampleSlideWithTerms() {
  return (
    <div className="space-y-6">
      {/* Example 1: In paragraph text */}
      <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)' }}>
        <h3 className="mb-3">Evidence Foundation</h3>
        <p style={{ color: 'var(--text-primary)' }}>
          The system processes evidence through a{" "}
          <TermDefinition 
            term="three-layer architecture"
            definition="Spine (infrastructure), Brain (transformation), and Output (artifacts)"
            variant="inline"
          />
          {" "}that ensures every legal output is{" "}
          <TermDefinition 
            term="traceable"
            definition="Can be traced back to original evidence with complete audit trail"
            variant="underline"
          />
          {" "}to its source.
        </p>
      </div>

      {/* Example 2: In a list */}
      <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)' }}>
        <h3 className="mb-3">Core Functions</h3>
        <ul className="space-y-2">
          <li>
            <TermDefinition 
              term="State Management"
              definition="Controls workflow transitions between case stages with deterministic logic"
              variant="underline"
            />
          </li>
          <li>
            <TermDefinition 
              term="Evidence Fingerprinting"
              definition="Creates immutable hash signatures of all evidence for integrity verification"
              variant="underline"
            />
          </li>
          <li>
            <TermDefinition 
              term="Audit Trail Generation"
              definition="Maintains append-only log of all system operations for compliance"
              variant="underline"
            />
          </li>
        </ul>
      </div>

      {/* Example 3: In a diagram or label */}
      <div className="grid grid-cols-3 gap-4">
        <DiagramBox 
          title={
            <TermDefinition 
              term="Layer 1: Spine"
              definition="Provides infrastructure services: state, storage, integrity, audit, lookup"
              variant="icon"
            />
          }
          color="#336699"
        />
        <DiagramBox 
          title={
            <TermDefinition 
              term="Layer 2: Brain"
              definition="Transforms evidence through three specialized lobes"
              variant="icon"
            />
          }
          color="#6B46C1"
        />
        <DiagramBox 
          title={
            <TermDefinition 
              term="Layer 3: Output"
              definition="Generates court-ready litigation artifacts"
              variant="icon"
            />
          }
          color="#000033"
        />
      </div>

      {/* Example 4: In technical descriptions */}
      <div className="p-6 rounded-lg border" style={{ backgroundColor: 'var(--white)' }}>
        <h3 className="mb-3">Technical Architecture</h3>
        <p style={{ color: 'var(--text-primary)' }}>
          The{" "}
          <TermDefinition 
            term="Evidence Foundation Packet (EFP)"
            definition="Atomic unit containing: facts, source evidence, CA Evidence Code mappings, and admissibility assessments"
            variant="underline"
          />
          {" "}serves as the foundational data structure. Each EFP undergoes{" "}
          <TermDefinition 
            term="Rule Evaluation"
            definition="Systematic assessment against CA Evidence Code sections 350-356 and hearsay exceptions"
            variant="inline"
          />
          {" "}before being made available to the{" "}
          <TermDefinition 
            term="Output Construction Layer"
            definition="System component that generates complaints, motions, and discovery responses"
            variant="inline"
          />
          .
        </p>
      </div>

      {/* Example 5: In a table/grid */}
      <div className="grid md:grid-cols-2 gap-6">
        <FeatureCard 
          title={
            <TermDefinition 
              term="Deterministic Execution"
              definition="Same inputs always produce same outputs - no random behavior"
              variant="underline"
            />
          }
          description="Ensures reproducibility for evidentiary defensibility"
        />
        <FeatureCard 
          title={
            <TermDefinition 
              term="Append-Only Audit"
              definition="All system events are logged in an immutable, time-ordered sequence"
              variant="underline"
            />
          }
          description="Prevents silent mutation and supports compliance"
        />
      </div>
    </div>
  );
}

// Helper components for examples
function DiagramBox({ title, color }: { title: React.ReactNode; color: string }) {
  return (
    <div 
      className="p-4 rounded-lg border-2 text-center"
      style={{ borderColor: color, backgroundColor: 'var(--white)' }}
    >
      <div className="text-sm font-semibold" style={{ color }}>
        {title}
      </div>
    </div>
  );
}

function FeatureCard({ title, description }: { title: React.ReactNode; description: string }) {
  return (
    <div className="p-5 rounded-lg border" style={{ backgroundColor: 'var(--white)' }}>
      <h4 className="mb-2">{title}</h4>
      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
        {description}
      </p>
    </div>
  );
}
