import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router";
import { getAdjacentSlides, isSlide } from "../config/slideNavigation";

const routes = [
  "/",
  "/video",
  "/what-this-is",
  "/what-this-changes",
  "/core-capabilities",
  "/workflow",
  "/agent-program-map",
  "/evidentiary",
  "/system-governance",
  "/engineering",
  "/development",
  "/leadership",
];

export function useKeyboardNavigation() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Only trigger if no input/textarea is focused
      if (
        document.activeElement?.tagName === "INPUT" ||
        document.activeElement?.tagName === "TEXTAREA"
      ) {
        return;
      }

      // Check if current page is a slide - use slide navigation
      if (isSlide(location.pathname)) {
        const { prev, next } = getAdjacentSlides(location.pathname);
        
        if (e.key === "ArrowRight" || e.key === "ArrowDown") {
          e.preventDefault();
          if (next) {
            navigate(next.path);
          }
        } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
          e.preventDefault();
          if (prev) {
            navigate(prev.path);
          }
        } else if (e.key === "Home") {
          e.preventDefault();
          navigate("/presentation");
        }
        return;
      }

      // Standard navigation for non-slide pages
      const currentIndex = routes.indexOf(location.pathname);

      // Arrow keys for navigation
      if (e.key === "ArrowRight" || e.key === "ArrowDown") {
        e.preventDefault();
        const nextIndex = Math.min(currentIndex + 1, routes.length - 1);
        if (nextIndex !== currentIndex) {
          navigate(routes[nextIndex]);
        }
      } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
        e.preventDefault();
        const prevIndex = Math.max(currentIndex - 1, 0);
        if (prevIndex !== currentIndex) {
          navigate(routes[prevIndex]);
        }
      } else if (e.key === "Home") {
        e.preventDefault();
        navigate("/");
      } else if (e.key === "End") {
        e.preventDefault();
        navigate(routes[routes.length - 1]);
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [location.pathname, navigate]);
}