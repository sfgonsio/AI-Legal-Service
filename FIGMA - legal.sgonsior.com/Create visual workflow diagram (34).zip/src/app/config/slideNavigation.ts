// Slide Navigation Configuration
// Defines the presentation flow for all SL slides
// Story Arc: Problem → Concept → Transformation → Architecture → Implementation

export interface SlideConfig {
  id: string;
  path: string;
  label: string;
  shortLabel: string;
  order: number;
}

export const SLIDE_SEQUENCE: SlideConfig[] = [
  // PART 1: FOUNDATIONAL OVERVIEW (The Problem & Solution)
  {
    id: "sl-1",
    path: "/final/platform-architecture",
    label: "SL-1: Platform Architecture Overview",
    shortLabel: "Platform Architecture Overview",
    order: 1,
  },
  {
    id: "sl-16",
    path: "/final/litigation-intelligence",
    label: "SL-16: Litigation Intelligence Engine",
    shortLabel: "Litigation Intelligence Engine",
    order: 2,
  },
  {
    id: "sl-17",
    path: "/final/litigation-flow",
    label: "SL-17: Litigation Intelligence Flow",
    shortLabel: "Litigation Intelligence Flow",
    order: 3,
  },
  {
    id: "sl-18",
    path: "/final/workflow-map",
    label: "SL-18: Litigation Workflow Map",
    shortLabel: "Litigation Workflow Map",
    order: 4,
  },
  
  // PART 2: CONCEPTUAL FRAMEWORK (How Evidence Becomes Leverage)
  {
    id: "sl-3",
    path: "/final/dikw-strategy",
    label: "SL-3: Evidence Transformation (DIKW)",
    shortLabel: "Evidence Transformation (DIKW)",
    order: 5,
  },
  {
    id: "sl-4",
    path: "/final/data-architecture",
    label: "SL-4: Litigation Leverage Model",
    shortLabel: "Litigation Leverage Model",
    order: 6,
  },
  {
    id: "sl-5",
    path: "/final/evidence-pressure",
    label: "SL-5: Admissibility Leverage",
    shortLabel: "Admissibility Leverage",
    order: 7,
  },
  
  // PART 3: SYSTEM EXECUTION (The Lifecycle)
  {
    id: "sl-2",
    path: "/final/litigation-engine",
    label: "SL-2: Litigation Lifecycle Engine",
    shortLabel: "Litigation Lifecycle Engine",
    order: 8,
  },
  {
    id: "sl-13",
    path: "/final/litigation-workflow",
    label: "SL-13: Litigation Workflow Stages",
    shortLabel: "Litigation Workflow Stages",
    order: 9,
  },
  {
    id: "sl-14",
    path: "/final/artifact-matrix",
    label: "SL-14: Artifact Production Matrix",
    shortLabel: "Artifact Production Matrix",
    order: 10,
  },
  {
    id: "sl-15",
    path: "/final/artifact-registry",
    label: "SL-15: Canonical Artifact Registry",
    shortLabel: "Canonical Artifact Registry",
    order: 11,
  },
  
  // PART 4: SPINE & BRAIN ARCHITECTURE (Core System Design)
  {
    id: "sl-9",
    path: "/final/spine-brain-concept",
    label: "SL-9: Spine & Brain Concept",
    shortLabel: "Spine & Brain Concept",
    order: 12,
  },
  {
    id: "sl-8",
    path: "/final/spine-brain-architecture",
    label: "SL-8: Spine & Brain Architecture",
    shortLabel: "Spine & Brain Architecture",
    order: 13,
  },
  {
    id: "sl-10",
    path: "/final/spine-detail",
    label: "SL-10: Spine Architecture Deep Dive",
    shortLabel: "Spine Architecture Deep Dive",
    order: 14,
  },
  {
    id: "sl-11",
    path: "/final/brain-detail",
    label: "SL-11: Brain Architecture Deep Dive",
    shortLabel: "Brain Architecture Deep Dive",
    order: 15,
  },
  
  // PART 5: TECHNICAL IMPLEMENTATION (How We Build It)
  {
    id: "sl-6",
    path: "/final/tech-architecture",
    label: "SL-6: Technical Architecture Diagram",
    shortLabel: "Technical Architecture Diagram",
    order: 16,
  },
  {
    id: "sl-7",
    path: "/final/tech-stack",
    label: "SL-7: Technology Stack",
    shortLabel: "Technology Stack",
    order: 17,
  },
  
  // PART 6: DEVELOPMENT & INPUT (Status and Feedback)
  {
    id: "dev",
    path: "/final/development",
    label: "Development Status",
    shortLabel: "Development Status",
    order: 18,
  },
  // HIDDEN: Slide 19 needs attorney ask update
  // {
  //   id: "leadership",
  //   path: "/final/leadership",
  //   label: "Leadership Input",
  //   shortLabel: "Leadership Input",
  //   order: 19,
  // },
];

// Helper function to get prev/next slides
export function getAdjacentSlides(currentPath: string): {
  prev: SlideConfig | null;
  next: SlideConfig | null;
} {
  const currentIndex = SLIDE_SEQUENCE.findIndex(slide => slide.path === currentPath);
  
  if (currentIndex === -1) {
    return { prev: null, next: null };
  }

  return {
    prev: currentIndex > 0 ? SLIDE_SEQUENCE[currentIndex - 1] : null,
    next: currentIndex < SLIDE_SEQUENCE.length - 1 ? SLIDE_SEQUENCE[currentIndex + 1] : null,
  };
}

// Get current slide info
export function getCurrentSlide(path: string): SlideConfig | null {
  return SLIDE_SEQUENCE.find(slide => slide.path === path) || null;
}

// Check if a path is a slide
export function isSlide(path: string): boolean {
  return SLIDE_SEQUENCE.some(slide => slide.path === path);
}