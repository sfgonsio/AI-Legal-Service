Business Capability Architecture — Litigation Engine

Subtitle:

Governed intelligence across the litigation lifecycle.

⚡ POWER MOVE #1 — The Lifecycle Spine

Instead of a row of small boxes…

We create a single dominant horizontal spine across the center of the slide.

A 120px tall deep navy bar (#000033).

White text, evenly spaced:

INTERVIEW   →   EVIDENCE   →   MAPPING   →   COA   →   DISCOVERY   →   TRIAL

Not small.
Not timid.

Large. Confident. Centered.

This becomes the engine of the slide.

Everything else supports this spine.

This is the “THIS IS AWESOME” anchor.

⚡ POWER MOVE #2 — Vertical Precision Columns

From each lifecycle stage, drop a perfectly straight 2px line downward.

No arrowheads.

These vertical lines connect to two structured layers:

AI Reasoning Agents

Deterministic Programs

Visually, it feels engineered.

Not flowchart.
Not process diagram.

Like a machine.

⚡ POWER MOVE #3 — Foundation Slab

At the bottom of the slide:

A full-width 100px white slab with 2px navy top border.

Inside, evenly spaced:

Structured Fact Store
Entity Registry
Document Vault
Audit Ledger
Artifact Registry

This slab feels like bedrock.

It visually says:

Everything rests on traceable persistence.

That’s powerful.

⚡ POWER MOVE #4 — Subtle Governance Shadow

At the top of the slide:

A thin 60px navy band with white text:

Governed by Contract v1 • Deterministic Execution • Audit-Enforced

This ties back to Slide 21 and visually casts authority over the lifecycle spine.

🧱 FINAL STRUCTURE (Clean, Engineered)
[ Governance Band ]

        INTERVIEW → EVIDENCE → MAPPING → COA → DISCOVERY → TRIAL
              │           │          │        │            │
              │           │          │        │            │
        AI Agents aligned below each stage
              │           │          │        │            │
        Deterministic Programs aligned below
---------------------------------------------------------------
              Structured Data & Audit Foundation

No clouds.
No cylinders.
No clutter.

But visually bold.

🎨 WHY THIS WORKS

It feels:

• Mechanical
• Layered
• Engineered
• Scalable
• Governed
• Unstoppable

It doesn’t scream hype.

It whispers inevitability.

That’s stronger.

🧠 WHAT MAKES PEOPLE REACT

When they see this slide they’ll think:

“Oh, this is modular.”

“Oh, this enforces discipline.”

“Oh, this isn’t just AI.”

“Oh… this could run litigation.”

That’s the reaction you want.

🎯 Figma Instruction (Power Version)

Paste this:

Create a 1440px slide using 12-column grid, 96px margins, 24px gutters.

Background: #F4F6F8
Primary fill: #000033
Borders: #C0C5CE

Add a thin top band (60px) filled #000033 with white text:
“Governed by Contract v1 • Deterministic Execution • Audit-Enforced”

Create a central 120px tall navy lifecycle spine with white text:
INTERVIEW → EVIDENCE → MAPPING → COA → DISCOVERY → TRIAL

Drop 2px vertical navy lines from each lifecycle stage downward.

Under lifecycle spine, add row labeled:
AI Reasoning Agents (aligned under each stage)

Under that, add row labeled:
Deterministic Programs (aligned under each stage)

Add full-width bottom slab with 2px navy top border labeled:
Structured Data & Audit Foundation

No icons.
No cloud imagery.
No gradients.
No decorative arrows.
Minimal text.
Perfect alignment.

Tone: Institutional, engineered, inevitable.