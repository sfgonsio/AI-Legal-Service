import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";

const LIFECYCLE_STAGES = [
  { id: "interview", label: "INTERVIEW", agent: "Interview Agent", program: "Intake Validator" },
  { id: "evidence", label: "EVIDENCE", agent: "Processing Agent", program: "Evidence Parser" },
  { id: "mapping", label: "MAPPING", agent: "Mapping Agent", program: "Element Matcher" },
  { id: "coa", label: "COA", agent: "COA Agent", program: "Claim Builder" },
  { id: "discovery", label: "DISCOVERY", agent: "Discovery Agent", program: "Doc Generator" },
  { id: "trial", label: "TRIAL", agent: "Trial Agent", program: "Brief Compiler" },
];

const FOUNDATION_MODULES = [
  "Structured Fact Store",
  "Entity Registry",
  "Document Vault",
  "Audit Ledger",
  "Artifact Registry",
];

export function LitigationEngineArchitecture() {
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const active = activeStage
    ? LIFECYCLE_STAGES.find((s) => s.id === activeStage) ?? null
    : null;

  return (
    <div className="relative" style={{ minHeight: "700px" }}>
      {/* NOTE: if SlideShell now provides max width + padding, remove the next wrapper */}
      <div className="w-full max-w-[1440px] mx-auto px-24">
        {/* If SlideShell renders titles, remove this title block entirely */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          className="mb-10 text-center"
        >
          <h1 className="font-bold tracking-tight" style={{ color: "#000033", fontSize: "40px", lineHeight: "44px" }}>
            Business Capability Architecture — Litigation Engine
          </h1>
          <p className="mt-3" style={{ color: "rgba(0,0,51,0.72)", fontSize: "18px", lineHeight: "26px" }}>
            Governed intelligence across the litigation lifecycle.
          </p>
        </motion.div>

        <div className="relative" style={{ minHeight: "700px" }}>
          {/* Governance Band */}
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.1 }}
            className="mb-8 flex items-center justify-center"
            style={{
              height: "60px",
              backgroundColor: "#000033",
              borderRadius: "12px",
            }}
          >
            <div className="flex items-center gap-4 text-white text-sm font-medium tracking-wide">
              <span>Governed by Contract v1</span>
              <span style={{ opacity: 0.45 }}>•</span>
              <span>Deterministic Execution</span>
              <span style={{ opacity: 0.45 }}>•</span>
              <span>Audit-Enforced</span>
              <span style={{ opacity: 0.45 }}>•</span>
              <span style={{ opacity: 0.9, letterSpacing: "0.08em" }}>
                AGENTS PROPOSE. PROGRAMS COMMIT.
              </span>
            </div>
          </motion.div>

          {/* Lifecycle Spine */}
          <motion.div
            initial={{ opacity: 0, scaleX: 0.92 }}
            animate={{ opacity: 1, scaleX: 1 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="relative mb-10"
            style={{
              height: "120px",
              backgroundColor: "#000033",
              borderRadius: "12px",
              border: "1px solid rgba(255,255,255,0.18)",
            }}
          >
            <div className="relative h-full flex items-center justify-around px-8">
              {LIFECYCLE_STAGES.map((stage, index) => (
                <motion.div
                  key={stage.id}
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.45, delay: 0.45 + index * 0.06 }}
                  className="flex items-center gap-3 cursor-pointer"
                  onMouseEnter={() => setActiveStage(stage.id)}
                  onMouseLeave={() => setActiveStage(null)}
                >
                  {/* disciplined marker */}
                  <div
                    style={{
                      width: "8px",
                      height: "8px",
                      borderRadius: "999px",
                      backgroundColor: activeStage === stage.id ? "#FFFFFF" : "rgba(255,255,255,0.28)",
                      transition: "all 140ms ease",
                    }}
                  />
                  <span
                    className="font-bold"
                    style={{
                      fontSize: "18px",
                      letterSpacing: "0.10em",
                      color: activeStage === stage.id ? "#FFFFFF" : "rgba(255,255,255,0.88)",
                      transition: "all 140ms ease",
                    }}
                  >
                    {stage.label}
                  </span>
                  {index < LIFECYCLE_STAGES.length - 1 && (
                    <span style={{ marginLeft: "12px", color: "rgba(255,255,255,0.35)", fontSize: "22px" }}>→</span>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Columns: Agents + Programs */}
          <div className="relative mb-10" style={{ minHeight: "280px" }}>
            <div className="grid grid-cols-6 gap-0">
              {LIFECYCLE_STAGES.map((stage, index) => {
                const isActive = activeStage === stage.id;
                return (
                  <motion.div
                    key={stage.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.45, delay: 0.75 + index * 0.05 }}
                    className="flex flex-col items-center"
                  >
                    {/* Precision line */}
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: "40px" }}
                      transition={{ duration: 0.55, delay: 0.85 + index * 0.05, ease: "easeOut" }}
                      style={{ width: "2px", backgroundColor: "#000033", marginBottom: "16px" }}
                    />

                    {/* AI Agent card */}
                    <div
                      className="w-full mb-4 p-4 rounded-lg cursor-pointer"
                      onMouseEnter={() => setActiveStage(stage.id)}
                      onMouseLeave={() => setActiveStage(null)}
                      style={{
                        backgroundColor: "#FFFFFF",
                        border: `2px solid ${isActive ? "#000033" : "#C0C5CE"}`,
                        transition: "all 140ms ease",
                      }}
                    >
                      <div
                        className="text-xs uppercase tracking-wide mb-1"
                        style={{ color: "rgba(0,0,51,0.62)" }}
                      >
                        AI Agent
                      </div>
                      <div className="text-sm font-semibold" style={{ color: "#000033" }}>
                        {stage.agent}
                      </div>
                    </div>

                    {/* Connector */}
                    <div style={{ width: "2px", height: "20px", backgroundColor: "#C0C5CE", marginBottom: "8px" }} />

                    {/* Program card */}
                    <div
                      className="w-full p-4 rounded-lg cursor-pointer"
                      onMouseEnter={() => setActiveStage(stage.id)}
                      onMouseLeave={() => setActiveStage(null)}
                      style={{
                        backgroundColor: "#FFFFFF",
                        border: `2px solid ${isActive ? "#000033" : "#C0C5CE"}`,
                        transition: "all 140ms ease",
                      }}
                    >
                      <div
                        className="text-xs uppercase tracking-wide mb-1"
                        style={{ color: "rgba(0,0,51,0.62)" }}
                      >
                        Program
                      </div>
                      <div className="text-sm font-semibold" style={{ color: "#000033" }}>
                        {stage.program}
                      </div>
                    </div>

                    {/* Down line to foundation */}
                    <div style={{ width: "2px", height: "40px", backgroundColor: "#C0C5CE", marginTop: "16px" }} />
                  </motion.div>
                );
              })}
            </div>

            {/* Anchored callout (not floating) */}
            <AnimatePresence>
              {active && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.18 }}
                  className="mt-6 mx-auto text-center"
                  style={{
                    maxWidth: "960px",
                    border: "1px solid #C0C5CE",
                    borderRadius: "12px",
                    backgroundColor: "#FFFFFF",
                    padding: "12px 16px",
                    color: "#000033",
                  }}
                >
                  <span className="font-bold" style={{ letterSpacing: "0.08em" }}>
                    {active.label}
                  </span>
                  <span style={{ opacity: 0.7 }}> — </span>
                  <span style={{ opacity: 0.85 }}>
                    Agent reasoning triggers deterministic execution, producing audited, reproducible outputs.
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Foundation Slab */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 1.05 }}
            className="relative"
            style={{
              height: "100px",
              backgroundColor: "#FFFFFF",
              borderTop: "2px solid #000033",
              borderRadius: "0 0 12px 12px",
              borderLeft: "1px solid #C0C5CE",
              borderRight: "1px solid #C0C5CE",
              borderBottom: "1px solid #C0C5CE",
            }}
          >
            <div className="relative h-full flex items-center justify-around px-8">
              <div className="text-xs uppercase tracking-wider font-bold" style={{ color: "rgba(0,0,51,0.62)" }}>
                Foundation
              </div>
              {FOUNDATION_MODULES.map((module) => (
                <div key={module} className="flex items-center gap-2">
                  <div
                    style={{
                      width: "6px",
                      height: "6px",
                      borderRadius: "999px",
                      backgroundColor: "#000033",
                      opacity: 0.9,
                    }}
                  />
                  <span className="text-sm font-semibold" style={{ color: "#000033" }}>
                    {module}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}