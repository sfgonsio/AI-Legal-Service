import { motion } from "motion/react";

// Slide 54 — Architectural Principles (Governed)
export function PlatformArchitecture() {
  return (
    <div
      className="w-full flex items-center justify-center py-12 px-6"
      style={{ backgroundColor: "#F4F6F8" }}
    >
      {/* Frame Width: 1440px, 12-col grid feel with 96px margins */}
      <div className="w-full max-w-[1440px] mx-auto px-24">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative mx-auto"
          style={{ maxWidth: "960px" }}
        >
          {/* Title & Subtitle */}
          <div className="mb-10 text-center">
            <h1
              className="font-bold tracking-tight"
              style={{ color: "#000033", fontSize: "40px", lineHeight: "44px" }}
            >
              Architectural Principles That Govern the System
            </h1>
            <p
              className="mt-3"
              style={{
                color: "rgba(0,0,51,0.72)",
                fontSize: "18px",
                lineHeight: "26px",
              }}
            >
              Designed for control, scale, and legal defensibility.
            </p>
          </div>

          <div className="relative">
            {/* Left Spine */}
            <div
              className="absolute left-0 top-0 bottom-0 flex items-center justify-center"
              style={{
                width: "64px",
                backgroundColor: "#000033",
                transform: "translateX(-80px)",
                borderRadius: "12px 0 0 12px",
              }}
            >
              <div
                className="text-white text-xs font-semibold uppercase tracking-wider"
                style={{
                  writingMode: "vertical-rl",
                  transform: "rotate(180deg)",
                  letterSpacing: "0.15em",
                }}
              >
                Architectural Discipline
              </div>
            </div>

            {/* Right Spine */}
            <div
              className="absolute right-0 top-0 bottom-0 flex items-center justify-center"
              style={{
                width: "64px",
                backgroundColor: "#000033",
                transform: "translateX(80px)",
                borderRadius: "0 12px 12px 0",
              }}
            >
              <div
                className="text-white text-xs font-semibold uppercase tracking-wider"
                style={{
                  writingMode: "vertical-rl",
                  letterSpacing: "0.15em",
                }}
              >
                Legal Defensibility
              </div>
            </div>

            {/* Main Platform Frame */}
            <div
              className="relative"
              style={{
                backgroundColor: "#FFFFFF",
                border: "1px solid #C0C5CE",
                borderRadius: "12px",
                overflow: "hidden",
              }}
            >
              {/* SECTION 1 — GOVERNANCE BY DESIGN */}
              <div
                className="px-12 py-12 flex flex-col items-center justify-center"
                style={{
                  backgroundColor: "#000033",
                  minHeight: "280px",
                }}
              >
                <div className="w-full max-w-2xl">
                  <h2 className="text-white font-bold uppercase tracking-wide text-center"
                      style={{ fontSize: "22px", letterSpacing: "0.12em" }}>
                    Governance by Design
                  </h2>

                  {/* “Invariant” banner — the WOW without gimmicks */}
                  <div
                    className="mt-6 mb-8 px-5 py-3 text-center"
                    style={{
                      border: "1px solid rgba(255,255,255,0.25)",
                      borderRadius: "10px",
                      color: "rgba(255,255,255,0.92)",
                      fontSize: "14px",
                      letterSpacing: "0.06em",
                    }}
                  >
                    PRINCIPLES ARE CONSTRAINTS — CONSTRAINTS CREATE TRUST
                  </div>

                  <div className="grid grid-cols-2 gap-x-10 gap-y-4">
                    <PrincipleItem text="Deterministic First" inverted />
                    <PrincipleItem text="Contract Over Code" inverted />
                    <PrincipleItem text="Tool Mediation Required" inverted />
                    <PrincipleItem text="Replay Equivalence Enforced" inverted />
                  </div>

                  <p
                    className="mt-8 text-center italic"
                    style={{ color: "rgba(255,255,255,0.72)", fontSize: "14px" }}
                  >
                    Intelligence operates within declared constraints.
                  </p>
                </div>
              </div>

              {/* Divider */}
              <div style={{ height: "2px", backgroundColor: "#000033" }} />

              {/* SECTION 2 — CONFIGURABLE BUT CONTROLLED */}
              <div className="px-12 py-12" style={{ minHeight: "280px" }}>
                <h2
                  className="font-bold uppercase tracking-wide text-center"
                  style={{ color: "#000033", fontSize: "22px", letterSpacing: "0.12em" }}
                >
                  Configurable but Controlled
                </h2>

                <div className="mt-10 grid grid-cols-2 gap-12">
                  <div className="space-y-4">
                    <PrincipleItem text="Service-Oriented Architecture" />
                    <PrincipleItem text="API-Driven Integration" />
                    <PrincipleItem text="Automation Over Manual Effort" />
                    <PrincipleItem text="Microservices Compatible" />
                  </div>
                  <div className="space-y-4">
                    <PrincipleItem text="Overlay-Based Flexibility" />
                    <PrincipleItem text="Extensible Without Rewrite" />
                    <PrincipleItem text="Configurable Without Custom Chaos" />
                    <PrincipleItem text="Horizontally & Vertically Scalable" />
                  </div>
                </div>

                <p
                  className="mt-8 text-center"
                  style={{ color: "rgba(0,0,51,0.72)", fontSize: "14px" }}
                >
                  Designed to evolve without losing control.
                </p>
              </div>

              {/* Divider */}
              <div style={{ height: "2px", backgroundColor: "#000033" }} />

              {/* SECTION 3 — DATA & SECURITY FOUNDATIONAL */}
              <div className="px-12 py-12" style={{ minHeight: "280px" }}>
                <h2
                  className="font-bold uppercase tracking-wide text-center"
                  style={{ color: "#000033", fontSize: "22px", letterSpacing: "0.12em" }}
                >
                  Data & Security Foundational
                </h2>

                <div className="mt-10 grid grid-cols-2 gap-12">
                  <div className="space-y-4">
                    <PrincipleItem text="Rapid Structured Ingestion" />
                    <PrincipleItem text="Data Ownership & Interoperability" />
                    <PrincipleItem text="Searchable, Catalogued Facts" />
                    <PrincipleItem text="Lifecycle Management" />
                  </div>
                  <div className="space-y-4">
                    <PrincipleItem text="Secure by Design" />
                    <PrincipleItem text="Policy-Driven Access" />
                    <PrincipleItem text="Consent-Aware Architecture" />
                    <PrincipleItem text="Regulatory Alignment" />
                  </div>
                </div>

                <p
                  className="mt-8 text-center"
                  style={{ color: "rgba(0,0,51,0.72)", fontSize: "14px" }}
                >
                  Every fact traceable. Every action accountable.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function PrincipleItem({
  text,
  inverted = false,
}: {
  text: string;
  inverted?: boolean;
}) {
  return (
    <div className="flex items-start gap-3">
      <div
        className="mt-2 flex-shrink-0"
        style={{
          width: "7px",
          height: "7px",
          borderRadius: "999px",
          backgroundColor: inverted ? "#FFFFFF" : "#000033",
          opacity: inverted ? 0.95 : 0.9,
        }}
      />
      <p
        className="font-medium leading-relaxed"
        style={{
          color: inverted ? "#FFFFFF" : "#000033",
          fontSize: "18px",
        }}
      >
        {text}
      </p>
    </div>
  );
}