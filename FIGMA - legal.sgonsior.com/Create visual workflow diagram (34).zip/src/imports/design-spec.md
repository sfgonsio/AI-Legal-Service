Canvas

1440px width

Min 900px height

Background: #F4F6F8

12-column grid

96px margins

24px gutters

Central Platform Frame

8 columns centered (~960px)

White background

1px border #C0C5CE

12px radius

Divided into 3 equal visual-weight bands

2px #000033 divider between bands

Band 1 — Governance Core

Fill: #000033

White text

Clean two-column layout

Micro statement at bottom

No icons

No embellishment

Band 2 — Controlled Intelligence

White background

Overlay stack with 1px #C0C5CE borders

8px vertical offset

Dashed #C0C5CE container

Explicit case_config.yaml binding label

Band 3 — Case-Scoped Execution

White background

6 primary modules

2 persistence modules

Uniform card styling

Equal spacing

Small reproducibility statement

Side Spines

Fill: #000033

White vertical text

Minimal bullet text

Equal width both sides

Top & Bottom

Line icons in #000033

Thin 1px connectors

Clean portal cards

Unified interface label

🎯 Transition Discipline

Before building Slide 54, instruct Figma:

Create reusable components:

Governance Band

Overlay Stack Card

Runtime Module Card

Side Spine

Portal Card

Section Header Block

All subsequent slides must use these components.

No stylistic drift.