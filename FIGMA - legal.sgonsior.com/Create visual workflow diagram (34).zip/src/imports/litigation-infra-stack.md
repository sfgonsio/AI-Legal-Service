Technology Stack — Litigation Infrastructure

Subtitle (small, restrained):

AWS-first • Deterministic Runtime • Governed AI

LAYOUT INSTRUCTION FOR FIGMA

Use a clean layered stack format (vertical tiers or left-aligned tier rows).

Each layer includes:

Layer Name
Selected Technologies
Purpose (one sentence, restrained)

Do NOT use vendor logos unless design insists.
Use clean text blocks.

LAYER 1 — EXPERIENCE LAYER

Selected:

• React
• TypeScript
• Tailwind CSS
• shadcn/ui
• motion/react
• Vite (build system)

Purpose:

Structured, role-based client and attorney interfaces with consistent, controlled UI behavior.

LAYER 2 — IDENTITY & ACCESS CONTROL

Selected:

• AWS Cognito
• Case-scoped RBAC/ABAC enforcement
• IAM policy layering

Purpose:

Role-based access, case isolation, and privilege-aware enforcement across all workflows.

LAYER 3 — GOVERNED ORCHESTRATION RUNTIME

Selected:

• Temporal (workflow engine)
• Node.js + TypeScript services
• AWS ECS (Fargate)
• SQS + EventBridge

Purpose:

Versioned, replayable workflow orchestration.
Agents propose. Programs execute under governance.

LAYER 4 — TOOL MEDIATION GATEWAY

Selected:

• TypeScript (NestJS or Fastify)
• Contract v1 enforcement
• Tool registry validation
• Audit emission service

Purpose:

Prevents direct tool access.
Enforces role permissions, contract validation, and execution logging.

LAYER 5 — AI & TRANSCRIPTION LAYER

Selected:

• Claude (reasoning model)
• Optional secondary LLM (fallback, mediated)
• Amazon Transcribe (speech-to-text)

Purpose:

Structured reasoning and interview narration processing, fully mediated and auditable.

LAYER 6 — DETERMINISTIC PROGRAM LAYER

Selected:

• Python services (containerized)
• Docker
• ffmpeg (audio normalization)
• Structured extraction libraries

Purpose:

Hashing, parsing, evidence normalization, transcript processing, rule overlays — all deterministic and replayable.

LAYER 7 — DATA FOUNDATION

Selected:

• PostgreSQL (Structured Evidence Ledger)
• AWS S3 + Object Lock (Immutable Evidence Vault)
• OpenSearch (Search & retrieval)

Purpose:

Immutable evidence preservation.
Structured fact storage.
Searchable litigation record.

LAYER 8 — SECURITY & KEY MANAGEMENT

Selected:

• AWS KMS
• AWS Secrets Manager
• AWS WAF

Purpose:

Encryption at rest and in transit.
Key control.
Internet boundary protection.

LAYER 9 — OBSERVABILITY & AUDIT

Selected:

• OpenTelemetry
• AWS CloudWatch
• Append-only audit ledger (Postgres + S3 export)

Purpose:

Replay equivalence.
Execution traceability.
Defensible audit posture.

LAYER 10 — CI/CD & GOVERNANCE

Selected:

• GitHub
• GitHub Actions
• Terraform
• Container Registry (ECR)

Purpose:

Infrastructure as code.
Manifest enforcement.
Drift prevention via automated validation gates.

RIGHT-SIDE PANEL (SMALL)

Title:

Platform Guarantees

Include exactly:

Deterministic Execution
Hash-Locked Evidence
Tool Mediation Enforcement
Case-Scoped Isolation
Replay Equivalence
Audit Traceability

No bold graphics.
No glow.
Serious tone.

OPTIONAL SMALL FOOTER

Architected for adversarial environments.