Excellent.
Below is a **Figma-ready build instruction document** — structured so a designer can execute without interpretation drift, while still allowing creative elevation.

This is formatted for direct handoff.

---

# FIGMA BUILD SPECIFICATION

## Human-Governed Legal Intelligence Workflow Diagram

AI Legal Service — Executive Presentation Module

---

# 1. OBJECTIVE

Design an interactive, executive-level workflow diagram that:

• Visually illustrates human interaction with system agents
• Demonstrates governance at every inflection point
• Communicates evidentiary defensibility
• Shows agent orchestration without technical overload
• Reinforces that humans retain authority
• Instills confidence in structural discipline

Audience: Managing Partner (non-technical)
Tone: Institutional, modern, disciplined, warm confidence
Format: Web-enabled, scrollable, interactive

---

# 2. LAYOUT STRUCTURE

## Canvas

Frame Width: 1440px
Horizontal layout (left → right progression)
Minimum height: 900px
Allow horizontal scroll if needed

Grid: 12-column layout
Margins: 96px
Gutter: 24px

---

# 3. LAYERED ARCHITECTURE (MANDATORY)

The diagram must contain **three horizontal visual layers**, stacked vertically.

Each layer should feel distinct but connected.

---

## LAYER 1 — HUMAN GOVERNANCE (Top Band)

Height: ~200px
Background: White (#FFFFFF)

Visual Style:
• Circular nodes
• Deep Navy (#000033) fill
• White icons
• Subtle outer glow (very restrained)

Nodes (left → right):

Client
Attorney

Optional future node (lighter opacity): Paralegal

Between Client and Attorney, show directional flow arrows.

---

## LAYER 2 — PROGRAM ORCHESTRATION (Middle Band)

Height: ~300px
Background: Very light neutral (#F4F6F8)

Visual Style:
• Structured rectangular blocks
• Primary Blue (#336699)
• Slight drop shadow
• Clean sharp edges (no cartoon rounding)

Blocks (left → right):

Intake State
Validation Gate
Case Activation State
Evidence Ingestion State
COA Approval Gate
Output Release State
Rerun Control State

Each “Gate” must have:
• Small lock icon
• Slight silver border (#C0C5CE)

These represent human approval inflection points.

---

## LAYER 3 — AGENTS + EVIDENCE SYSTEM (Bottom Band)

Height: ~350px
Background: Subtle cool gradient (very light silver to white)

Visual Style:
• Rounded rectangular agent cards
• Silver or soft gray outline
• Light animated pulse (very subtle)

Agent Blocks (left → right):

INTERVIEW_AGENT
PROCESSING_AGENT
MAPPING_AGENT
OUTPUT_AGENT

Below Agents (smaller system nodes):

Evidence Store
COA Taxonomy
Audit Ledger
Fingerprint Engine

These should visually appear like foundational infrastructure.

---

# 4. FLOW CONNECTIONS

Connections must:

• Use thin Primary Blue lines
• Animate gently on load (200ms fade)
• Flow left to right

Vertical dotted connectors must link:

Agent → Program Block → Human Node

This reinforces:

Agents do not operate independently.
Program governs transitions.
Humans authorize inflection points.

---

# 5. STEP-BY-STEP FLOW SEQUENCE

This sequence must be visually represented:

Client
↓
INTERVIEW_AGENT
↓
Validation Gate
↓
Attorney Acceptance
↓
PROCESSING_AGENT
↓
Evidence Ingestion State
↓
MAPPING_AGENT
↓
COA Approval Gate
↓
OUTPUT_AGENT
↓
Attorney Review
↓
Release

Each transition must show movement through all three layers.

---

# 6. HOVER TOOLTIP CONTENT (INCLUDE)

Each node must support hover state.

Below is the exact tooltip copy to include.

---

## CLIENT → INTERVIEW_AGENT

Title:
Structured Client Intake

Body:
The Interview Agent conducts structured dialogue until sufficient factual clarity is established.

System-Level Behavior:
• Question sequencing logic
• Context validation
• Incomplete perspective detection
• Factual baseline locking

Purpose:
Establish a defensible factual foundation before downstream processing.

---

## VALIDATION GATE

Title:
Intake Completeness Verification

Body:
The program verifies structural completeness before allowing case activation.

System-Level Behavior:
• Required data verification
• Intake fingerprint generation
• Version snapshot

Purpose:
Prevent premature case activation.

---

## ATTORNEY ACCEPTANCE

Title:
Human Case Authorization

Body:
Attorney reviews intake summary and approves formal case activation.

System-Level Behavior:
• State transition logging
• Approval timestamping
• Audit record append

Purpose:
Ensure human legal judgment governs case commitment.

---

## PROCESSING_AGENT

Title:
Artifact Structuring

Body:
Uploaded artifacts are structured and normalized.

System-Level Behavior:
• Artifact hashing
• Metadata tagging
• Timestamp assignment
• Evidence indexing

Purpose:
Preserve evidentiary traceability.

---

## MAPPING_AGENT

Title:
Cause-of-Action Alignment

Body:
Evidence is aligned to COA elements.

System-Level Behavior:
• COA taxonomy reference
• Evidence-to-element linkage
• Gap detection alerts

Purpose:
Strengthen pleading defensibility.

---

## OUTPUT_AGENT

Title:
Controlled Document Generation

Body:
Structured outputs are generated based on mapped evidence.

System-Level Behavior:
• Template rendering
• Version stamping
• Fingerprint recalculation
• Output audit entry

Purpose:
Generate reproducible legal documents.

---

## RERUN CONTROL

Title:
Governed Recalculation

Body:
If new information is introduced, the system evaluates downstream impact before rerunning.

System-Level Behavior:
• Dependency recalculation
• Impact matrix evaluation
• Prior state preservation

Purpose:
Prevent silent document mutation.

---

# 7. DEFENSIBILITY SIDEBAR (RIGHT PANEL)

Add fixed vertical sidebar:

Title:
Evidentiary Defensibility Engine

Icons with labels:

Integrity Lock
Deterministic Fingerprint
Replay Validation
Append-Only Audit

Hover text:

Outputs are reproducible.
Transitions are logged.
Changes are traceable.
No silent mutation occurs.

---

# 8. MOTION SPECIFICATION

Scroll reveal: 250ms ease-out
Node hover glow: 150ms subtle
Connection pulse: 300ms fade
Gate lock shimmer: 500ms once on load

No excessive animation.

Must feel institutional, not playful.

---

# 9. VISUAL TONE REQUIREMENTS

Avoid:

• Cartoon icons
• Overly rounded playful shapes
• Excessive gradients
• Neon effects

Emphasize:

• Structure
• Discipline
• Layered depth
• Executive restraint

---

# 10. KEY MESSAGE THE DIAGRAM MUST COMMUNICATE

Agents perform structured work.
The program governs transitions.
Humans authorize critical decisions.
Evidence remains traceable.
Outputs remain defensible.

The managing partner should conclude:

“This is governed.
This is controlled.
This protects the firm.”

---

If you would like next:

• A simplified executive-only version
• A cinematic animated version spec
• Or a script that narrates while this diagram animates

This diagram will be one of the most powerful trust-building elements in the entire presentation.
