import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";

type Stage = {
  id: string;
  level: string;        // DATA / INFORMATION / KNOWLEDGE / etc
  title: string;        // Evidence Intake / Parsing / ...
  summary: string;      // 1-sentence
  bullets: [string, string, string]; // exactly 3 for horizontal alignment
};

const STAGES: Stage[] = [
  {
    id: "intake",
    level: "DATA",
    title: "Evidence Intake",
    summary: "Case-scoped capture of interview inputs and evidentiary files into an immutable boundary.",
    bullets: ["UID Assigned", "Case Isolation", "Immutable Vault Write"],
  },
  {
    id: "parse",
    level: "INFORMATION",
    title: "Structured Parsing",
    summary: "Deterministic parsing produces structured fields, chunks, and extract artifacts with lineage.",
    bullets: ["Schema Validated", "Chunk UID Created", "Replay Equivalent"],
  },
  {
    id: "facts",
    level: "KNOWLEDGE",
    title: "Fact Normalization",
    summary: "Canonical entities, dates, amounts, and assertions normalized under contract-defined rules.",
    bullets: ["Normalization Locked", "Conflict Logged", "Fact Registry Write"],
  },
  {
    id: "map",
    level: "LEGAL KNOWLEDGE",
    title: "Element Mapping",
    summary: "Facts map to legal elements under overlay binding and reviewable traceability.",
    bullets: ["Overlay Bound", "Element Trace Persisted", "Attorney Gate Ready"],
  },
  {
    id: "outputs",
    level: "STRATEGY",
    title: "Artifact Generation",
    summary: "Complaint, discovery, and trial artifacts generated with provenance and reproducibility guarantees.",
    bullets: ["Artifact Versioned", "Audit Ledger Complete", "Reproducible Output"],
  },
];

export function DataManagementApproach() {
  const [activeId, setActiveId] = useState<string | null>(null);
  const active = activeId ? STAGES.find((s) => s.id === activeId) ?? null : null;

  return (
    <div className="relative" style={{ minHeight: "720px" }}>
      {/* Silver rule for engineered feel */}
      <div style={{ height: "1px", backgroundColor: "#C0C5CE", marginBottom: "16px" }} />

      {/* Governance Band */}
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.1 }}
        className="mb-8 flex items-center justify-center"
        style={{
          height: "60px",
          backgroundColor: "#000033",
          borderRadius: "12px",
        }}
      >
        <div className="flex items-center gap-4 text-white text-sm font-medium tracking-wide">
          <span>Case-Bound Data Transformation</span>
          <span style={{ opacity: 0.45 }}>•</span>
          <span>Deterministic</span>
          <span style={{ opacity: 0.45 }}>•</span>
          <span>Overlay-Enforced</span>
          <span style={{ opacity: 0.45 }}>•</span>
          <span>Audit Logged</span>
        </div>
      </motion.div>

      {/* Main Frame */}
      <motion.div
        initial={{ opacity: 0, scaleX: 0.98 }}
        animate={{ opacity: 1, scaleX: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="relative mb-10"
        style={{
          backgroundColor: "#FFFFFF",
          border: "1px solid #C0C5CE",
          borderRadius: "12px",
          overflow: "hidden",
        }}
      >
        {/* Header row (levels) */}
        <div
          className="grid"
          style={{
            gridTemplateColumns: `repeat(${STAGES.length}, minmax(0, 1fr))`,
            borderBottom: "1px solid #C0C5CE",
          }}
        >
          {STAGES.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.3 + i * 0.06 }}
              className="px-5 py-3 text-center"
              style={{
                color: "rgba(0,0,51,0.72)",
                fontSize: "12px",
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                borderRight: i < STAGES.length - 1 ? "1px solid #C0C5CE" : "none",
              }}
            >
              {s.level}
            </motion.div>
          ))}
        </div>

        {/* Titles row */}
        <div
          className="grid"
          style={{
            gridTemplateColumns: `repeat(${STAGES.length}, minmax(0, 1fr))`,
            borderBottom: "1px solid #C0C5CE",
          }}
        >
          {STAGES.map((s, i) => {
            const isActive = activeId === s.id;
            return (
              <motion.div
                key={s.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 + i * 0.08 }}
                className="px-6 py-5 cursor-pointer"
                onMouseEnter={() => setActiveId(s.id)}
                onMouseLeave={() => setActiveId(null)}
                style={{
                  borderRight: i < STAGES.length - 1 ? "1px solid #C0C5CE" : "none",
                  borderBottom: isActive ? "2px solid #000033" : "2px solid transparent",
                  transition: "border-color 140ms ease",
                }}
              >
                <div
                  className="font-bold"
                  style={{
                    color: "#000033",
                    letterSpacing: "0.10em",
                    fontSize: "14px",
                  }}
                >
                  {s.title.toUpperCase()}
                </div>
                <div
                  className="mt-2"
                  style={{
                    color: "rgba(0,0,51,0.78)",
                    fontSize: "14px",
                    lineHeight: "20px",
                    minHeight: "40px",
                  }}
                >
                  {s.summary}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Controls rows (HORIZONTAL HOLD) */}
        <div
          className="grid"
          style={{
            gridTemplateColumns: `repeat(${STAGES.length}, minmax(0, 1fr))`,
          }}
        >
          {STAGES.map((s, colIdx) => {
            const isActive = activeId === s.id;
            return (
              <div
                key={s.id}
                className="px-6 py-5"
                onMouseEnter={() => setActiveId(s.id)}
                onMouseLeave={() => setActiveId(null)}
                style={{
                  borderRight: colIdx < STAGES.length - 1 ? "1px solid #C0C5CE" : "none",
                  borderLeft: isActive ? "2px solid #000033" : "2px solid transparent",
                  transition: "border-color 140ms ease",
                }}
              >
                <div
                  className="uppercase font-semibold"
                  style={{
                    fontSize: "11px",
                    letterSpacing: "0.14em",
                    color: "rgba(0,0,51,0.62)",
                    marginBottom: "10px",
                  }}
                >
                  Controls Applied
                </div>

                {/* EXACTLY 3 bullets; same vertical spacing; aligns across columns */}
                <div className="space-y-3">
                  {s.bullets.map((b) => (
                    <div key={b} className="flex items-start gap-3">
                      <span
                        style={{
                          width: "6px",
                          height: "6px",
                          borderRadius: "999px",
                          backgroundColor: "#000033",
                          opacity: 0.9,
                          marginTop: "7px",
                          flexShrink: 0,
                        }}
                      />
                      <span style={{ color: "#000033", fontSize: "13px", lineHeight: "18px" }}>
                        {b}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* Anchored callout (consistent with Litigation slide) */}
      <AnimatePresence>
        {active && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.18 }}
            className="mx-auto text-center"
            style={{
              maxWidth: "960px",
              border: "1px solid #C0C5CE",
              borderRadius: "12px",
              backgroundColor: "#FFFFFF",
              padding: "12px 16px",
              color: "#000033",
            }}
          >
            <span className="font-bold" style={{ letterSpacing: "0.08em" }}>
              {active.level}
            </span>
            <span style={{ opacity: 0.7 }}> — </span>
            <span style={{ opacity: 0.85 }}>
              {active.title}: {active.summary}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Foundation strip (optional, tight) */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.7 }}
        className="mx-auto mt-8"
        style={{
          maxWidth: "960px",
          backgroundColor: "#FFFFFF",
          border: "1px solid #C0C5CE",
          borderTop: "2px solid #000033",
          borderRadius: "12px",
          padding: "14px 16px",
          color: "#000033",
        }}
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div
            className="uppercase font-bold"
            style={{ fontSize: "12px", letterSpacing: "0.14em", color: "rgba(0,0,51,0.72)" }}
          >
            Traceability Guarantee
          </div>
          <div style={{ color: "rgba(0,0,51,0.78)", fontSize: "14px" }}>
            Every stage writes lineage to the audit ledger — enabling replay and equivalence verification.
          </div>
        </div>
      </motion.div>
    </div>
  );
}