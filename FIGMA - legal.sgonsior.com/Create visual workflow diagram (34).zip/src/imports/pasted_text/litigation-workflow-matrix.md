Litigation Workflow & Artifact Matrix v1

AI Legal Service – Deterministic Litigation Platform

Scope







Attribute



Value





Case Type



Civil





Sub Case Type



Contract





Posture



Plaintiff / Defendant





Version



v1 – Attorney Validation Draft

Matrix Columns







Column



Meaning





Party Posture



Plaintiff or Defendant





Stage



Litigation lifecycle stage





Artifact



Work product produced





Supplier



Source of inputs





Inputs



Evidence / facts / law





Process



Analytical or legal process





Output



Artifact created





Consumer



Next user of artifact





Producer Type



Program / Agent / Attorney





Platform Component



Responsible system element





Trigger



Event that initiates generation





Approval Required



Attorney validation required

Stage 1 — Client Intake







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Plaintiff



Client Intake



Interview Transcript



Client



Client narrative



Structured interview capture



Interview Record



Mapping Agent



Agent



INTERVIEW_AGENT



Client interview start



No





Plaintiff



Client Intake



Initial Fact List



Interview Agent



Interview transcript



Fact extraction



Raw fact candidates



Fact normalization



Program



program_FACT_NORMALIZATION



Interview complete



No





Defendant



Client Intake



Matter Intake Record



Law firm



Case summary



Structured intake



Matter profile



Evidence collection



Agent



INTERVIEW_AGENT



Case opened



Attorney

Stage 2 — Case Evaluation







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Plaintiff



Case Evaluation



Case Theory Draft



Attorney + system



Facts + law



Legal theory formulation



Theory outline



COA analysis



Agent



agent_COA_REASONER



Fact normalization complete



Attorney





Defendant



Case Evaluation



Defense Position Outline



Attorney



Complaint allegations



Defense theory analysis



Defense strategy outline



COA analysis



Attorney



Manual



Complaint received



Attorney

Stage 3 — Evidence Collection







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Evidence Collection



Evidence Repository



Client / Documents



Files, emails, contracts



Document ingestion



Evidence dataset



Fact normalization



Program



program_PROCESSING



File upload



No





Both



Evidence Collection



Evidence Metadata



Processing engine



Documents



Metadata extraction



Evidence index



Tagging engine



Program



program_PROCESSING



Document processed



No

Stage 4 — Fact Normalization







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Fact Normalization



Normalized Facts



Evidence + interview



Evidence text



Fact extraction



Structured facts



Event mapping



Program



program_FACT_NORMALIZATION



Evidence ingestion



No

Stage 5 — Event Mapping







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Event Mapping



Event Candidates



Facts



Normalized facts



Event construction



Event objects



Timeline + COA



Program



program_COMPOSITE_ENGINE



Facts created



No





Both



Event Mapping



Case Timeline



Event candidates



Events



Chronological assembly



Litigation timeline



Attorney review



Agent



MAPPING_AGENT



Event set complete



Attorney

Stage 6 — Legal Theory Formation







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Plaintiff



Legal Theory



COA Coverage Matrix



Timeline + facts



COA rules



Coverage analysis



Element coverage map



Attorney



Program



program_COA_ENGINE



Timeline finalized



No





Plaintiff



Legal Theory



Legal Argument Proposal



Coverage matrix



Evidence + elements



Narrative synthesis



Argument draft



Attorney



Agent



agent_COA_REASONER



COA coverage generated



Attorney

Stage 7 — Pleading Drafting







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Plaintiff



Pleading Drafting



Complaint Draft



Legal theory



COA coverage



Complaint drafting



Complaint document



Court filing



Agent



OPPOSITION_AGENT



Attorney request



Attorney





Defendant



Pleading Drafting



Answer Draft



Complaint



Allegations



Defense drafting



Answer document



Court filing



Agent



OPPOSITION_AGENT



Complaint received



Attorney

Stage 8 — Discovery







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Discovery



Discovery Request Packet



Case facts



Evidence gaps



Discovery planning



Interrogatories / RFPs



Opposing party



Program



program_DISCOVERY_PACKET



Evidence gap detected



Attorney





Both



Discovery



Discovery Response Map



Opposing responses



Documents



Evidence correlation



Response index



COA coverage



Program



program_COVERAGE_ANALYSIS



Discovery responses received



Attorney

Stage 9 — Motion Practice







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Motion Practice



Motion Draft



Evidence + law



Legal arguments



Motion construction



Motion document



Court filing



Agent



OPPOSITION_AGENT



Attorney request



Attorney





Both



Motion Practice



Opposition Draft



Motion



Counter arguments



Opposition drafting



Opposition brief



Court filing



Agent



OPPOSITION_AGENT



Motion filed



Attorney

Stage 10 — Trial Preparation







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Trial Prep



Exhibit List



Evidence repository



Documents



Exhibit selection



Exhibit catalog



Court



Program



program_BURDEN_MAP_BUILDER



Trial preparation start



Attorney





Both



Trial Prep



Witness Outline



Facts + events



Timeline



Witness narrative creation



Witness prep guide



Attorney



Agent



OPPOSITION_AGENT



Trial prep phase



Attorney

Stage 11 — Trial Support







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Trial



Trial Evidence Map



Exhibits



Evidence



Evidence alignment



Trial evidence index



Attorney



Program



program_COVERAGE_ANALYSIS



Trial start



No

Stage 12 — Post Trial







Party



Stage



Artifact



Supplier



Inputs



Process



Output



Consumer



Producer Type



Platform Component



Trigger



Approval





Both



Post Trial



Judgment Analysis



Verdict



Trial outcome



Legal analysis



Appeal assessment



Attorney



Agent



agent_COA_REASONER



Verdict entered



Attorney

What This Matrix Immediately Gives You

This artifact now connects four worlds:

1️⃣ Real Litigation Practice

What attorneys actually produce.

2️⃣ Platform Components

Agents and programs responsible.

3️⃣ Artifact System

What artifacts exist and when.

4️⃣ Execution Triggers

How orchestration occurs.

Why This Matrix Is So Important

This single artifact becomes the control surface of the platform.

It will drive:

Product scope

What the system actually needs to build.

Orchestration design

How the workflow engine triggers programs.

Artifact registry

What artifacts must exist in the system.

Attorney validation

Whether the platform matches real litigation practice.

Next Critical Step (Very Important)

Before expanding this matrix further, we should add three additional columns that will make the architecture fully operational:







Column



Why it matters





Artifact ID



Connects to artifact registry





Artifact Type



Evidence / Analysis / Pleading





Storage Class



Canonical / Proposal / Derived

These connect the matrix directly to your artifact governance model.

Next Step I Recommend

In the next pass we should build the real platform control version of this matrix by adding:

4 additional columns

Artifact IDArtifact ClassArtifact Lifecycle StageDeterministic Program Stage

This will turn the matrix into the true orchestration map of the platform.

Important Observation

You were absolutely right earlier in the day:

"When do we get back to the SIPOC matrix?"

Now that the architecture is frozen, this matrix becomes the bridge between litigation reality and the deterministic system you built.

This is exactly the moment to build it.

If you're ready, the next step will dramatically strengthen the platform.

I recommend we next build:

The Artifact Taxonomy Layer

which will define ~40–60 canonical artifacts the system manages.

This will transform the matrix into the actual operating model of the litigation engine.

And it will make your attorney validation session 10× more productive.

If you'd like, I can also show you the single improvement that will make attorneys immediately understand the platform in 60 seconds.

Yes to adding 4 columns: Artifact ID Artifact Class Artifact Lifecycle Stage Deterministic Program Stage Can you also produce a 'terms' key with descriptions so that I speak your language and can explain the matrix as intended. a "so what" might be helpful to keep attorneys focused on validation, not arguing terms - they are like that! Also I am not seeing things like 'deposition' explicitly called out - when we make matrix can we be sure to be thorough and complete. i thought there were layers to category ie. civil->contract->breach ...

Excellent instincts. What you are doing here is exactly what mature platform design requires — separating:





terminology clarity



workflow completeness



system execution mapping

If you do those three things well, attorneys focus on validating the workflow, not debating vocabulary.

Below are the three pieces you asked for.

1. Matrix Term Key (Plain English for Attorneys)

Use this as the legend when presenting the matrix.

It allows you to control the conversation.

Core Litigation Context

Party Posture

Which side of the case the workflow step belongs to.

Examples:





Plaintiff



Defendant



Both

So What

Different sides of litigation produce different artifacts and workflows.The platform must support both litigation strategies.

Case Type

High-level legal category.

Examples:

CivilCriminalAdministrative

So What

Different case types require different workflow engines and different artifacts.

Sub Case Type

More specific legal classification within the case type.

Examples (Civil):

ContractTortEmploymentIP

So What

Each subtype has different Causes of Action and evidence requirements.

Cause of Action (COA)

The legal claim being asserted.

Examples for Contract:





Breach of Contract



Anticipatory Breach



Promissory Estoppel

So What

The entire platform ultimately exists to answer one question:

“Do the facts and evidence satisfy the elements of the claim?”

Everything flows into that analysis.

2. Workflow Terms

Stage

Major phase of litigation.

Example stages:





Client Intake



Case Evaluation



Evidence Collection



Pleading Drafting



Discovery



Motion Practice



Trial Preparation



Trial



Post-Trial

So What

Stages help ensure the platform follows real litigation timelines.

Artifact

A work product generated during litigation.

Examples:

ComplaintInterrogatoriesDeposition TranscriptExhibit ListMotion for Summary Judgment

So What

The platform is fundamentally an artifact production system.

Every artifact:

• has inputs• requires analysis• produces outputs• feeds the next step

Supplier

The origin of information used to generate the artifact.

Examples:

ClientEvidence DocumentsOpposing CounselCourtAttorney

So What

Ensures the system tracks provenance of information.

Inputs

Information used to generate an artifact.

Examples:

FactsEvidenceLawPrior artifacts

So What

Allows the system to trace how conclusions were formed.

Process

The legal or analytical work performed.

Examples:

Legal analysisFact extractionEvent reconstructionArgument formation

So What

Defines what the system actually does.

Output

The artifact created after the process.

So What

This is what attorneys ultimately use.

Consumer

Who uses the artifact next.

Examples:

AttorneyCourtOpposing CounselAnother system process

So What

Defines workflow dependencies.

3. Platform Execution Terms

These map the legal workflow to the deterministic system you built.

Producer Type

Who generated the artifact.

Examples:

AttorneyAI AgentDeterministic Program

So What

Shows which parts of litigation are automated vs human.

Platform Component

The specific system element responsible.

Examples:

INTERVIEW_AGENTprogram_FACT_NORMALIZATIONprogram_COA_ENGINE

So What

Connects legal workflow → system architecture.

Trigger

What causes the artifact to be generated.

Examples:

Client interview completedEvidence uploadedComplaint filedDiscovery deadline approaching

So What

This defines the workflow orchestration logic.

Approval Required

Whether attorney review is mandatory.

So What

Protects against unauthorized automated legal work.

4. New Columns We Added

These are pure platform governance columns.

Artifact ID

Unique identifier for each artifact type.

Example

ART-COMPLAINT-DRAFTART-DEPOSITION-TRANSCRIPTART-INTERROGATORIES

So What

This allows the system to maintain a canonical artifact registry.

Artifact Class

Type of artifact.

Example classes

EvidenceAnalysisPleadingDiscoveryMotionTrialAdministrative

So What

Allows the system to organize artifacts across case types.

Artifact Lifecycle Stage

Where the artifact sits in its lifecycle.

Example:

ProposedDraftAttorney ReviewedFiledFinal

So What

Controls legal workflow governance.

Deterministic Program Stage

Where the artifact fits into the execution spine of the platform.

Example stages:

INGESTIONNORMALIZATIONTAGGINGCOMPOSITIONLEGAL ANALYSISDOCUMENT GENERATION

So What

This ensures the platform executes in a predictable deterministic pipeline.

5. Ensuring the Matrix Is Complete

You are 100% correct.

The matrix must include all major litigation artifacts, including:

Discovery

InterrogatoriesRequests for ProductionRequests for AdmissionSubpoenasDeposition NoticesDeposition Transcripts

Depositions

Deposition preparation outlineDeposition exhibitsDeposition transcriptDeposition summary

Motion Practice

Motion to DismissMotion to CompelMotion for Summary JudgmentOppositionReply

Trial Preparation

Witness listExhibit listTrial briefJury instructions

Trial

Direct examination outlinesCross examination outlinesTrial exhibits

Post Trial

JudgmentAppeal noticeAppeal brief

6. Case Classification Hierarchy (Very Important)

You are also right that there are layers.

The platform will eventually support a hierarchy like this:

Case Type   ↓Sub Case Type   ↓Cause of Action   ↓Element   ↓Evidence

Example:

Civil   ↓Contract   ↓Breach of Contract   ↓Elements   • Valid Contract   • Plaintiff Performance   • Defendant Breach   • Damages

This hierarchy drives:

COA_ENGINEBURDEN_MAP_BUILDERCOVERAGE_ANALYSIS

7. The One Thing That Will Keep Attorneys Focused

When presenting the matrix say this:

"We are not debating terminology today.We are validating whether the workflow and artifacts reflect real litigation practice. If the artifacts and stages are correct, the platform will mirror how attorneys actually work."

That framing works extremely well.

8. Next Step (Very Important)

Before building the final expanded matrix, we should create:

Canonical Artifact Registry

This will likely include 50–80 litigation artifacts.

Once defined, the matrix becomes fully populated and consistent.

If you'd like, the next thing I can produce is something that will help enormously:

The Master Litigation Artifact Catalog

It will list every artifact produced across litigation including:

• pleadings• discovery• depositions• motions• trial artifacts• appellate artifacts

Once that exists, the matrix can be built completely and accurately.

And that will make your attorney validation session dramatically more productive.

hell yeah...that will be awesome. create all and any contnet you think will help me

Perfect. What we’re about to build is the single artifact that will anchor the entire platform conversation with attorneys.

Think of this as the Litigation Artifact Catalog + Platform Mapping Guide.

This does four things simultaneously:





Shows attorneys you understand litigation practice deeply



Defines what the platform actually produces



Connects artifacts to deterministic execution



Prevents scope creep during product design

MASTER LITIGATION ARTIFACT CATALOG

AI Legal Service – Deterministic Litigation Platform

This catalog lists the canonical artifacts produced during civil litigation and maps them to the platform architecture.

The catalog is organized by litigation phase.

Artifact Classification Model

Every artifact belongs to a structured hierarchy.

Artifact Class     ↓Artifact Category     ↓Artifact Type     ↓Artifact ID

Example:

Pleading   ↓Complaint   ↓Breach of Contract Complaint   ↓ART-PL-COMPLAINT-BOC

This structure ensures the system can scale across:

• case types• jurisdictions• litigation strategies

Artifact Classes

These are the top-level artifact families.







Artifact Class



Description





Evidence



Documents, files, or testimony





Analysis



Structured interpretation of evidence





Pleading



Documents filed initiating claims





Discovery



Information requests and responses





Motion



Requests for court rulings





Trial



Trial preparation and courtroom artifacts





Post-Trial



Judgments, appeals, enforcement





Administrative



Case management records

STAGE 1 — CLIENT INTAKE







Artifact ID



Artifact



Class



Description





ART-INTAKE-INTERVIEW



Client Interview Transcript



Administrative



Structured intake interview record





ART-INTAKE-MATTER



Matter Intake Record



Administrative



Initial case file record





ART-INTAKE-FACTLIST



Initial Fact List



Analysis



Early fact extraction





ART-INTAKE-CASESUMMARY



Case Summary



Analysis



High level narrative summary





ART-INTAKE-CONFLICTCHECK



Conflict Check Report



Administrative



Law firm conflict validation

STAGE 2 — CASE EVALUATION







Artifact ID



Artifact



Class



Description





ART-CASE-THEORY



Case Theory Draft



Analysis



Initial theory of liability





ART-CASE-COA-LIST



Cause of Action List



Analysis



Potential claims





ART-CASE-DAMAGES



Preliminary Damages Analysis



Analysis



Early damages estimate





ART-CASE-RISK



Case Risk Assessment



Analysis



Likelihood of success

STAGE 3 — EVIDENCE COLLECTION







Artifact ID



Artifact



Class



Description





ART-EVID-DOCUMENT



Evidence Document



Evidence



Uploaded files





ART-EVID-METADATA



Evidence Metadata



Evidence



Document attributes





ART-EVID-INDEX



Evidence Index



Evidence



Catalog of evidence





ART-EVID-CHAIN



Chain of Custody



Administrative



Evidence provenance

STAGE 4 — FACT NORMALIZATION







Artifact ID



Artifact



Class



Description





ART-FACT-NORMALIZED



Normalized Fact Record



Analysis



Structured fact representation





ART-FACT-SOURCE



Fact Source Link



Analysis



Evidence supporting fact





ART-FACT-TAGGED



Tagged Fact



Analysis



Fact with legal tags

STAGE 5 — EVENT MAPPING







Artifact ID



Artifact



Class



Description





ART-EVENT-CANDIDATE



Event Candidate



Analysis



Potential legal event





ART-EVENT-COMPOSITE



Composite Event



Analysis



Event built from multiple facts





ART-EVENT-TIMELINE



Case Timeline



Analysis



Chronological case map

STAGE 6 — LEGAL THEORY DEVELOPMENT







Artifact ID



Artifact



Class



Description





ART-COA-MATRIX



COA Coverage Matrix



Analysis



Elements vs evidence





ART-BURDEN-MAP



Burden of Proof Map



Analysis



Proof requirements





ART-ARGUMENT-DRAFT



Legal Argument Draft



Analysis



Narrative legal reasoning

STAGE 7 — PLEADING DRAFTING







Artifact ID



Artifact



Class



Description





ART-PL-COMPLAINT



Complaint Draft



Pleading



Plaintiff complaint





ART-DF-ANSWER



Answer Draft



Pleading



Defendant response





ART-COUNTERCLAIM



Counterclaim Draft



Pleading



Defendant claim





ART-AMENDED-COMPLAINT



Amended Complaint



Pleading



Revised complaint

STAGE 8 — DISCOVERY







Artifact ID



Artifact



Class



Description





ART-DISC-INTERROG



Interrogatories



Discovery



Written questions





ART-DISC-RFP



Request for Production



Discovery



Document requests





ART-DISC-RFA



Request for Admission



Discovery



Admission requests





ART-DISC-SUBPOENA



Subpoena



Discovery



Third party evidence request





ART-DISC-RESPONSE



Discovery Response



Discovery



Opposing responses

STAGE 9 — DEPOSITIONS







Artifact ID



Artifact



Class



Description





ART-DEPO-NOTICE



Deposition Notice



Discovery



Formal deposition notice





ART-DEPO-OUTLINE



Deposition Outline



Trial



Question preparation





ART-DEPO-TRANSCRIPT



Deposition Transcript



Evidence



Recorded testimony





ART-DEPO-SUMMARY



Deposition Summary



Analysis



Key testimony summary

STAGE 10 — MOTION PRACTICE







Artifact ID



Artifact



Class



Description





ART-MOTION-DISMISS



Motion to Dismiss



Motion



Early dismissal request





ART-MOTION-COMPEL



Motion to Compel



Motion



Discovery enforcement





ART-MOTION-SJ



Motion for Summary Judgment



Motion



Judgment without trial





ART-MOTION-OPPOSITION



Opposition Brief



Motion



Response to motion





ART-MOTION-REPLY



Reply Brief



Motion



Final argument

STAGE 11 — TRIAL PREPARATION







Artifact ID



Artifact



Class



Description





ART-TRIAL-WITNESS



Witness List



Trial



Witness planning





ART-TRIAL-EXHIBIT



Exhibit List



Trial



Evidence exhibits





ART-TRIAL-BRIEF



Trial Brief



Trial



Legal summary





ART-TRIAL-JURY



Jury Instructions



Trial



Proposed instructions





ART-TRIAL-DIRECT



Direct Examination Outline



Trial



Witness questioning plan





ART-TRIAL-CROSS



Cross Examination Outline



Trial



Opposing witness questioning

STAGE 12 — TRIAL







Artifact ID



Artifact



Class



Description





ART-TRIAL-EXHIBIT-ADMITTED



Admitted Exhibit



Evidence



Accepted trial evidence





ART-TRIAL-TRANSCRIPT



Trial Transcript



Evidence



Court record

STAGE 13 — POST TRIAL







Artifact ID



Artifact



Class



Description





ART-JUDGMENT



Judgment



Post-Trial



Court decision





ART-APPEAL-NOTICE



Notice of Appeal



Post-Trial



Appeal initiation





ART-APPEAL-BRIEF



Appeal Brief



Post-Trial



Appellate argument

How This Catalog Connects to the Platform

Each artifact will map to:

AgentProgramTriggerApprovalLifecycle Stage

Example:

ART-DEPO-SUMMARYClassAnalysisProduced ByOPPOSITION_AGENTProgram StageLEGAL_ANALYSISTriggerDeposition transcript ingestionApprovalAttorney required

Why This Catalog Matters

This single artifact becomes the foundation of the entire litigation platform.

It determines:

• database schema• artifact registry• workflow orchestration• agent responsibilities• attorney validation sessions

How to Present This to Attorneys

Start with this framing:

“We mapped the artifacts produced in litigation.The platform simply helps generate, analyze, and manage these artifacts in a structured way.”

Then ask them:

1️⃣ Are any artifacts missing?2️⃣ Are artifacts produced at the wrong stage?3️⃣ Are any artifacts unnecessary?

Do not let them debate terminology.

Focus only on:

“Does this reflect how litigation actually works?”

The Next Piece (This Will Be Huge)

The artifact catalog unlocks the ability to build:

The Litigation Workflow Engine

This will show:

artifact → program → agent → artifact

Which is the actual execution model of the platform.

If you'd like, the next thing I can produce will be extremely powerful for you:

The Full Litigation Workflow Engine Map

It will show exactly how the platform moves from:

client interview      ↓facts      ↓events      ↓COA coverage      ↓arguments      ↓pleadings      ↓discovery      ↓trial

When attorneys see that diagram, the platform usually clicks immediately.





Full Litigation Workflow Engine Map

AI Legal Service – Deterministic Litigation Platform

The platform operates as a structured artifact pipeline:

Client Narrative     ↓Evidence     ↓Facts     ↓Events     ↓Legal Elements     ↓Arguments     ↓Litigation Artifacts     ↓Court Process

Each stage produces structured artifacts that feed the next stage.

Stage 1 — Client Intake

Goal

Capture the client’s narrative and initial case facts.

Inputs





Client interview



Documents



Contracts



Communications

Artifacts Produced







Artifact



Artifact ID





Client Interview Transcript



ART-INTAKE-INTERVIEW





Initial Fact List



ART-INTAKE-FACTLIST





Case Summary



ART-INTAKE-CASESUMMARY





Matter Record



ART-INTAKE-MATTER

Platform Components

Producer

INTERVIEW_AGENT

Programs

program_PROCESSINGprogram_FACT_NORMALIZATION

Output

Initial fact candidatesEvidence repository

Stage 2 — Evidence Ingestion

Goal

Convert unstructured evidence into structured records.

Inputs

DocumentsEmailsContractsImagesAudio

Artifacts Produced







Artifact



ID





Evidence Document



ART-EVID-DOCUMENT





Evidence Metadata



ART-EVID-METADATA





Evidence Index



ART-EVID-INDEX

Platform Programs

program_PROCESSINGprogram_TAGGING_ENGINE

Output

Tagged evidence objects

Stage 3 — Fact Normalization

Goal

Extract legally relevant facts from evidence.

Inputs

Evidence objectsInterview narrative

Artifacts Produced







Artifact



ID





Normalized Fact



ART-FACT-NORMALIZED





Fact Source Link



ART-FACT-SOURCE





Tagged Fact



ART-FACT-TAGGED

Platform Program

program_FACT_NORMALIZATION

Output

Structured fact dataset

Stage 4 — Event Construction

Goal

Transform facts into legally meaningful events.

Inputs

FactsEntitiesTime references

Artifacts Produced







Artifact



ID





Event Candidate



ART-EVENT-CANDIDATE





Composite Event



ART-EVENT-COMPOSITE





Case Timeline



ART-EVENT-TIMELINE

Platform Program

program_COMPOSITE_ENGINE

Output

Chronological legal timeline

Stage 5 — Legal Element Mapping

Goal

Determine whether facts satisfy legal elements.

Inputs

EventsEvidenceLegal rules

Artifacts Produced







Artifact



ID





COA Coverage Matrix



ART-COA-MATRIX





Burden Map



ART-BURDEN-MAP

Platform Programs

program_COA_ENGINEprogram_BURDEN_MAP_BUILDER

Output

Element coverage analysis

Stage 6 — Legal Reasoning

Goal

Convert structured analysis into legal arguments.

Inputs

Coverage matrixEvidenceLegal authorities

Artifacts Produced







Artifact



ID





Legal Argument Draft



ART-ARGUMENT-DRAFT





Case Theory



ART-CASE-THEORY

Platform Component

agent_COA_REASONER

Output

Attorney reviewable argument proposals

Stage 7 — Pleading Generation

Goal

Produce formal court filings.

Inputs

ArgumentsFactsLegal elements

Artifacts Produced







Artifact



ID





Complaint



ART-PL-COMPLAINT





Answer



ART-DF-ANSWER





Counterclaim



ART-COUNTERCLAIM

Platform Agent

OPPOSITION_AGENT

Output

Draft pleadings

Attorney approval required.

Stage 8 — Discovery Engine

Goal

Identify evidence gaps and generate discovery.

Inputs

Coverage matrixEvidence gapsCase theory

Artifacts Produced







Artifact



ID





Interrogatories



ART-DISC-INTERROG





Request for Production



ART-DISC-RFP





Requests for Admission



ART-DISC-RFA





Subpoena



ART-DISC-SUBPOENA

Platform Program

program_DISCOVERY_PACKET

Output

Discovery request packet

Stage 9 — Deposition Support

Goal

Prepare and analyze witness testimony.

Inputs

Discovery evidenceTimelineFact records

Artifacts Produced







Artifact



ID





Deposition Outline



ART-DEPO-OUTLINE





Deposition Transcript



ART-DEPO-TRANSCRIPT





Deposition Summary



ART-DEPO-SUMMARY

Platform Agent

OPPOSITION_AGENT

Output

Witness testimony analysis

Stage 10 — Motion Practice

Goal

Generate legal motions and oppositions.

Inputs

EvidenceLegal argumentsDiscovery results

Artifacts Produced







Artifact



ID





Motion to Dismiss



ART-MOTION-DISMISS





Motion to Compel



ART-MOTION-COMPEL





Motion for Summary Judgment



ART-MOTION-SJ





Opposition Brief



ART-MOTION-OPPOSITION

Platform Agent

OPPOSITION_AGENT

Stage 11 — Trial Preparation

Goal

Organize trial strategy.

Inputs

EvidenceWitnessesArguments

Artifacts Produced







Artifact



ID





Witness List



ART-TRIAL-WITNESS





Exhibit List



ART-TRIAL-EXHIBIT





Trial Brief



ART-TRIAL-BRIEF





Direct Examination Outline



ART-TRIAL-DIRECT





Cross Examination Outline



ART-TRIAL-CROSS

Platform Programs

program_COVERAGE_ANALYSISprogram_BURDEN_MAP_BUILDER

Stage 12 — Trial

Goal

Support courtroom presentation.

Artifacts Produced







Artifact



ID





Admitted Exhibit



ART-TRIAL-EXHIBIT-ADMITTED





Trial Transcript



ART-TRIAL-TRANSCRIPT

Stage 13 — Post-Trial

Goal

Evaluate judgment and appeals.

Artifacts Produced







Artifact



ID





Judgment



ART-JUDGMENT





Notice of Appeal



ART-APPEAL-NOTICE





Appeal Brief



ART-APPEAL-BRIEF

The Deterministic Platform Spine

Your architecture guarantees that the system executes in this order:

INGESTION   ↓NORMALIZATION   ↓TAGGING   ↓EVENT COMPOSITION   ↓LEGAL ELEMENT ANALYSIS   ↓LEGAL REASONING   ↓DOCUMENT GENERATION

Programs drive the deterministic layers.

Agents operate only where reasoning or drafting is required.

The Most Powerful Way to Explain This

Tell attorneys this:

“Litigation is really just the transformation of evidence into arguments and then into filings. This platform organizes that transformation so that every step is traceable and supported by evidence.”

That explanation almost always makes the platform click immediately.

The Next Artifact That Will Help You Tremendously

If you'd like, I can also produce the Visual Architecture Layer Diagram for the platform.

This will show the five-layer architecture attorneys love seeing:

Human LayerAgent LayerProgram LayerArtifact LayerEvidence Layer

That diagram is the one Figma slide that usually blows people away.







































































Perfect. What we’re about to build is the single artifact that will anchor the entire platform conversation with attorneys.

Think of this as the Litigation Artifact Catalog + Platform Mapping Guide.

This does four things simultaneously:





Shows attorneys you understand litigation practice deeply



Defines what the platform actually produces



Connects artifacts to deterministic execution



Prevents scope creep during product design

MASTER LITIGATION ARTIFACT CATALOG

AI Legal Service – Deterministic Litigation Platform

This catalog lists the canonical artifacts produced during civil litigation and maps them to the platform architecture.

The catalog is organized by litigation phase.

Artifact Classification Model

Every artifact belongs to a structured hierarchy.

Artifact Class
     ↓
Artifact Category
     ↓
Artifact Type
     ↓
Artifact ID


Example:

Pleading
   ↓
Complaint
   ↓
Breach of Contract Complaint
   ↓
ART-PL-COMPLAINT-BOC


This structure ensures the system can scale across:

• case types• jurisdictions• litigation strategies

Artifact Classes

These are the top-level artifact families.







Artifact Class



Description





Evidence



Documents, files, or testimony





Analysis



Structured interpretation of evidence





Pleading



Documents filed initiating claims





Discovery



Information requests and responses





Motion



Requests for court rulings





Trial



Trial preparation and courtroom artifacts





Post-Trial



Judgments, appeals, enforcement





Administrative



Case management records

STAGE 1 — CLIENT INTAKE







Artifact ID



Artifact



Class



Description





ART-INTAKE-INTERVIEW



Client Interview Transcript



Administrative



Structured intake interview record





ART-INTAKE-MATTER



Matter Intake Record



Administrative



Initial case file record





ART-INTAKE-FACTLIST



Initial Fact List



Analysis



Early fact extraction





ART-INTAKE-CASESUMMARY



Case Summary



Analysis



High level narrative summary





ART-INTAKE-CONFLICTCHECK



Conflict Check Report



Administrative



Law firm conflict validation

STAGE 2 — CASE EVALUATION







Artifact ID



Artifact



Class



Description





ART-CASE-THEORY



Case Theory Draft



Analysis



Initial theory of liability





ART-CASE-COA-LIST



Cause of Action List



Analysis



Potential claims





ART-CASE-DAMAGES



Preliminary Damages Analysis



Analysis



Early damages estimate





ART-CASE-RISK



Case Risk Assessment



Analysis



Likelihood of success

STAGE 3 — EVIDENCE COLLECTION







Artifact ID



Artifact



Class



Description





ART-EVID-DOCUMENT



Evidence Document



Evidence



Uploaded files





ART-EVID-METADATA



Evidence Metadata



Evidence



Document attributes





ART-EVID-INDEX



Evidence Index



Evidence



Catalog of evidence





ART-EVID-CHAIN



Chain of Custody



Administrative



Evidence provenance

STAGE 4 — FACT NORMALIZATION







Artifact ID



Artifact



Class



Description





ART-FACT-NORMALIZED



Normalized Fact Record



Analysis



Structured fact representation





ART-FACT-SOURCE



Fact Source Link



Analysis



Evidence supporting fact





ART-FACT-TAGGED



Tagged Fact



Analysis



Fact with legal tags

STAGE 5 — EVENT MAPPING







Artifact ID



Artifact



Class



Description





ART-EVENT-CANDIDATE



Event Candidate



Analysis



Potential legal event





ART-EVENT-COMPOSITE



Composite Event



Analysis



Event built from multiple facts





ART-EVENT-TIMELINE



Case Timeline



Analysis



Chronological case map

STAGE 6 — LEGAL THEORY DEVELOPMENT







Artifact ID



Artifact



Class



Description





ART-COA-MATRIX



COA Coverage Matrix



Analysis



Elements vs evidence





ART-BURDEN-MAP



Burden of Proof Map



Analysis



Proof requirements





ART-ARGUMENT-DRAFT



Legal Argument Draft



Analysis



Narrative legal reasoning

STAGE 7 — PLEADING DRAFTING







Artifact ID



Artifact



Class



Description





ART-PL-COMPLAINT



Complaint Draft



Pleading



Plaintiff complaint





ART-DF-ANSWER



Answer Draft



Pleading



Defendant response





ART-COUNTERCLAIM



Counterclaim Draft



Pleading



Defendant claim





ART-AMENDED-COMPLAINT



Amended Complaint



Pleading



Revised complaint

STAGE 8 — DISCOVERY







Artifact ID



Artifact



Class



Description





ART-DISC-INTERROG



Interrogatories



Discovery



Written questions





ART-DISC-RFP



Request for Production



Discovery



Document requests





ART-DISC-RFA



Request for Admission



Discovery



Admission requests





ART-DISC-SUBPOENA



Subpoena



Discovery



Third party evidence request





ART-DISC-RESPONSE



Discovery Response



Discovery



Opposing responses

STAGE 9 — DEPOSITIONS







Artifact ID



Artifact



Class



Description





ART-DEPO-NOTICE



Deposition Notice



Discovery



Formal deposition notice





ART-DEPO-OUTLINE



Deposition Outline



Trial



Question preparation





ART-DEPO-TRANSCRIPT



Deposition Transcript



Evidence



Recorded testimony





ART-DEPO-SUMMARY



Deposition Summary



Analysis



Key testimony summary

STAGE 10 — MOTION PRACTICE







Artifact ID



Artifact



Class



Description





ART-MOTION-DISMISS



Motion to Dismiss



Motion



Early dismissal request





ART-MOTION-COMPEL



Motion to Compel



Motion



Discovery enforcement





ART-MOTION-SJ



Motion for Summary Judgment



Motion



Judgment without trial





ART-MOTION-OPPOSITION



Opposition Brief



Motion



Response to motion





ART-MOTION-REPLY



Reply Brief



Motion



Final argument

STAGE 11 — TRIAL PREPARATION







Artifact ID



Artifact



Class



Description





ART-TRIAL-WITNESS



Witness List



Trial



Witness planning





ART-TRIAL-EXHIBIT



Exhibit List



Trial



Evidence exhibits





ART-TRIAL-BRIEF



Trial Brief



Trial



Legal summary





ART-TRIAL-JURY



Jury Instructions



Trial



Proposed instructions





ART-TRIAL-DIRECT



Direct Examination Outline



Trial



Witness questioning plan





ART-TRIAL-CROSS



Cross Examination Outline



Trial



Opposing witness questioning

STAGE 12 — TRIAL







Artifact ID



Artifact



Class



Description





ART-TRIAL-EXHIBIT-ADMITTED



Admitted Exhibit



Evidence



Accepted trial evidence





ART-TRIAL-TRANSCRIPT



Trial Transcript



Evidence



Court record

STAGE 13 — POST TRIAL







Artifact ID



Artifact



Class



Description





ART-JUDGMENT



Judgment



Post-Trial



Court decision





ART-APPEAL-NOTICE



Notice of Appeal



Post-Trial



Appeal initiation





ART-APPEAL-BRIEF



Appeal Brief



Post-Trial



Appellate argument

How This Catalog Connects to the Platform

Each artifact will map to:

Agent
Program
Trigger
Approval
Lifecycle Stage


Example:

ART-DEPO-SUMMARY

Class
Analysis

Produced By
OPPOSITION_AGENT

Program Stage
LEGAL_ANALYSIS

Trigger
Deposition transcript ingestion

Approval
Attorney required


Why This Catalog Matters

This single artifact becomes the foundation of the entire litigation platform.

It determines:

• database schema• artifact registry• workflow orchestration• agent responsibilities• attorney validation sessions

How to Present This to Attorneys

Start with this framing:

“We mapped the artifacts produced in litigation.The platform simply helps generate, analyze, and manage these artifacts in a structured way.”

Then ask them:

1️⃣ Are any artifacts missing?2️⃣ Are artifacts produced at the wrong stage?3️⃣ Are any artifacts unnecessary?

Do not let them debate terminology.

Focus only on:

“Does this reflect how litigation actually works?”

The Next Piece (This Will Be Huge)

The artifact catalog unlocks the ability to build:

The Litigation Workflow Engine

This will show:

artifact → program → agent → artifact


Which is the actual execution model of the platform.

If you'd like, the next thing I can produce will be extremely powerful for you:

The Full Litigation Workflow Engine Map

It will show exactly how the platform moves from:

client interview
      ↓
facts
      ↓
events
      ↓
COA coverage
      ↓
arguments
      ↓
pleadings
      ↓
discovery
      ↓
trial


When attorneys see that diagram, the platform usually clicks immediately.