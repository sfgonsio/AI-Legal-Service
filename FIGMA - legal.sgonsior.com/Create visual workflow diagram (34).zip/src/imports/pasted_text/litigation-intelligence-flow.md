Figma Design Brief
Litigation Intelligence Flow Diagram
“How Evidence Becomes Legal Strategy”
Objective

Create a visual narrative diagram that shows the journey of a single piece of evidence through the platform.

The diagram should illustrate how the system converts:

Raw Evidence → Legal Intelligence → Court-Ready Artifacts

This illustration complements the Litigation Intelligence Engine diagram by showing dynamic flow instead of architecture layers.

Concept

Use a left-to-right flow.

The document enters on the left.

As it moves right, it transforms through the system.

Each transformation should visually show information becoming more structured and legally meaningful.

Think of it like a data transformation pipeline.

Layout

Create seven stages across the canvas.

Evidence
↓
Fact Extraction
↓
Event Construction
↓
Legal Element Mapping
↓
Legal Reasoning
↓
Litigation Artifacts
↓
Court Process

Each stage should have:

an icon

a short title

1-line explanation

Use connecting arrows between stages.

Stage 1 — Evidence

Visual:

A contract document icon with highlighted text.

Label:

Evidence

Subtitle:

Contracts, emails, records, testimony

Caption:

Raw information enters the system.

Example evidence:

Contract between Supplier and Distributor

This stage represents the Evidence Layer.

Stage 2 — Fact Extraction

Visual:

Text highlights turning into structured fact cards.

Example cards:

Fact
Supplier and Distributor signed contract in 2022
Fact
Distributor failed to deliver payment

Label:

Fact Normalization

Subtitle:

Extract legally relevant facts

Programs involved:

FACT_NORMALIZATION
TAGGING_ENGINE
Stage 3 — Event Construction

Visual:

Facts connecting into a timeline graphic.

Example events:

Contract Signed
Payment Due
Payment Breach

Label:

Event Mapping

Subtitle:

Facts assembled into legal events

Program involved:

COMPOSITE_ENGINE
Stage 4 — Legal Element Mapping

Visual:

Timeline feeding into a legal checklist.

Example checklist:

Breach of Contract
✓ Valid Contract
✓ Plaintiff Performance
✓ Defendant Breach
✓ Damages

Label:

Legal Element Analysis

Subtitle:

Evidence tested against legal elements

Programs involved:

COA_ENGINE
BURDEN_MAP_BUILDER
Stage 5 — Legal Reasoning

Visual:

Evidence and elements flowing into an argument bubble.

Example:

Argument
Defendant breached the contract by failing to pay the agreed amount.

Label:

Legal Reasoning

Subtitle:

AI assists legal argument formation

Agent involved:

COA_REASONER
Stage 6 — Litigation Artifacts

Visual:

Documents appearing:

complaint

discovery request

motion

Label:

Litigation Artifacts

Subtitle:

Court-ready legal documents

Examples:

Complaint
Interrogatories
Motion for Summary Judgment

Agent involved:

OPPOSITION_AGENT
Stage 7 — Court Process

Visual:

Courtroom icon.

Artifacts feeding into the courtroom.

Label:

Court Process

Subtitle:

Litigation supported by structured evidence
Visual Story

As the document moves across the diagram:

document → facts → events → legal elements → argument → court filing

Each step should visually show increasing structure and clarity.