SLIDE REPLACEMENT INSTRUCTION
Replace: “Conceptual Data Architecture Framework” (Slide 63)
1️⃣ WHAT IS BEING REPLACED
Remove Completely:

Circular / multi-layer framework

Data Source Layer box cluster

Data Aggregation Layer blocks

Analytical Layer boxes

Security column on right

Governance row at bottom

All icons

All numbered circles

All paragraph explanation side panels

Any teal/blue gradient tones

Any shaded bevel effects

Any pseudo-3D boxes

This slide should no longer look like:

Enterprise BI

Consulting architecture

Healthcare IT platform diagram

Generic data warehouse diagram

2️⃣ WHAT IS BEING MAINTAINED

The following must remain consistent with the deck:

A. Canvas

Width: 1440px

Horizontal layout

Min height: 900px

12-column grid

96px margins

24px gutters

B. Color Discipline

Background: #F4F6F8

Borders: #C0C5CE

Primary fill: #000033

White allowed

No other accent colors

C. Typography Hierarchy

Maintain consistency with prior slides:

Slide Title (left aligned)

Subtitle optional (muted gray)

Uppercase small labels (tracking wide)

Bold stage headers

Body copy in restrained neutral tone

D. Interaction Model

Must match Litigation slide behavior:

Hover = subtle border emphasis

Anchored callout appears below

No floating tooltips

No animated gradients

No icons

We maintain consistency across the deck.

3️⃣ NEW STRUCTURE TO BUILD
Title (Top Left)

“Conceptual Data Architecture”
Subtitle:
“Deterministic. Traceable. Defensible.”

Left aligned.
Keep spacing consistent with previous slides.

4️⃣ TOP GOVERNANCE BAND

Full width inside margin frame.

Height: 60px
Fill: #000033
Border radius: 12px

Centered text:

CASE-BOUND EVIDENCE TRANSFORMATION
Immutable • Deterministic • Hash-Verified • Overlay-Enforced

White text only.
No glow.
No shadow.

5️⃣ PRIMARY VISUAL — THE CONTROLLED EVIDENTIARY SPINE

Centered large white container:

Border: 1px #C0C5CE

Border radius: 12px

Width: approx 1100px

Horizontally centered

Inside this container:

Five Equal Vertical Columns

Equal width.
Separated by 1px silver lines.

NO icons.
NO arrows.
NO gradients.

COLUMN STRUCTURE (Each Identical)
Top Label (small uppercase)

DATA
INFORMATION
KNOWLEDGE
LEGAL KNOWLEDGE
STRATEGY

Muted navy (70% opacity)

Stage Title (bold uppercase)

EVIDENCE CAPTURE
STRUCTURED PARSING
FACT NORMALIZATION
LEGAL ELEMENT MAPPING
ARTIFACT GENERATION

Color: #000033

Summary Line

1–2 line description.
Max width constrained so all columns maintain vertical alignment.
Min-height enforced to preserve horizontal hold.

Controls Section

Uppercase small label:
CONTROLS APPLIED

Then exactly three bullets per column.

Bullets must align horizontally across all columns.

Visually:

Row 1 across all columns
Row 2 across all columns
Row 3 across all columns

Use:

6px navy dot

13px text

Consistent line-height

No column should have more or fewer bullets.

This alignment creates executive “structural confidence.”

6️⃣ ANCHORED CALLOUT (Consistent Interaction Pattern)

Below main container:

Centered white panel:

Border: 1px #C0C5CE

Radius: 12px

Max width: 960px

Appears on hover of column.
Matches Litigation slide interaction exactly.

No floating overlay.
No animation attention grab.
Just subtle fade-in.

7️⃣ FOUNDATION STRIP (Optional but Recommended)

Below callout:

White container
Top border: 2px #000033

Title:
TRACEABILITY GUARANTEE

Text:
“Every transformation step writes to an immutable audit ledger enabling replay and adversarial defensibility.”

This reinforces legal differentiation.

8️⃣ WHAT THIS NEW SLIDE COMMUNICATES

Old slide communicated:
“We have enterprise data architecture.”

New slide communicates:
“We can defend every allegation in court.”

That is the differentiation.

9️⃣ WHAT MUST NOT HAPPEN

Do not:

Add teal

Add icons

Add shadow depth

Add animated arrows

Add explanatory paragraphs on the sides

Turn it into a wheel

Make it “techy”

This slide must feel:

Judicial
Engineered
Controlled
Safe

🔷 SUMMARY FOR FIGMA DESIGNER

We are replacing a generic enterprise data framework with a vertically structured, deterministic evidentiary transformation architecture.

Maintain:

Canvas discipline

Color system

Typography scale

Interaction consistency

Replace:

All legacy architecture blocks

All BI-style layering

All decorative design elements

Goal:

Educate attorneys that this system is litigation-grade and reproducible under adversarial scrutiny.