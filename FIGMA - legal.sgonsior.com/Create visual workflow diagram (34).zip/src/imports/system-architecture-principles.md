Title

Architectural Principles That Govern the System

Subtitle (lighter weight):

Designed for control, scale, and legal defensibility.

CANVAS

1440px width

Min height 900px

Background: #F4F6F8

12-column grid

96px margins

24px gutters

Use same master components from Slide 21.

CENTRAL FRAME

Width: 8 columns centered (~960px)
White background
1px border #C0C5CE
12px radius

Divide into three equal horizontal sections
2px #000033 divider between sections

Proportional balance maintained.

🔒 SECTION 1 — GOVERNANCE BY DESIGN

Fill: #000033
Text: White

Header (24px bold):

GOVERNANCE BY DESIGN

Four primary principles (18px weight):

• Deterministic First
• Contract Over Code
• Tool Mediation Required
• Replay Equivalence Enforced

Supporting line (14px):

Intelligence operates within declared constraints.

No icons.
No embellishment.
Authority through simplicity.

🧠 SECTION 2 — CONFIGURABLE BUT CONTROLLED

White background
Header in #000033

Two-column layout:

Left Column:

• Service-Oriented Architecture
• API-Driven Integration
• Automation Over Manual Effort
• Microservices Compatible

Right Column:

• Overlay-Based Flexibility
• Extensible Without Rewrite
• Configurable Without Custom Chaos
• Horizontally & Vertically Scalable

Supporting line:

Designed to evolve without losing control.

🗄 SECTION 3 — DATA & SECURITY FOUNDATIONAL

White background
Header in #000033

Two-column layout:

Left Column:

• Rapid Structured Ingestion
• Data Ownership & Interoperability
• Searchable, Catalogued Facts
• Lifecycle Management

Right Column:

• Secure by Design
• Policy-Driven Access
• Consent-Aware Architecture
• Regulatory Alignment

Supporting line:

Every fact traceable. Every action accountable.

SIDE SPINES (Reuse from Slide 21)

Left spine:
Fill #000033
White vertical text:

ARCHITECTURAL DISCIPLINE

Right spine:
Fill #000033
White vertical text:

LEGAL DEFENSIBILITY

STRICT FIGMA CONSTRAINTS

Include this instruction when passing:

No tables

No icons

No gradients

No shadows

No additional colors

Use existing Slide 21 components

Equal vertical spacing between bullet groups

Balanced two-column alignment

Tone: Institutional. Enterprise. Controlled.