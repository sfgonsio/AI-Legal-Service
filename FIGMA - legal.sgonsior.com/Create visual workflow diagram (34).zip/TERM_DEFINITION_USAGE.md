# Term Definition Component - Usage Guide

## Overview
The `TermDefinition` component provides a consistent, elegant way to add hover definitions throughout the application. It's fully responsive and maintains our strict brand discipline.

## Import

```tsx
import { TermDefinition, TermIcon } from "../components/TermDefinition";
```

## Basic Usage

### 1. Inline Variant (Default)
Subtle dotted underline for inline terms:

```tsx
<TermDefinition 
  term="State Machine Controller"
  definition="Orchestrates workflow transitions between stages"
/>
```

### 2. Underline Variant
Bold blue text with hover - for emphasis:

```tsx
<TermDefinition 
  term="Litigation Leverage"
  definition="The strategic advantage gained through structured evidence transformation"
  variant="underline"
/>
```

### 3. Icon Variant
Shows help icon next to term:

```tsx
<TermDefinition 
  term="Evidence Foundation Packet"
  definition="Atomic unit containing facts, evidence, and CA Evidence Code alignments"
  variant="icon"
/>
```

### 4. Term Icon Only
For diagrams or tight spaces:

```tsx
<TermIcon 
  definition="Core architectural component that manages system state"
  size={14}
/>
```

## Position Control

```tsx
<TermDefinition 
  term="Brain Lobe"
  definition="Specialized processing component for evidence transformation"
  position="bottom" // top (default), bottom, left, right
/>
```

## Real-World Examples

### In Running Text
```tsx
<p>
  The system uses a{" "}
  <TermDefinition 
    term="state machine"
    definition="Deterministic workflow controller ensuring proper stage transitions"
    variant="inline"
  />{" "}
  to manage case progression.
</p>
```

### In Lists
```tsx
<ul>
  <li>
    <TermDefinition 
      term="Versioned transitions"
      definition="Each workflow step is tracked with version history"
      variant="inline"
    />
  </li>
  <li>
    <TermDefinition 
      term="Controlled reruns"
      definition="Human-authorized workflow re-execution with audit trails"
      variant="inline"
    />
  </li>
</ul>
```

### In Headers or Emphasis
```tsx
<h3>
  <TermDefinition 
    term="Spine Architecture"
    definition="The five core functions providing litigation infrastructure"
    variant="underline"
  />
</h3>
```

## Design Principles

- **Dark Navy Tooltip**: Tooltips use `var(--deep-navy)` background for contrast
- **Smooth Animation**: 150ms fade-in with subtle scale
- **No Icons Unless Requested**: Follows brand discipline
- **Mobile-Responsive**: Tooltips adjust position for mobile screens
- **Consistent Typography**: Uses base font sizes for accessibility

## When to Use

✅ **Use for:**
- Technical terms (State Machine, Brain Lobe, Spine Function)
- Legal terms (COA, Evidence Foundation Packet)
- System concepts (Governed Program, Controlled Rerun)
- Architecture terms (Layer 2 Workflow, Manifest)

❌ **Don't use for:**
- Common words
- Terms already defined in context
- Navigation elements
- Button labels

## Styling

The component automatically:
- Uses CSS variables for theming
- Adapts to dark/light mode
- Maintains proper z-index layering
- Handles overflow on mobile

## Accessibility

- Uses semantic HTML
- Cursor changes to `help` pointer
- Keyboard accessible (hover triggers on focus)
- Proper ARIA roles
