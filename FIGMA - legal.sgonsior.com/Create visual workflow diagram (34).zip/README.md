# Legal AI Executive Portal

A professional executive review portal for presenting an AI Legal Service system to leadership and stakeholders.

## 🎯 Overview

This multi-page web application provides a comprehensive walkthrough of a legal intelligence system, covering:

- System definition and purpose
- Strategic impact analysis  
- Core capabilities overview
- Workflow integration
- Agent architecture mapping
- Evidentiary defensibility
- **NEW: System governance mechanisms (integrity & reproducibility)**
- Engineering foundation
- Development status
- Leadership feedback collection
- **NEW: Animated video presentation (3-minute overview)**

## ✨ Features

- **12 Sections** - Logical progression from high-level overview to detailed implementation
- **System Governance Page** - Five governance mechanisms with technical → stakeholder translation
- **Animated Video Component** - Auto-playing presentation with full controls
- **Fully Responsive** - Works seamlessly on mobile, tablet, and desktop
- **Mobile Navigation** - Hamburger menu with slide-out panel
- **Smooth Navigation** - Animated page transitions and clear wayfinding
- **Keyboard Shortcuts** - Arrow keys, Home, End, and ? for help
- **Dark Mode** - Toggle between light and dark themes
- **Progress Tracking** - Visual indicator showing position in the portal
- **Professional UI** - Clean, executive-friendly design system

## 🚀 Quick Start

### Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Production Build

```bash
# Build for production
npm run build

# Preview production build
npx serve dist
```

## 📦 Deployment

See **[QUICKSTART.md](./QUICKSTART.md)** for deployment instructions.

**Recommended:** Use Netlify for easiest deployment (drag & drop the `dist` folder)

### Quick Deploy to Netlify:
1. `npm run build`
2. Drag `dist` folder to https://app.netlify.com/drop
3. Done! ✅

## 🎨 Design System

- **Fonts:** Orbitron (headings), Inter (body text)
- **Colors:**
  - Primary Blue: `#336699`
  - Deep Navy: `#000033`
  - Silver Accent: `#C0C5CE`
  - Light Background: `#F4F6F8`
- **Framework:** React + TypeScript
- **Styling:** Tailwind CSS v4
- **Animations:** Motion (Framer Motion)
- **Router:** React Router v7

## 🗂️ Project Structure

```
src/
├── app/
│   ├── components/       # Reusable UI components
│   │   ├── Layout.tsx
│   │   ├── ProgressIndicator.tsx
│   │   ├── PageNavigation.tsx
│   │   └── ...
│   ├── pages/           # Page components (10 sections)
│   │   ├── Welcome.tsx
│   │   ├── WhatThisIs.tsx
│   │   ├── Workflow.tsx
│   │   └── ...
│   ├── hooks/           # Custom React hooks
│   ├── routes.tsx       # Route configuration
│   └── App.tsx          # Main app component
├── styles/
│   ├── theme.css        # Design system tokens
│   ├── fonts.css        # Font imports
│   └── ...
└── ...
```

## ⌨️ Keyboard Shortcuts

- `→` or `↓` - Next page
- `←` or `↑` - Previous page
- `Home` - Go to Welcome page
- `End` - Go to Leadership Input page
- `?` - Show/hide shortcuts modal

## 🌐 Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🔧 Tech Stack

- **React 18.3** - UI framework
- **TypeScript** - Type safety
- **Vite 6** - Build tool
- **Tailwind CSS 4** - Styling
- **React Router 7** - Routing
- **Motion** - Animations
- **Lucide React** - Icons

## 📄 Pages

1. **Welcome** - Introduction and key principles
2. **What This Is** - System definition
3. **What This Changes** - Strategic impact
4. **Core Capabilities** - Feature overview
5. **Workflow** - Process integration
6. **Agent → Program Map** - Architecture layers
7. **Evidentiary Defensibility** - Legal compliance
8. **System Governance** - Integrity & reproducibility
9. **Engineering Foundation** - Technical implementation
10. **Development Status** - Project timeline
11. **Leadership Input** - Feedback collection
12. **Animated Video Presentation** - 3-minute overview

## 📞 Support

For deployment help or customization requests, refer to:
- [DEPLOYMENT.md](./DEPLOYMENT.md) - Detailed deployment guide
- [QUICKSTART.md](./QUICKSTART.md) - Quick deployment steps

## 📝 License

Private project - All rights reserved

---

Built with ❤️ for executive presentations