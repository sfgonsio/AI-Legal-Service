# ✅ SL-5: Engineering Admissibility Leverage (Evidence Pressure Model)

## What Was Built

A **LEFT → RIGHT scrutiny pipeline** that shows how evidence flows through structured evaluation gates to produce defensible litigation artifacts.

---

## Visual Architecture

### **LEFT: Evidence Intake** (Slightly Unstructured)
- Emails
- Agreements  
- Board Minutes
- Text Messages
- Cap Tables

**Conversion Statement:**  
"Converted to Foundation Packets (Hash Verified • Case Scoped)"

---

### **CENTER: Admissibility Evaluation Engine** (The Power Zone)

**Five Sequential Gates** (vertical checkpoints with arrows):

1. **Authentication**
2. **Hearsay Analysis**
3. **Privilege Review**
4. **Relevance & 352 Balancing**
5. **Expert Foundation**

Each gate is numbered, has a checkpoint marker, and shows visual flow downward.

**Under gates:**  
"Versioned • Deterministic • Replayable"

---

### **RIGHT: Structurally Defensible Artifacts** (Clean & Organized)

**Outputs** (visually cleaner than left side):
- Complaint Paragraphs
- Exhibits
- Motion in Limine
- Deposition Outline
- Trial Brief

**Strategic Impact Box:**
- Fewer exclusion surprises
- Stronger motion posture
- Cleaner privilege handling
- Early element weakness detection

---

### **BOTTOM: Platform Guarantees** (Restrained)

- Hash Verified
- Overlay Governed
- Audit Logged
- Replay Equivalent

---

### **CLOSING STATEMENT**

"Evidence enters. Evidence is scrutinized. Evidence emerges defensible."

---

## Why This Works

### **The Metaphor Shift:**
- **Previous model:** Hub-and-spoke architecture (structural)
- **This model:** Scrutiny pipeline (pressure-based)

### **Attorney Psychology:**
- ✅ Attorneys understand **pressure** and **gates**
- ✅ They understand **admissibility scrutiny**
- ✅ They understand **objection survival**
- ✅ They see: "This forces evidence through foundation"

### **The Wow Factor:**
Every piece of evidence must **survive** structured evaluation—just like in court.

---

## Design Details

### **LEFT (Intake):**
- Slight rotation on cards (-0.5° / +0.5°) = visual "messiness"
- Light background (#F9FAFB)
- Items feel unorganized (reflecting raw evidence)

### **CENTER (Gates):**
- Dark navy borders (#000033, 2px)
- Numbered badges (1-5)
- Downward arrows between gates
- Heavy visual weight = scrutiny
- White background = neutral evaluation zone

### **RIGHT (Outputs):**
- Clean cards with dark borders
- No rotation = structured
- Strategic Impact box with bullets
- Light background (#F9FAFB)
- Items feel organized (reflecting defensible artifacts)

---

## Navigation

**Path:** `/evidence-pressure`  
**Label:** "SL-5: ADMISSIBILITY LEVERAGE"  
**Icon:** Filter (scrutiny metaphor)

---

## Key Messaging

1. **Visual flow is left-to-right** (not radial)
2. **Gates are sequential** (not decorative circles)
3. **Outputs are cleaner** (visual transformation)
4. **Strategic impact is explicit** (not implied)

---

## Brand Alignment

✅ **Hash-verified** foundation packets  
✅ **CA Evidence Code** gates (Authentication, Hearsay, Privilege, 352)  
✅ **Deterministic, replayable** evaluation  
✅ **Strategic impact** focus (attorney outcomes)  
✅ **Scrutiny metaphor** (not AI hype)  

---

## Differentiation from SL-4

| Aspect | SL-4 (Litigation Leverage) | SL-5 (Evidence Pressure) |
|--------|---------------------------|--------------------------|
| **View** | Architectural layers | Workflow pipeline |
| **Metaphor** | Three-layer foundation | Scrutiny gates |
| **Focus** | What exists | How it works |
| **Audience** | Engineers + Leadership | Attorneys + Leadership |
| **Feeling** | Structural power | Admissibility confidence |

---

## Status

✅ **Component built:** `/src/app/components/slides/EvidencePressureModel.tsx`  
✅ **Page created:** `/src/app/pages/EvidencePressureSlide.tsx`  
✅ **Route added:** `/evidence-pressure`  
✅ **Navigation updated:** "SL-5: ADMISSIBILITY LEVERAGE"  
✅ **Fully responsive:** Mobile → Tablet → Desktop  
✅ **Brand aligned:** 95%

---

## Next Steps

Ready to build **SL-6 through SL-12** using the same evidence-first, scrutiny-based approach!
