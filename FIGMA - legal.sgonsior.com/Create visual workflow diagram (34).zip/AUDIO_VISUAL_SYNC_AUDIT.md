# AUDIO-VISUAL SYNCHRONIZATION AUDIT & FIX PLAN

## CRITICAL ISSUES IDENTIFIED

### 1. **AUDIO TRUNCATION PROBLEM**
**Issue**: Speech synthesis is being cancelled when scenes transition, cutting off audio mid-sentence.

**Root Cause**: 
- Scene transitions are time-based (fixed durations)
- No mechanism to wait for audio completion before advancing
- `window.speechSynthesis.cancel()` is called on every scene change

**Testing Method**:
```
1. Start video playback
2. Monitor console for speech synthesis events
3. Verify if utterances complete before scene transitions
4. Check if Act 1 voiceover (15s duration) completes in 15s
```

**Current Behavior**: ❌ Audio cuts off at exactly scene.duration milliseconds
**Expected Behavior**: ✅ Audio should complete naturally, then scene should transition

---

### 2. **TIMING CALCULATION ERRORS**

**Current Durations (Fixed):**
- Act 1: 15,000ms for 74-word voiceover
- Act 2: 48,000ms for dialogue (7 exchanges)
- Act 3: 40,000ms for dialogue (7 exchanges)
- Act 4-13: Fixed durations not calculated from actual speech

**Speech Rate Analysis:**
- Current TTS rate: 0.85 (slower than normal)
- Average speech: ~150 words per minute at rate 1.0
- At rate 0.85: ~127 words per minute = ~2.1 words/second

**Act 1 Calculation:**
- Voiceover: 74 words
- At 2.1 words/sec = **35.2 seconds needed**
- Current duration: 15 seconds ❌ **SEVERELY TRUNCATED**

**Act 2 Calculation:**
- Total dialogue words: ~185 words
- With delays and pauses: ~46 seconds needed
- Current duration: 48 seconds ✅ (adequate but tight)

**Act 3 Calculation:**
- Total dialogue words: ~160 words
- With delays and pauses: ~40 seconds needed
- Current duration: 40 seconds ✅ (adequate but tight)

---

### 3. **NO AUDIO COMPLETION DETECTION**

**Current System:**
- Uses `requestAnimationFrame` for scene progress
- No `utterance.onend` event listeners
- Cannot detect when speech actually completes

**Fix Required:**
- Add `utterance.onend` callbacks
- Track audio completion state
- Only advance scene when BOTH animation AND audio complete

---

### 4. **DIALOGUE SCENES LACK COORDINATION**

**Act 2 & 3 Issues:**
- Dialogue is managed inside scene components (VideoScenes.tsx)
- No feedback to parent CinematicVideo component
- Parent can't know when dialogue completes
- Scene transitions can interrupt mid-dialogue

**Current Flow:**
```
CinematicVideo (timer) → Scene transitions → Act2Scene (dialogue)
                                                    ↓
                                             Speech starts
                                                    ↓
                                        [Timer expires too early]
                                                    ↓
                                        Speech cancelled mid-word ❌
```

---

### 5. **VISUAL ANIMATION TIMING**

**Requirements:**
- Visual animations should sync with audio beats
- Key moments should align with voiceover phrases
- Document appearances should match narration timing

**Current Issues:**
- Fixed animation delays (e.g., delay: 0.5, 1.2, 2.5)
- No correlation to actual audio phrasing
- Act 1 documents animate at 1.5s, 1.9s, 2.3s
- But voiceover hasn't reached those phrases yet

---

## SYSTEMATIC FIX PLAN

### PHASE 1: Audio Completion Detection ✅

**Files to Modify:**
1. `/src/app/components/video/CinematicVideo.tsx`
   - Add `audioCompletedRef` state tracking
   - Implement `utterance.onend` listeners
   - Scene advances only when audio completes

2. `/src/app/components/video/VideoScenes.tsx`
   - Add `onAudioComplete` callback prop
   - Dialogue scenes report completion to parent
   - Proper cleanup on unmount

**Implementation:**
```typescript
// Track audio state
const [audioCompleted, setAudioCompleted] = useState(false);
const audioCompletedRef = useRef(false);

// In TTS effect
utterance.onend = () => {
  audioCompletedRef.current = true;
  setAudioCompleted(true);
};

// In scene advancement
if (progress >= 1 && audioCompletedRef.current) {
  // Safe to advance
}
```

---

### PHASE 2: Dynamic Duration Calculation ✅

**Word Count Analysis:**
```javascript
function estimateSpeechDuration(text: string, rate: number): number {
  const words = text.trim().split(/\s+/).length;
  const wordsPerSecond = (150 / 60) * rate; // 150 WPM baseline
  const baseSeconds = words / wordsPerSecond;
  const pauseBuffer = baseSeconds * 0.15; // 15% buffer for pauses
  return Math.ceil((baseSeconds + pauseBuffer) * 1000); // milliseconds
}
```

**Recalculated Durations:**
- Title (14 words): 6,900ms → **8,000ms**
- Act 1 (74 words): 15,000ms → **36,000ms** 
- Act 4 (56 words): 12,000ms → **28,000ms**
- Act 5 (62 words): 14,000ms → **30,000ms**
- Act 6 (42 words): 11,000ms → **21,000ms**
- Act 7 (52 words): 12,000ms → **26,000ms**
- Act 8 (32 words): 10,000ms → **16,000ms**
- Act 9 (50 words): 10,000ms → **25,000ms**
- Act 10 (48 words): 11,000ms → **24,000ms**
- Act 11 (58 words): 11,000ms → **29,000ms**
- Act 12 (36 words): 10,000ms → **18,000ms**
- Act 13 (68 words): 13,000ms → **33,000ms**
- Final (58 words): 10,000ms → **29,000ms**

---

### PHASE 3: Dialogue Scene Coordination ✅

**Act 2 & 3 Callback System:**
```typescript
interface SceneProps {
  scene: Scene;
  isPlaying: boolean;
  onAudioComplete?: () => void; // NEW
}

// In dialogue scenes
useEffect(() => {
  // ... existing dialogue setup
  
  const lastLine = ACT2_DIALOGUE[ACT2_DIALOGUE.length - 1];
  const totalDuration = lastLine.delay + lastLine.duration + 1000;
  
  const completionTimeout = setTimeout(() => {
    onAudioComplete?.();
  }, totalDuration);
  
  return () => clearTimeout(completionTimeout);
}, [isPlaying, onAudioComplete]);
```

---

### PHASE 4: Visual-Audio Synchronization ✅

**Animation Timing Strategy:**
1. Parse voiceover text into phrases
2. Calculate when each phrase is spoken
3. Align visual animations to phrase timing

**Example for Act 1:**
```
Voiceover phrase analysis:
- "Jenny founded..." (0-2s) → Initial setup
- "She brought in a colleague..." (2-5s) → Partner introduction
- "They executed operating agreements..." (5-8s) → Show "Operating Agreement" doc
- "They shared governance..." (8-10s) → Show "Board Minutes" doc
- "They shared equity..." (10-12s) → Show "Cap Table" doc
```

**Adjusted Animation Delays:**
```typescript
{ name: "Operating Agreement", angle: 0, delay: 5.0 },   // Was 1.5
{ name: "Board Minutes", angle: 120, delay: 8.0 },       // Was 1.9
{ name: "Cap Table", angle: 240, delay: 10.0 }          // Was 2.3
```

---

## TESTING PROTOCOL

### Test 1: Audio Completion
```
✅ Play through entire video
✅ No audio should be cut off mid-word
✅ Each scene should complete audio before transitioning
✅ Manual console.log at utterance.onend events
```

### Test 2: Duration Accuracy
```
✅ Record actual completion times vs. expected
✅ Act 1 should take ~36 seconds (not 15)
✅ Total video length should be ~350 seconds (not 250)
✅ Progress bar should accurately reflect remaining time
```

### Test 3: Dialogue Synchronization
```
✅ Act 2 should complete full 10-line exchange
✅ Act 3 should complete full 10-line exchange
✅ Speech bubbles should appear/disappear cleanly
✅ No scene transition during active dialogue
```

### Test 4: Visual-Audio Alignment
```
✅ Act 1 documents should appear when mentioned
✅ Act 5 gates should animate in sequence with narration
✅ Act 7 patterns should appear when described
✅ No "dead time" with visuals static while audio plays
```

### Test 5: Pause/Resume Behavior
```
✅ Pausing should stop audio immediately
✅ Resuming should continue from correct position
✅ Scene jumping should reset audio properly
✅ Restart button should reset everything cleanly
```

---

## IMPLEMENTATION CHECKLIST

### Immediate Fixes (Critical):
- [ ] Add `utterance.onend` event listeners
- [ ] Implement audio completion state tracking
- [ ] Update all scene durations based on word count
- [ ] Add dialogue completion callbacks
- [ ] Test audio truncation is eliminated

### Quality Improvements:
- [ ] Sync visual animations to voiceover phrases
- [ ] Add buffer time between scenes (500ms)
- [ ] Improve speech synthesis voice selection
- [ ] Add visual indicator when audio is playing
- [ ] Implement closed captions system

### Polish:
- [ ] Add fade-out on audio before scene transition
- [ ] Subtle audio cross-fade between scenes
- [ ] Visual "pulse" on speaker during dialogue
- [ ] Progress bar shows audio waveform
- [ ] Scene preview thumbnails on timeline

---

## EXPECTED OUTCOMES

**Before:**
- ❌ Audio cuts off mid-sentence
- ❌ Scenes transition too quickly
- ❌ Visuals not synchronized
- ❌ Total video: ~4 minutes

**After:**
- ✅ Audio completes naturally
- ✅ Scenes wait for audio + visuals
- ✅ Animations sync with narration
- ✅ Total video: ~6 minutes (proper pacing)
- ✅ Professional cinematic quality

---

## QUALITY ASSURANCE METRICS

### Audio Quality:
- **Completion Rate**: 100% of utterances complete before transition
- **Truncation Events**: 0
- **Audio Gaps**: < 500ms between scenes
- **Volume Consistency**: ±5dB across all scenes

### Visual Quality:
- **Animation Sync**: ±200ms of voiceover phrase timing
- **Frame Rate**: 60fps throughout
- **Transition Smoothness**: No jarring cuts
- **Layout Precision**: No overlapping elements

### User Experience:
- **Perceived Quality**: Professional/cinematic
- **Cognitive Load**: Low (clear narrative flow)
- **Engagement**: High (audio-visual harmony)
- **Reproducibility**: 100% (deterministic playback)

---

**Status**: AUDIT COMPLETE - READY FOR IMPLEMENTATION
**Next Step**: Execute PHASE 1 - Audio Completion Detection
